import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable, of, Subscription } from 'rxjs';
import { catchError, delay, finalize, map, tap } from 'rxjs/operators';
import { GlobalConstants } from '@core/helpers/global-constants';
import { User } from '../models/user';
import { LoginResult } from '@core/models/login-result..model';
import { CommonHelper } from '@core/helpers/common-helper';

@Injectable({
  providedIn: 'root',
})
export class AuthService {

  // Feilds.
  //private urlBaseApi = environment.apiBaseURL;
  private timer: Subscription;
  isAuth = false;
  errorMessage: string;

  private currentUserSubject: BehaviorSubject<User>;
  public currentUser: Observable<User>;

  // Ctor.
  constructor(private http: HttpClient) {
    this.currentUserSubject = new BehaviorSubject<User>(
      JSON.parse(localStorage.getItem('currentUser') || '{}')
    );
    this.currentUser = this.currentUserSubject.asObservable();
    window.addEventListener('storage', this.storageEventListener.bind(this));
  }

  public get currentUserValue(): User {
    return this.currentUserSubject.value;
  }

  // storageEventListener.
  private storageEventListener(event: StorageEvent) {
    if (event.storageArea === localStorage) {
      if (event.key === 'logout-event') {
        this.stopTokenTimer();
        this.currentUserSubject.next(new User());
      }
      if (event.key === 'login-event') {
        this.stopTokenTimer();
        this.http.get<LoginResult>(`${GlobalConstants.uriAuthentificationCtx}/user`).subscribe((response) => {
          var dd = response;
          // this.currentUserSubject.next({
          //   id: response.id,
          //   username: response.username,
          //   role: response.role,
          // });
        });
      }
    }
  }

  login(username: string, password: string) {
    return this.http.post<LoginResult>(`${GlobalConstants.uriAuthentificationCtx}/login`, { username, password })
                    .pipe(
                      map((response) => {
                        if(response.isAuthenticated) {
                          this.currentUserSubject.next({
                            id: '',
                            username: response.username,
                            password: '',
                            nomCabinet: '',
                            role: response.roles[0],
                            photo: '',
                            accessToken: response.accessToken,
                            refreshToken: response.refreshToken,
                            isAuthenticated: response.isAuthenticated
                          });
                          this.setLocalStorage(response);
                          this.startTokenTimer();
                          this.isAuth = true;
                        }
                        else {
                          this.isAuth = false;
                        }
                        return response;
                      }),
                      catchError(error => {
                        this.isAuth = false;
                        this.errorMessage = error;
                        return of(error);
                      })
                    );
  }

  logout() {
    // remove user from local storage to log user out
    // localStorage.removeItem('currentUser');
    // this.currentUserSubject.next(this.currentUserValue);
    // return of({ success: false });

    this.http.post<unknown>(`${GlobalConstants.uriAuthentificationCtx}/logout`, {})
      .pipe(
        finalize(() => {
          this.clearLocalStorage();
          this.currentUserSubject.next(new User());
          this.stopTokenTimer();
          //this.router.navigate(['authentication/signin']);
        })
      ).subscribe();

    this.clearLocalStorage();
    this.currentUserSubject.next(new User());
    return of({ success: false });
  }

  // refreshToken.
  refreshToken() {
    const refreshToken = localStorage.getItem('refresh_token');
    if (!refreshToken) {
      this.clearLocalStorage();
      return of(null);
    }

    return this.http.post<LoginResult>(`${GlobalConstants.uriAuthentificationCtx}/refresh-token`, { refreshToken })
                    .pipe(
                      map((response) => {
                        // this.currentUserSubject.next({
                        //   username: response.username,
                        //   role: response.role
                        // });
                        this.setLocalStorage(response);
                        this.startTokenTimer();
                        return response;
                      }),
                      catchError(error => {
                        this.isAuth = false;
                        this.errorMessage = error;
                        return of(error);
                      })
                    );
  }

  // setLocalStorage.
  setLocalStorage(loginResult: LoginResult) {
    var decode_id_token = CommonHelper.decodeToken(loginResult.accessToken);
    localStorage.setItem('access_token', loginResult.accessToken);
    localStorage.setItem('username', loginResult.username);
    localStorage.setItem('user_roles', JSON.stringify(loginResult.roles));
    localStorage.setItem('refresh_token', loginResult.refreshToken);
    localStorage.setItem('login-event', 'login' + Math.random());
  }

  // clearLocalStorage.
  clearLocalStorage() {
    localStorage.removeItem('access_token');
    localStorage.removeItem('user_roles');
    localStorage.removeItem('refresh_token');
    localStorage.removeItem('specialites');
    localStorage.removeItem('username');
    localStorage.setItem('logout-event', 'logout' + Math.random());
  }

  // getTokenRemainingTime.
  private getTokenRemainingTime() {
    const accessToken = localStorage.getItem('access_token');
    if (!accessToken) {
      return 0;
    }
    const jwtToken = JSON.parse(atob(accessToken.split('.')[1]));
    const expires = new Date(jwtToken.exp * 1000);
    return expires.getTime() - Date.now();
  }

  // startTokenTimer.
  private startTokenTimer() {
    const timeout = this.getTokenRemainingTime();
    this.timer = of(true)
      .pipe(
        delay(timeout),
        tap(() => this.refreshToken().subscribe())
      )
      .subscribe();
  }

  // stopTokenTimer.
  private stopTokenTimer() {
    this.timer?.unsubscribe();
  }

  // isUserInRole.
  public isUserInRole(roles: string[]) {
    const userRoles = localStorage.getItem('user_roles');
    for (var cpt = 0; cpt < roles.length; cpt++) {
      if (userRoles?.includes(roles[cpt])) {
          return true;
      }
    }
    return false;
  }

  // ngOnDestroy.
  ngOnDestroy(): void {
    window.removeEventListener('storage', this.storageEventListener.bind(this));
  }
}
