import { Injectable, Input } from '@angular/core';
import { BehaviorSubject, catchError, map, Observable, of } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { UnsubscribeOnDestroyAdapter } from '@shared';
import { PlanningTravauxModel } from '@core/models/planning-travaux.model';
import { GlobalConstants } from '@core/helpers/global-constants';
import { GlobalResponse } from '@core/helpers/global-response';

@Injectable({
  providedIn: 'root',
})
export class SuiviProjetService extends UnsubscribeOnDestroyAdapter  {
  
  // Fields.
  isGetAllPlanningTravauxOK = false;
  isAddPlanningTravauxOk = false;
  isEditPlanningTravauxOk = false;
  isDeletePlanningTravauxOK = false;
  
  isTblLoading = true;
  dataChange: BehaviorSubject<PlanningTravauxModel[]> = new BehaviorSubject<PlanningTravauxModel[]>([]);
  
  dialogData!: PlanningTravauxModel;

  currentPlanningTravaux: any = null;
  planningTravauxAdd: PlanningTravauxModel;
  planningTravauxUpdate: PlanningTravauxModel;
  currentProjetCoutTotalTTC: string;

  constructor(private httpClient: HttpClient) {
    super();
  }

  get data(): PlanningTravauxModel[] {
    return this.dataChange.value;
  }

  getDialogData() {
    return this.dialogData;
  }

  /** CRUD METHODS */
  getAllPlanningTravauxByOperationId(operationId: any): void {
    this.subs.sink = this.httpClient.get<any[]>(`${GlobalConstants.uriPlanningTravauxCtx}?operationId=${operationId}`)
          .subscribe({
            next: (response: any) => {

                this.isTblLoading = false;
                this.isGetAllPlanningTravauxOK = true;

                var planningsTemp = new Array<PlanningTravauxModel>();
                planningsTemp = response.data;
                var plannings = new Array<any>();
  
                planningsTemp.forEach(element => {
                  var planning = {
                    operationId: element.operationId,
                    planningTravauxId: element.planningTravauxId,
                    activiteTypeCode: element.activiteTypeCode,
                    activiteTypeLibelle: element.activiteTypeLibelle,
                    sousTraitantId: element.sousTraitantId,
                    sousTraitantNomSociete: element.sousTraitantNomSociete,
                    coutHT: element.coutHT,
                    tva: element.tva,

                    materiels: element.materiels,
                    debutDate: element.debutDate,

                    activiteForUsedCode: element.activiteForUsedCode,
                    selectedImmeubleId: element.selectedImmeubleId,
                    selectedImmeubleNom: element.selectedImmeubleNom,
                    selectedAppartementId: element.selectedAppartementId,
                    selectedAppartementReference: element.selectedAppartementReference,

                    finDate: element.finDate,
                  };
                  plannings.push(planning);
                });
                this.dataChange.next(plannings);

                this.calculateCoutTotal(this.data);
            },
            error: () => {
              this.isGetAllPlanningTravauxOK = true;
              this.isTblLoading = false;
              this.dataChange.next(new Array<PlanningTravauxModel>());
              return of(GlobalResponse.handleError());
            },
          });
  }

  addPlanningTravaux(planningTravaux: PlanningTravauxModel): Observable<any> {
    return this.httpClient.post<PlanningTravauxModel>(`${GlobalConstants.uriPlanningTravauxCtx}`, planningTravaux)
                    .pipe(
                        map((response: any) => {
                            this.isTblLoading = false;
                            this.isAddPlanningTravauxOk = true;
                            this.dialogData = response.data;
                            this.planningTravauxAdd = response.data;
                            return response.data;
                        }),
                        catchError(() => {
                            this.isAddPlanningTravauxOk = false;
                            this.isTblLoading = false;
                            return of(GlobalResponse.handleError());
                        })
                    );
  }

  updatePlanningTravaux(planningTravaux: PlanningTravauxModel): Observable<any> {
    return this.httpClient.put<PlanningTravauxModel>(`${GlobalConstants.uriPlanningTravauxCtx}`, planningTravaux)
                    .pipe(
                        map((response: any) => {
                            this.isTblLoading = false;
                            this.isEditPlanningTravauxOk = true;
                            this.dialogData = response.data;
                            this.planningTravauxUpdate = response.data;
                            return response.data;
                        }),
                        catchError(() => {
                            this.isEditPlanningTravauxOk = false;
                            this.isTblLoading = false;
                            return of(GlobalResponse.handleError());
                        })
                    );
  }

  deletePlanningTravaux(operationId: any, planningTravauxId: any): Observable<any> {
    return this.httpClient.delete(`${GlobalConstants.uriPlanningTravauxCtx}?operationId=${operationId}&planningTravauxId=${planningTravauxId}`)
                    .pipe(
                      map((response: any) => {
                          this.isTblLoading = false;
                          this.isDeletePlanningTravauxOK = true;
                          return response.data;
                        }),
                        catchError(() => {
                          this.isTblLoading = false;
                          this.isDeletePlanningTravauxOK = false;
                          return of(GlobalResponse.handleError());
                        })
                    );
  }

  calculateCoutTotal(data: PlanningTravauxModel[]) {
    var prixTotalGlobal = 0;
    data.forEach(planning => {
      var coutHT = planning.coutHT;
      var tva = planning.tva;

      var prixPlanningTTC = coutHT * (1 + tva / 100);
      var prixTotalTTC = prixPlanningTTC;

      planning.materiels.forEach(materiel => {
        var prixUnitaireMateriel = materiel.prixUnitaire;
        var tvaMateriel = materiel.tva;
        var quantiteMateriel = materiel.quantite;

        var prixUnitaireMaterielTTC = prixUnitaireMateriel * (1 + tvaMateriel / 100);

        var prixMaterielTTC = prixUnitaireMaterielTTC * quantiteMateriel;
        prixTotalTTC = prixPlanningTTC + prixMaterielTTC;
      });
      prixTotalGlobal = prixTotalGlobal + prixTotalTTC;
    });
    this.currentProjetCoutTotalTTC = `${prixTotalGlobal.toLocaleString('de-DE', {minimumFractionDigits: 2})} DA`;
    return this.currentProjetCoutTotalTTC;
  }
  
}
