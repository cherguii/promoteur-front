// import { Injectable } from '@angular/core';
// import { HttpClient } from '@angular/common/http';
// import { UnsubscribeOnDestroyAdapter } from '@shared';
// import { BehaviorSubject, catchError, map, Observable, of } from 'rxjs';
// import { GlobalConstants } from '@core/helpers/global-constants';
// import { GlobalResponse } from '@core/helpers/global-response';
// import { OperationItemModel } from '@core/models/operation-item.model';
// import { OperationUpsertModel } from '@core/models/operation-upsert.model';

// @Injectable()
// export class OperationService extends UnsubscribeOnDestroyAdapter {

//   // Fields.
//   isGetAllOperationOk = false;
//   isAddOperationOk = false;
//   isEditOperationOK = false;
//   isDeleteOperationOK = false;
//   //errorMessage: any;
//   isTblLoading = true;
//   dataChange: BehaviorSubject<OperationItemModel[]> = new BehaviorSubject<OperationItemModel[]>([]);
  
//   dialogData!: OperationItemModel;
//   currentOperation: any = null;
//   operationAdd: OperationItemModel;
//   operationUpdate: OperationItemModel;

//   // Ctor.
//   constructor(private httpClient: HttpClient) {
//     super();
//   }

//   get data(): OperationItemModel[] {
//     return this.dataChange.value;
//   }

//   getDialogData() {
//     return this.dialogData;
//   }
  
//   /** CRUD METHODS */
//   getAllOperation(): void {
//     this.subs.sink = this.httpClient.get<any[]>(`${GlobalConstants.uriOperationCtx}`)
//           .subscribe({
//             next: (response: any) => {

//                 this.isTblLoading = false;
//                 this.isGetAllOperationOk = true;

//                 var operationsTemp = new Array<OperationItemModel>();
//                 operationsTemp = response.data;
//                 var operations = new Array<any>();
  
//                 operationsTemp.forEach(element => {
//                   var operation = {
//                     operationId: element.operationId,
//                     nom: element.nom,
//                     adresse: element.adresse,
//                     ville: element.ville,
//                     surfaceTotal: element.surfaceTotal,
//                     demarrageDate: element.demarrageDate,
//                     finDate: element.finDate,
//                     //livraisonDate: element.livraisonDate,
//                     statusCode: element.statusCode,
//                     statusLibelle: element.statusLibelle,
//                   };
//                   operations.push(operation);
//                 });
//                 this.dataChange.next(operations);
//             },
//             error: () => {
//               this.isGetAllOperationOk = true;
//               this.isTblLoading = false;
//               this.dataChange.next(new Array<OperationItemModel>());
//               return of(GlobalResponse.handleError());
//             },
//           });
          
//   }

//   addOperation(operation: OperationUpsertModel): Observable<any> {
//     return this.httpClient.post<OperationUpsertModel>(`${GlobalConstants.uriOperationCtx}`, operation)
//                     .pipe(
//                         map((response: any) => {
//                             this.isTblLoading = false;
//                             this.isAddOperationOk = true;
//                             this.dialogData = response.data;
//                             this.operationAdd = response.data;
//                             return response.data;
//                         }),
//                         catchError(() => {
//                             this.isAddOperationOk = false;
//                             this.isTblLoading = false;
//                             return of(GlobalResponse.handleError());
//                         })
//                     );
                    
//   }

//   updateOperation(operation: OperationUpsertModel): Observable<any> {
//     return this.httpClient.put<OperationUpsertModel>(`${GlobalConstants.uriOperationCtx}`, operation)
//                     .pipe(
//                         map((response: any) => {
//                             this.isTblLoading = false;
//                             this.isEditOperationOK = true;
//                             this.dialogData = response.data;
//                             this.operationUpdate = response.data;
//                             return response.data;;
//                         }),
//                         catchError(() => {
//                             this.isEditOperationOK = false;
//                             this.isTblLoading = false;
//                             return of(GlobalResponse.handleError());
//                         })
//                     );
                    
//   }

//   deleteOperation(operationId: string): Observable<any> {
//     return this.httpClient.delete(`${GlobalConstants.uriOperationCtx}?id=${operationId}`)
//                     .pipe(
//                       map((response: any) => {
//                         this.isTblLoading = false;
//                             this.isDeleteOperationOK = true;
//                             return response.data;
//                         }),
//                         catchError(() => {
//                           this.isTblLoading = false;
//                             this.isDeleteOperationOK = false;
//                             return of(GlobalResponse.handleError());
//                         })
//                     );
                    
//   }
// }
