import { Injectable } from "@angular/core";
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material/snack-bar';

@Injectable({ providedIn: 'root' })
export class NotificationService {

  //Ctor.
  constructor(public snackBar: MatSnackBar) { }

  //openSnackBarPosition.
  openSnackBarPosition(message: string, hPos: MatSnackBarHorizontalPosition, vPos: MatSnackBarVerticalPosition, className: string) {
    this.snackBar.open(`${message}`, 'X', {
      duration: 20000,
      horizontalPosition: hPos,
      verticalPosition: vPos,
      panelClass: [className]
    });
  }

  // openSnackBarPositionWithDuration.
  openSnackBarPositionWithDuration(message: string, hPos: MatSnackBarHorizontalPosition, vPos: MatSnackBarVerticalPosition, duration: number, className: string) {
    this.snackBar.open(`${message}`, 'X', {
      duration: duration,
      horizontalPosition: hPos,
      verticalPosition: vPos,
      panelClass: [className]
    });
  }

  openSnackUpload(message: string, hPos: MatSnackBarHorizontalPosition, vPos: MatSnackBarVerticalPosition, className: string, duration: number) {
    this.snackBar.open(`${message}`, 'X', {
      duration: duration,
      horizontalPosition: hPos,
      verticalPosition: vPos,
      panelClass: [className]
    });
  }
  
}
