import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { BaseService } from './baseService/base.service';
import { GlobalConstants } from '@core/helpers/global-constants';
import { PatientModel } from '@core/models/patient.model';
import { NextPreviousPatientModel } from '@core/models/salle-attente.model';
import { GlobalResponse } from '@core/helpers/global-response';

@Injectable({
  providedIn: 'root',
})
export class SalleAttenteService extends BaseService {
  
  // Fields.
  isDocteurItemsHomeOk = false;
  isGetSalleAttenteByDocteurIdOK = false;
  isAddPatientOk = false;
  isUpdatePatientOk = false;
  isUpdateSalleAttenteOk = false;
  isDeletePatientOk = false;
  currentPatient: any = null;

  getDocteurItemsHome(): Observable<any>  {
    return super.getAll<any[]>(`${GlobalConstants.uriSalleAttenteCtx}`)
                .pipe(
                    map((response) => {
                        this.isDocteurItemsHomeOk = true;
                        var result = GlobalResponse.getResponse(response);
                        return result.data;
                    }),
                    catchError(() => {
                        this.isDocteurItemsHomeOk = false;
                        return of(GlobalResponse.handleError());
                    })
                );
  }

  getSalleAttenteByDocteurId(docteurId:any): Observable<any>  {
    return super.getAll<any>(`${GlobalConstants.uriSalleAttenteCtx}/GetByDocteurIdAsync?docteurId=${docteurId}`)
                .pipe(
                    map((response) => {
                        this.isGetSalleAttenteByDocteurIdOK = true;
                        var result = GlobalResponse.getResponse(response);
                        return result.data;
                    }),
                    catchError(() => {
                        this.isGetSalleAttenteByDocteurIdOK = false;
                        return of(GlobalResponse.handleError());
                    })
                );
 }
 
 addPatient(patient: PatientModel): Observable<any> {
    return super.post<PatientModel>(patient, `${GlobalConstants.uriSalleAttenteCtx}`)
                .pipe(
                    map((response: any) => {                            
                        this.isAddPatientOk = true;
                        var result = GlobalResponse.getResponse(response);
                        return result.data;
                    }),
                    catchError(() => {
                        this.isAddPatientOk = false;
                        return of(GlobalResponse.handleError());
                    })
                );                    
  }

  updatePatient(patient: PatientModel): Observable<any> {
    return super.put<PatientModel>(patient, `${GlobalConstants.uriSalleAttenteCtx}`)
                .pipe(
                    map((response: any) => {                            
                        this.isUpdatePatientOk = true;
                        var result = GlobalResponse.getResponse(response);
                        return result.data;
                    }),
                    catchError(() => {
                        this.isUpdatePatientOk = false;
                        return of(GlobalResponse.handleError());
                    })
                );                    
  }
  
  updateSalleAttente(salleAttente: NextPreviousPatientModel): Observable<any> {
    return super.put<NextPreviousPatientModel>(salleAttente, `${GlobalConstants.uriSalleAttenteCtx}/UpdateSalleAttente`)
                .pipe(
                    map((response: any) => {                            
                        this.isUpdateSalleAttenteOk = true;
                        var result = GlobalResponse.getResponse(response);
                        return result.data;
                    }),
                    catchError(() => {
                        this.isUpdateSalleAttenteOk = false;
                        return of(GlobalResponse.handleError());
                    })
                );
                    
  }

  deletePatient(patientId: string, docteurId: string): Observable<any> {
    return super.delete(`${GlobalConstants.uriSalleAttenteCtx}?id=${patientId}&docteurId=${docteurId}`)
                .pipe(
                    map((response: any) => {
                        this.isDeletePatientOk = true;
                        var result = GlobalResponse.getResponse(response);
                        return result.data;
                    }),
                    catchError(() => {
                        this.isDeletePatientOk = false;
                        return of(GlobalResponse.handleError());
                    })
                );
                    
  }

}
