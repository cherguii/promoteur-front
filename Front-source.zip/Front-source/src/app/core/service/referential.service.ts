import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { BaseService } from './baseService/base.service';
import { GlobalConstants } from '@core/helpers/global-constants';
import { GlobalResponse } from '@core/helpers/global-response';
import { ReferentielModel } from '@core/models/referentiel.model';

@Injectable({
  providedIn: 'root',
})
export class ReferentialService extends BaseService {
  
    // Fields.
    isGetAllAppartementTypeOk = false;
    isGetAllPositionAppartementOk = false;
    isGetAllCuisineTypeOk = false;
    isGetAllActiviteTypeOk = false;
    isGetAllSousTraitantTypeOk = false;

    // Appel l'api référentiel et retourne la liste des AppartementType.
    getAllAppartementType(): Observable<any>  {
        return super.getAll<ReferentielModel[]>(`${GlobalConstants.uriReferentialCtx}/AppartementType`)
                    .pipe(
                        map((response) => {
                            this.isGetAllAppartementTypeOk = true;
                            var result = GlobalResponse.getResponse(response);
                            return result.data as ReferentielModel[];
                        }),
                        catchError(() => {
                            this.isGetAllAppartementTypeOk = false;
                            return of(GlobalResponse.handleError());
                        })
                    );
    }

    // Appel l'api référentiel et retourne la liste des PositionAppartement.
    getAllPositionAppartement(): Observable<any>  {
        return super.getAll<ReferentielModel[]>(`${GlobalConstants.uriReferentialCtx}/PositionAppartement`)
                    .pipe(
                        map((response) => {
                            this.isGetAllPositionAppartementOk = true;
                            var result = GlobalResponse.getResponse(response);
                            return result.data as ReferentielModel[];
                        }),
                        catchError(() => {
                            this.isGetAllPositionAppartementOk = false;
                            return of(GlobalResponse.handleError());
                        })
                    );
    }

    // Appel l'api référentiel et retourne la liste des CuisineType.
    getAllCuisineType(): Observable<any>  {
        return super.getAll<ReferentielModel[]>(`${GlobalConstants.uriReferentialCtx}/CuisineType`)
                    .pipe(
                        map((response) => {
                            this.isGetAllCuisineTypeOk = true;
                            var result = GlobalResponse.getResponse(response);
                            return result.data as ReferentielModel[];
                        }),
                        catchError(() => {
                            this.isGetAllCuisineTypeOk = false;
                            return of(GlobalResponse.handleError());
                        })
                    );
    }

    // Appel l'api référentiel et retourne la liste des ActiviteType.
    getAllActiviteType(): Observable<any>  {
        return super.getAll<ReferentielModel[]>(`${GlobalConstants.uriReferentialCtx}/ActiviteType`)
                    .pipe(
                        map((response) => {
                            this.isGetAllActiviteTypeOk = true;
                            var result = GlobalResponse.getResponse(response);
                            return result.data as ReferentielModel[];
                        }),
                        catchError(() => {
                            this.isGetAllActiviteTypeOk = false;
                            return of(GlobalResponse.handleError());
                        })
                    );
    }

    // Appel l'api référentiel et retourne la liste des SousTraitantType.
    getAllSousTraitantType(): Observable<any>  {
        return super.getAll<ReferentielModel[]>(`${GlobalConstants.uriReferentialCtx}/SousTraitantType`)
                    .pipe(
                        map((response) => {
                            this.isGetAllSousTraitantTypeOk = true;
                            var result = GlobalResponse.getResponse(response);
                            return result.data as ReferentielModel[];
                        }),
                        catchError(() => {
                            this.isGetAllSousTraitantTypeOk = false;
                            return of(GlobalResponse.handleError());
                        })
                    );
    }

}
