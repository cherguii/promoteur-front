import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { UnsubscribeOnDestroyAdapter } from '@shared';
import { BehaviorSubject, catchError, map, Observable, of } from 'rxjs';
import { GlobalConstants } from '@core/helpers/global-constants';
import { GlobalResponse } from '@core/helpers/global-response';
import { ActiviteTypeModel } from '@core/models/activite-type.model';

@Injectable()
export class ActiviteService extends UnsubscribeOnDestroyAdapter {

  // Fields.
  isGetAllActiviteOk = false;
  isGetAllActiviteForActiviteOK = false;
  isGetQuantiteQuiResteEnStockOK = false;
  isAddActiviteOk = false;
  isEditActiviteOK = false;
  isDeleteActiviteOK = false;
  isTblLoading = true;
  dataChange: BehaviorSubject<ActiviteTypeModel[]> = new BehaviorSubject<ActiviteTypeModel[]>([]);
  dialogData!: ActiviteTypeModel;
  currentActivite: any = null;
  activiteAdd: ActiviteTypeModel;
  activiteUpdate: ActiviteTypeModel;

  // Ctor.
  constructor(private httpClient: HttpClient) {
    super();
  }

  get data(): ActiviteTypeModel[] {
    return this.dataChange.value;
  }

  getDialogData() {
    return this.dialogData;
  }
  
  /** CRUD METHODS */
  getAllActivite(): void {
    this.subs.sink = this.httpClient.get<any[]>(`${GlobalConstants.uriActiviteTypeCtx}`)
          .subscribe({
            next: (response: any) => {

                this.isTblLoading = false;
                this.isGetAllActiviteOk = true;

                var activitesTemp = new Array<ActiviteTypeModel>();
                activitesTemp = response.data;
                var activites = new Array<any>();
  
                activitesTemp.forEach(element => {
                  var activite = {
                    activiteTypeId: element.activiteTypeId,
                    libelle: element.libelle,
                    order: element.order
                  };
                  activites.push(activite);
                });
                this.dataChange.next(activites);
            },
            error: () => {
              this.isGetAllActiviteOk = true;
              this.isTblLoading = false;
              this.dataChange.next(new Array<ActiviteTypeModel>());
              return of(GlobalResponse.handleError());
            },
          });
          
  }

  addActivite(activite: ActiviteTypeModel): Observable<any> {
    return this.httpClient.post<ActiviteTypeModel>(`${GlobalConstants.uriActiviteTypeCtx}`, activite)
                    .pipe(
                        map((response: any) => {
                            this.isTblLoading = false;
                            this.isAddActiviteOk = true;
                            this.dialogData = response.data;
                            this.activiteAdd = response.data;
                            return response.data;
                        }),
                        catchError(() => {
                            this.isAddActiviteOk = false;
                            this.isTblLoading = false;
                            return of(GlobalResponse.handleError());
                        })
                    );
                    
  }

  updateActivite(activite: ActiviteTypeModel): Observable<any> {
    return this.httpClient.put<ActiviteTypeModel>(`${GlobalConstants.uriActiviteTypeCtx}`, activite)
                    .pipe(
                        map((response: any) => {
                            this.isTblLoading = false;
                            this.isEditActiviteOK = true;
                            this.dialogData = response.data;
                            this.activiteUpdate = response.data;
                            return response.data;;
                        }),
                        catchError(() => {
                            this.isEditActiviteOK = false;
                            this.isTblLoading = false;
                            return of(GlobalResponse.handleError());
                        })
                    );
                    
  }

  deleteActivite(activiteTypeId: string): Observable<any> {
    return this.httpClient.delete(`${GlobalConstants.uriReferentialCtx}uriActiviteTypeCtx?id=${activiteTypeId}`)
                    .pipe(
                      map((response: any) => {
                        this.isTblLoading = false;
                            this.isDeleteActiviteOK = true;
                            return response.data;
                        }),
                        catchError(() => {
                          this.isTblLoading = false;
                            this.isDeleteActiviteOK = false;
                            return of(GlobalResponse.handleError());
                        })
                    );
                    
  }
}
