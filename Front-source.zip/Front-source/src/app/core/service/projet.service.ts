import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { BaseService } from './baseService/base.service';
import { GlobalConstants } from '@core/helpers/global-constants';
import { GlobalResponse } from '@core/helpers/global-response';
import { OperationItemModel } from '@core/models/operation-item.model';
import { OperationDetailModel } from '@core/models/operation-detail.model';
import { OperationUpsertModel } from '@core/models/operation-upsert.model';

@Injectable({
  providedIn: 'root',
})
export class ProjetService extends BaseService {
  
  // Fields.
  isGetAllProjetItemOK = false;
  isGetProjetItemOK = false;
  isGetProjetByIdOK = false;
  isAddProjetOk = false;
  isEditProjetOK = false;
  isDeleteProjetOK = false;
  
  currentProjet: any = null;
  projetUpdate: OperationDetailModel;
  projetAdd: OperationItemModel;

  getAllProjetItem(): Observable<any>  {
    return super.getAll<any[]>(`${GlobalConstants.uriProjetCtx}`)
                .pipe(
                  map((response) => {
                    this.isGetAllProjetItemOK = true;
                    var result = GlobalResponse.getResponse(response);
                    return result.data as OperationItemModel[];
                  }),
                  catchError(() => {
                    this.isGetAllProjetItemOK = false;
                    return of(GlobalResponse.handleError());
                  })
              );
          
  }

  getProjetItem(operationId: any): Observable<any> {
    return super.getAll<any[]>(`${GlobalConstants.uriProjetCtx}/GetProjetItem?operationId=${operationId}`)
                .pipe(
                  map((response) => {
                    this.isGetProjetItemOK = true;
                    var result = GlobalResponse.getResponse(response);
                    return result.data as OperationItemModel;
                  }),
                  catchError(() => {
                    this.isGetProjetItemOK = false;
                    return of(GlobalResponse.handleError());
                  })
              );
          
  }

  getProjetDetailById(operationId: any): Observable<any>  {
    return super.getAll<any[]>(`${GlobalConstants.uriProjetCtx}/${operationId}`)
                .pipe(
                  map((response) => {
                    this.isGetProjetByIdOK = true;
                    var result = GlobalResponse.getResponse(response);
                    return result.data as OperationDetailModel;
                  }),
                  catchError(() => {
                    this.isGetProjetByIdOK = false;
                    return of(GlobalResponse.handleError());
                  })
              );
          
  }

  addProjet(operation: OperationUpsertModel): Observable<any> {
    return super.post<OperationUpsertModel>(operation, `${GlobalConstants.uriProjetCtx}`)
                    .pipe(
                        map((response: any) => {
                          this.isAddProjetOk = true;
                          var result = GlobalResponse.getResponse(response);
                          this.projetAdd = result.data;
                          return result.data as OperationItemModel;
                        }),
                        catchError(() => {
                          this.isAddProjetOk = false;
                          return of(GlobalResponse.handleError());
                        })
                    );
                    
  }

  updateProjet(operation: OperationUpsertModel): Observable<any> {
    return super.put<OperationUpsertModel>(operation, `${GlobalConstants.uriProjetCtx}`)
                    .pipe(
                        map((response: any) => {
                          this.isEditProjetOK = true;
                          var result = GlobalResponse.getResponse(response);
                          this.projetUpdate = result.data;
                          return result.data as OperationDetailModel;
                        }),
                        catchError(() => {
                          this.isEditProjetOK = false;
                          return of(GlobalResponse.handleError());
                        })
                    );
                    
  }

  deleteProjet(operationId: string): Observable<any> {
    return super.delete(`${GlobalConstants.uriProjetCtx}?operationId=${operationId}`)
                    .pipe(
                      map((response: any) => {
                          this.isDeleteProjetOK = true;
                          return response.data;
                        }),
                        catchError(() => {
                          this.isDeleteProjetOK = false;
                          return of(GlobalResponse.handleError());
                        })
                    );
                    
  }

}
