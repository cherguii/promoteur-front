// import { Injectable } from '@angular/core';
// import { HttpClient } from '@angular/common/http';
// import { UnsubscribeOnDestroyAdapter } from '@shared';
// import { BehaviorSubject, catchError, map, Observable, of } from 'rxjs';
// import { GlobalConstants } from '@core/helpers/global-constants';
// import { GlobalResponse } from '@core/helpers/global-response';
// import { PatientModel } from '@core/models/patient.model';
// //import { PatientItemModel } from '@core/models/patient-item.model';

// @Injectable()
// export class PatientService extends UnsubscribeOnDestroyAdapter {

//   // Fields.
//   isGetAllPatientOk = false;
//   isAddPatientOk = false;
//   isEditPatientOK = false;
//   isDeletePatientOK = false;
//   isTblLoading = true;
//   dataChange: BehaviorSubject<PatientModel[]> = new BehaviorSubject<PatientModel[]>([]);
//   // Temporarily stores data from dialogs
//   dialogData!: PatientModel;
//   currentPatient: any = null;
//   patientAdd: PatientModel;
//   patientUpdate: PatientModel;

//   // Ctor.
//   constructor(private httpClient: HttpClient) {
//     super();
//   }

//   get data(): PatientModel[] {
//     return this.dataChange.value;
//   }

//   getDialogData() {
//     return this.dialogData;
//   }
  
//   /** CRUD METHODS */
//   getAllPatient(): void {
//     this.subs.sink = this.httpClient.get<any[]>(`${GlobalConstants.uriPatientCtx}`)
//           .subscribe({
//             next: (response: any) => {

//                 this.isTblLoading = false;
//                 this.isGetAllPatientOk = true;

//                 var patientsTemp = new Array<PatientModel>();
//                 patientsTemp = response.data;
//                 var patients = new Array<any>();
  
//                 patientsTemp.forEach(element => {
//                   var patient = {
//                     docteurId: element.docteurId,
//                     patientId: element.patientId,
//                     genreCode: element.genreCode,
//                     nom: element.nom,
//                     prenom: element.prenom,
//                     telephoneMobile: element.telephoneMobile,
//                     numero: element.numero,
//                     statusLibelle: element.statusLibelle,
//                     statusCode: element.statusCode,
//                     docteurNomPrenom: element.docteurNomPrenom,
//                     rendezVousStatusCode: element.rendezVousStatusCode,
//                     rendezVousDate: element.rendezVousDate,
//                     heureRendezVous: element.heureRendezVous,
//                   };
//                   patients.push(patient);
//                 });
//                 this.dataChange.next(patients);
//             },
//             error: () => {
//               this.isGetAllPatientOk = true;
//               this.isTblLoading = false;
//               this.dataChange.next(new Array<PatientModel>());
//               return of(GlobalResponse.handleError());
//             },
//           });
          
//   }  

//   addPatient(patient: PatientModel): Observable<any> {
//     return this.httpClient.post<PatientModel>(`${GlobalConstants.uriPatientCtx}`, patient)
//                     .pipe(
//                         map((response: any) => {
//                             this.isTblLoading = false;
//                             this.isAddPatientOk = true;
//                             this.dialogData = response.data;
//                             this.patientAdd = response.data;
//                             return response.data;
//                         }),
//                         catchError(() => {
//                             this.isAddPatientOk = false;
//                             this.isTblLoading = false;
//                             return of(GlobalResponse.handleError());
//                         })
//                     );
                    
//   }

//   updatePatient(patient: PatientModel): Observable<any> {
//     return this.httpClient.put<PatientModel>(`${GlobalConstants.uriPatientCtx}`, patient)
//                     .pipe(
//                         map((response: any) => {
//                             this.isTblLoading = false;
//                             this.isEditPatientOK = true;
//                             //var result = GlobalResponse.getResponse(response);
//                             this.dialogData = response.data;
//                             this.patientUpdate = response.data;
//                             return response.data;;
//                         }),
//                         catchError(() => {
//                             this.isEditPatientOK = false;
//                             this.isTblLoading = false;
//                             return of(GlobalResponse.handleError());
//                         })
//                     );
                    
//   }

//   deletePatient(patientId: string): Observable<any> {
//     return this.httpClient.delete(`${GlobalConstants.uriPatientCtx}?id=${patientId}`)
//                     .pipe(
//                       map((response: any) => {
//                         this.isTblLoading = false;
//                             this.isDeletePatientOK = true;
//                             return response.data;
//                         }),
//                         catchError(() => {
//                           this.isTblLoading = false;
//                             this.isDeletePatientOK = false;
//                             return of(GlobalResponse.handleError());
//                         })
//                     );
                    
//   }
// }
