import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { UnsubscribeOnDestroyAdapter } from '@shared';
import { catchError, map, Observable, of } from 'rxjs';
import { GlobalConstants } from '@core/helpers/global-constants';
import { GlobalResponse } from '@core/helpers/global-response';
import { ImmeubleItemModel } from '@core/models/immeuble-item.model';
import { ImmeubleDetailModel } from '@core/models/immeuble-detail.model';
import { ImmeubleUpsertModel } from '@core/models/immeuble-upsert.model';

@Injectable()
export class ImmeubleService extends UnsubscribeOnDestroyAdapter {

  // Fields.
  isGetImmeubleDetailByIdOK = false;
  isGetImmeublesByOperationIdOK = false;
  isAddImmeubleOk = false;
  isEditImmeubleOK = false;
  isDeleteImmeubleOK = false;
  
  currentImmeuble: any = null;
  immeubleAdd: ImmeubleItemModel;
  immeubleUpdate: ImmeubleDetailModel;

  // Ctor.
  constructor(private httpClient: HttpClient) {
    super();
  }

  getImmeubleDetailById(operationId: any, immeubleId: any): Observable<any>  {
    return this.httpClient.get(`${GlobalConstants.uriImmeubleCtx}/getImmeubleDetailById?&operationId=${operationId}&immeubleId=${immeubleId}`)
              .pipe(
                map((response: any) => {
                    this.isGetImmeubleDetailByIdOK = true;
                    return response.data as ImmeubleItemModel;
                }),
                catchError(() => {
                    this.isGetImmeubleDetailByIdOK = false;
                    return of(GlobalResponse.handleError());
                })
            );
  }

  getImmeublesByOperationId(operationId: any): Observable<any>  {
    return this.httpClient.get(`${GlobalConstants.uriImmeubleCtx}/getImmeublesByOperationId?operationId=${operationId}`)
              .pipe(
                map((response: any) => {
                    this.isGetImmeublesByOperationIdOK = true;
                    return response.data as ImmeubleItemModel;
                }),
                catchError(() => {
                    this.isGetImmeublesByOperationIdOK = false;
                    return of(GlobalResponse.handleError());
                })
            );
  }

  addImmeuble(immeuble: ImmeubleUpsertModel): Observable<any> {
    return this.httpClient.post<ImmeubleUpsertModel>(`${GlobalConstants.uriImmeubleCtx}`, immeuble)
                    .pipe(
                        map((response: any) => {
                            //this.isTblLoading = false;
                            this.isAddImmeubleOk = true;
                            this.immeubleAdd = response.data;
                            return response.data;
                        }),
                        catchError(() => {
                            this.isAddImmeubleOk = false;
                            //this.isTblLoading = false;
                            return of(GlobalResponse.handleError());
                        })
                    );
                    
  }

  updateImmeuble(immeuble: ImmeubleUpsertModel): Observable<any> {
    return this.httpClient.put<ImmeubleUpsertModel>(`${GlobalConstants.uriImmeubleCtx}`, immeuble)
                    .pipe(
                        map((response: any) => {
                            //this.isTblLoading = false;
                            this.isEditImmeubleOK = true;
                            this.immeubleUpdate = response.data;
                            return response.data;
                        }),
                        catchError(() => {
                            this.isEditImmeubleOK = false;
                            //this.isTblLoading = false;
                            return of(GlobalResponse.handleError());
                        })
                    );
                    
  }

  deleteImmeuble(operationId: string, immeubleId: string): Observable<any> {
    return this.httpClient.delete(`${GlobalConstants.uriImmeubleCtx}?operationId=${operationId}&immeubleId=${immeubleId}`)
                    .pipe(
                      map((response: any) => {
                        //this.isTblLoading = false;
                          this.isDeleteImmeubleOK = true;
                          return response.data;
                        }),
                        catchError(() => {
                          //this.isTblLoading = false;
                          this.isDeleteImmeubleOK = false;
                          return of(GlobalResponse.handleError());
                        })
                    );
                    
  }

  
}
