// import { Injectable } from '@angular/core';
// import { formatDate } from '@angular/common';
// import { HttpClient } from '@angular/common/http';
// import { UnsubscribeOnDestroyAdapter } from '@shared';
// import { BehaviorSubject, catchError, map, Observable, of } from 'rxjs';
// import { GlobalConstants } from '@core/helpers/global-constants';
// import { DocteurDetail } from '@core/models/docteur-detail.model';
// import { GlobalResponse } from '@core/helpers/global-response';

// @Injectable()
// export class DocteurService extends UnsubscribeOnDestroyAdapter {

//   // Fields.
//   isGetAllDocteurOk = false;
//   isAddDocteurOk = false;
//   isEditDocteurOK = false;
//   isDeleteDocteurOK = false;
//   isTblLoading = true;
//   dataChange: BehaviorSubject<DocteurDetail[]> = new BehaviorSubject<DocteurDetail[]>([]);
//   // Temporarily stores data from dialogs
//   dialogData!: DocteurDetail;
//   currentDocteur: any = null;
//   docteurAdd: DocteurDetail;
//   docteurUpdate: DocteurDetail;

//   // Ctor.
//   constructor(private httpClient: HttpClient) {
//     super();
//   }

//   get data(): DocteurDetail[] {
//     return this.dataChange.value;
//   }

//   getDialogData() {
//     return this.dialogData;
//   }
  
//   /** CRUD METHODS */
//   getAllDoctors(): void {
//     this.subs.sink = this.httpClient.get<any[]>(`${GlobalConstants.uriDocteurCtx}`)
//           .subscribe({
//             next: (response: any) => {

//                 this.isTblLoading = false;
//                 this.isGetAllDocteurOk = true;

//                 var docteursTemp = new Array<DocteurDetail>();
//                 docteursTemp = response.data;
//                 var docteurs = new Array<any>();
  
//                 docteursTemp.forEach(element => {
//                   var docteur = {
//                     //cabinetId: element.cabinetId,
//                     docteurId: element.docteurId,
//                     civiliteCode: element.civiliteCode,
//                     isActif: element.isActif,
//                     nom: element.nom,
//                     prenom: element.prenom || '',
//                     specialiteCode: element.specialiteCode || 1,
//                     specialiteLibelle: element.specialiteLibelle || '',
//                     photo: element.photo === null || element.photo === '' ? 'assets/images/user/avatar.png' : element.photo,
//                     dureeConsultation: element.dureeConsultation || '',

//                     lundiStart: element.lundiStart || '',
//                     lundiEnd: element.lundiEnd || '',
//                     mardiStart: element.mardiStart || '',
//                     mardiEnd: element.mardiEnd || '',
//                     mercrediStart: element.mercrediStart || '',
//                     mercrediEnd: element.mercrediEnd || '',
//                     jeudiStart: element.jeudiStart || '',
//                     jeudiEnd: element.jeudiEnd || '',
//                     vendrediStart: element.vendrediStart || '',
//                     vendrediEnd: element.vendrediEnd || '',
//                     samediStart: element.samediStart || '',
//                     samediEnd: element.samediEnd || '',
//                     dimancheStart: element.dimancheStart || '',
//                     dimancheEnd: element.dimancheEnd || '',
//                     createdDate: element.createdDate || formatDate(new Date(), 'yyyy-MM-dd', 'en')
//                   };
//                   docteurs.push(docteur);
//                 });
//                 this.dataChange.next(docteurs);
//             },
//             error: () => {
//               this.isGetAllDocteurOk = true;
//               this.isTblLoading = false;
//               this.dataChange.next(new Array<DocteurDetail>());
//               return of(GlobalResponse.handleError());
//             },
//           });
          
//   }

//   getAllDocteurItem(): Observable<any>  {
//     return this.httpClient.get<DocteurDetail[]>(`${GlobalConstants.uriDocteurCtx}`)
//                 .pipe(
//                     map((response: any) => {
//                         this.isGetAllDocteurOk = true;
//                         return response.data;
//                     }),
//                     catchError(() => {
//                         this.isGetAllDocteurOk = false;
//                         return of(GlobalResponse.handleError());
//                     })
//                 );
//   }

//   addDocteur(docteur: DocteurDetail): Observable<any> {
//     return this.httpClient.post<DocteurDetail>(`${GlobalConstants.uriDocteurCtx}`, docteur)
//                     .pipe(
//                         map((response: any) => {
//                             this.isTblLoading = false;
//                             this.isAddDocteurOk = true;
//                             this.dialogData = response.data;
//                             this.docteurAdd = response.data;
//                             return response.data;
//                         }),
//                         catchError(() => {
//                             this.isAddDocteurOk = false;
//                             this.isTblLoading = false;
//                             return of(GlobalResponse.handleError());
//                         })
//                     );
                    
//   }

//   updateDoctors(docteur: DocteurDetail): Observable<any> {
//     return this.httpClient.put<DocteurDetail>(`${GlobalConstants.uriDocteurCtx}`, docteur)
//                     .pipe(
//                         map((response: any) => {
//                             this.isTblLoading = false;
//                             this.isEditDocteurOK = true;
//                             this.dialogData = response.data;
//                             this.docteurUpdate = response.data;
//                             return response.data;;
//                         }),
//                         catchError(() => {
//                             this.isEditDocteurOK = false;
//                             this.isTblLoading = false;
//                             return of(GlobalResponse.handleError());
//                         })
//                     );
                    
//   }

//   deleteDocteur(docteurId: string): Observable<any> {
//     return this.httpClient.delete(`${GlobalConstants.uriDocteurCtx}?id=${docteurId}`)
//                     .pipe(
//                       map((response: any) => {
//                         this.isTblLoading = false;
//                             this.isDeleteDocteurOK = true;
//                             return response.data;
//                         }),
//                         catchError(() => {
//                           this.isTblLoading = false;
//                             this.isDeleteDocteurOK = false;
//                             return of(GlobalResponse.handleError());
//                         })
//                     );
                    
//   }
// }
