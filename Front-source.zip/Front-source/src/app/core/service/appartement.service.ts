import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { UnsubscribeOnDestroyAdapter } from '@shared';
import { catchError, map, Observable, of } from 'rxjs';
import { GlobalConstants } from '@core/helpers/global-constants';
import { GlobalResponse } from '@core/helpers/global-response';
import { AppartementModel } from '@core/models/appartement.model';

@Injectable()
export class AppartementService extends UnsubscribeOnDestroyAdapter {

  // Fields.
  isGetAppartementsByOperationIdAndImmeubleIdOK = false;
  isAddAppartementOk = false;
  isEditAppartementOK = false;
  isDeleteAppartementOK = false;

  currentAppartement: any = null;
  appartementAdd: AppartementModel;
  appartementUpdate: AppartementModel;

  // Ctor.
  constructor(private httpClient: HttpClient) {
    super();
  }

  getAppartementsByOperationIdAndImmeubleId(operationId: any, immeubleId: any): Observable<any> {
    return this.httpClient.get(`${GlobalConstants.uriAppartementCtx}/getAppartementsByOperationIdAndImmeubleId?operationId=${operationId}&immeubleId=${immeubleId}`)
                    .pipe(
                        map((response: any) => {
                            this.isGetAppartementsByOperationIdAndImmeubleIdOK = true;
                            return response.data as AppartementModel;
                        }),
                        catchError(() => {
                            this.isGetAppartementsByOperationIdAndImmeubleIdOK = false;
                            return of(GlobalResponse.handleError());
                        })
                    );
  }

  addAppartement(appartement: AppartementModel): Observable<any> {
    return this.httpClient.post<AppartementModel>(`${GlobalConstants.uriAppartementCtx}`, appartement)
                    .pipe(
                        map((response: any) => {
                            this.isAddAppartementOk = true;
                            this.appartementAdd = response.data;
                            return response.data;
                        }),
                        catchError(() => {
                            this.isAddAppartementOk = false;
                            return of(GlobalResponse.handleError());
                        })
                    );
                    
  }

  updateAppartement(appartement: AppartementModel): Observable<any> {
    return this.httpClient.put<AppartementModel>(`${GlobalConstants.uriAppartementCtx}`, appartement)
                    .pipe(
                        map((response: any) => {
                            this.isEditAppartementOK = true;
                            this.appartementUpdate = response.data;
                            return response.data;
                        }),
                        catchError(() => {
                            this.isEditAppartementOK = false;
                            return of(GlobalResponse.handleError());
                        })
                    );
                    
  }

  deleteAppartement(operationId: string, immeubleId: string, appartementId: string): Observable<any> {
    return this.httpClient.delete(`${GlobalConstants.uriAppartementCtx}?&operationId=${operationId}&immeubleId=${immeubleId}&appartementId=${appartementId}`)
                    .pipe(
                      map((response: any) => {
                          this.isDeleteAppartementOK = true;
                          return response.data;
                        }),
                        catchError(() => {
                          this.isDeleteAppartementOK = false;
                          return of(GlobalResponse.handleError());
                        })
                    );
                    
  }

}
