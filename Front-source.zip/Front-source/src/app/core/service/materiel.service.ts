import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { UnsubscribeOnDestroyAdapter } from '@shared';
import { BehaviorSubject, catchError, map, Observable, of } from 'rxjs';
import { GlobalConstants } from '@core/helpers/global-constants';
import { GlobalResponse } from '@core/helpers/global-response';
import { MaterielModel } from '@core/models/materiel.model';

@Injectable()
export class MaterielService extends UnsubscribeOnDestroyAdapter {

  // Fields.
  isGetAllMaterielOk = false;
  isGetAllMaterielForActiviteOK = false;
  isGetQuantiteQuiResteEnStockOK = false;
  isAddMaterielOk = false;
  isEditMaterielOK = false;
  isDeleteMaterielOK = false;
  isTblLoading = true;
  dataChange: BehaviorSubject<MaterielModel[]> = new BehaviorSubject<MaterielModel[]>([]);
  dialogData!: MaterielModel;
  currentMateriel: any = null;
  materielAdd: MaterielModel;
  materielUpdate: MaterielModel;

  // Ctor.
  constructor(private httpClient: HttpClient) {
    super();
  }

  get data(): MaterielModel[] {
    return this.dataChange.value;
  }

  getDialogData() {
    return this.dialogData;
  }
  
  /** CRUD METHODS */
  getAllMateriel(): void {
    this.subs.sink = this.httpClient.get<any[]>(`${GlobalConstants.uriMaterielCtx}`)
          .subscribe({
            next: (response: any) => {
                this.isTblLoading = false;
                this.isGetAllMaterielOk = true;

                var materielsTemp = new Array<MaterielModel>();
                materielsTemp = response.data;
                var materiels = new Array<any>();
  
                materielsTemp.forEach(element => {
                  var materiel = {
                    materielId: element.materielId,
                    libelle: element.libelle,
                    prixUnitaire: element.prixUnitaire,
                    tva: element.tva,
                    quantiteInitial: element.quantiteInitial,
                  };
                  materiels.push(materiel);
                });
                this.dataChange.next(materiels);
            },
            error: () => {
              this.isGetAllMaterielOk = true;
              this.isTblLoading = false;
              this.dataChange.next(new Array<MaterielModel>());
              return of(GlobalResponse.handleError());
            },
          });
          
  }

  getAllMaterielForActivite(): Observable<any> {
    return this.httpClient.get<any[]>(`${GlobalConstants.uriMaterielCtx}`)
                    .pipe(
                        map((response: any) => {
                            this.isGetAllMaterielForActiviteOK = true;
                            return response.data as any[];
                        }),
                        catchError(() => {
                            this.isGetAllMaterielForActiviteOK = false;
                            return of(GlobalResponse.handleError());
                        })
                    );
          
  } 

  getQuantiteQuiResteEnStock(materielId: any): Observable<any> {
    return this.httpClient.get(`${GlobalConstants.uriMaterielCtx}/getQuantiteQuiResteEnStock?materielId=${materielId}`)
              .pipe(
                map((response: any) => {
                    this.isGetQuantiteQuiResteEnStockOK = true;
                    return response.data;
                }),
                catchError(() => {
                    this.isGetQuantiteQuiResteEnStockOK = false;
                    return of(GlobalResponse.handleError());
                })
            );
            
  }

  addMateriel(materiel: MaterielModel): Observable<any> {
    return this.httpClient.post<MaterielModel>(`${GlobalConstants.uriMaterielCtx}`, materiel)
                    .pipe(
                        map((response: any) => {
                            this.isTblLoading = false;
                            this.isAddMaterielOk = true;
                            this.dialogData = response.data;
                            this.materielAdd = response.data;
                            return response.data;
                        }),
                        catchError(() => {
                            this.isAddMaterielOk = false;
                            this.isTblLoading = false;
                            return of(GlobalResponse.handleError());
                        })
                    );
                    
  }

  updateMateriel(materiel: MaterielModel): Observable<any> {
    return this.httpClient.put<MaterielModel>(`${GlobalConstants.uriMaterielCtx}`, materiel)
                    .pipe(
                        map((response: any) => {
                            this.isTblLoading = false;
                            this.isEditMaterielOK = true;
                            //var result = GlobalResponse.getResponse(response);
                            this.dialogData = response.data;
                            this.materielUpdate = response.data;
                            return response.data;;
                        }),
                        catchError(() => {
                            this.isEditMaterielOK = false;
                            this.isTblLoading = false;
                            return of(GlobalResponse.handleError());
                        })
                    );
                    
  }

  deleteMateriel(materielId: string): Observable<any> {
    return this.httpClient.delete(`${GlobalConstants.uriMaterielCtx}?id=${materielId}`)
                    .pipe(
                      map((response: any) => {
                        this.isTblLoading = false;
                            this.isDeleteMaterielOK = true;
                            return response.data;
                        }),
                        catchError(() => {
                          this.isTblLoading = false;
                            this.isDeleteMaterielOK = false;
                            return of(GlobalResponse.handleError());
                        })
                    );
                    
  }
}
