import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { UnsubscribeOnDestroyAdapter } from '@shared';
import { BehaviorSubject, catchError, map, Observable, of } from 'rxjs';
import { GlobalConstants } from '@core/helpers/global-constants';
import { GlobalResponse } from '@core/helpers/global-response';
import { SousTraitantModel } from '@core/models/sous-traitant.model';

@Injectable()
export class SousTraitantService extends UnsubscribeOnDestroyAdapter {

  // Fields.
  isGetAllSousTraitantOk = false;
  isAddSousTraitantOk = false;
  isEditSousTraitantOK = false;
  isDeleteSousTraitantOK = false;
  isGetAllSousTraitantForActiviteOK = false;
  isTblLoading = true;
  dataChange: BehaviorSubject<SousTraitantModel[]> = new BehaviorSubject<SousTraitantModel[]>([]);
  // Temporarily stores data from dialogs
  dialogData!: SousTraitantModel;
  currentSousTraitant: any = null;
  sousTraitantAdd: SousTraitantModel;
  sousTraitantUpdate: SousTraitantModel;

  // Ctor.
  constructor(private httpClient: HttpClient) {
    super();
  }

  get data(): SousTraitantModel[] {
    return this.dataChange.value;
  }

  getDialogData() {
    return this.dialogData;
  }
  
  /** CRUD METHODS */
  getAllSousTraitant(): void {
    this.subs.sink = this.httpClient.get<any[]>(`${GlobalConstants.uriSousTraitantCtx}`)
          .subscribe({
            next: (response: any) => {

                this.isTblLoading = false;
                this.isGetAllSousTraitantOk = true;

                var sousTraitantsTemp = new Array<SousTraitantModel>();
                sousTraitantsTemp = response.data;
                var sousTraitants = new Array<any>();
  
                sousTraitantsTemp.forEach(element => {
                  var sousTraitant = {
                    sousTraitantId: element.sousTraitantId,
                    nomSociete: element.nomSociete,
                    nomGerant: element.nomGerant,
                    telephoneGerant: element.telephoneGerant,
                    sousTraitantTypeCode: element.sousTraitantTypeCode,
                    sousTraitantTypeLibelle: element.sousTraitantTypeLibelle
                  };
                  sousTraitants.push(sousTraitant);
                });
                this.dataChange.next(sousTraitants);
            },
            error: () => {
              this.isGetAllSousTraitantOk = true;
              this.isTblLoading = false;
              this.dataChange.next(new Array<SousTraitantModel>());
              return of(GlobalResponse.handleError());
            },
          });
          
  }

  getAllSousTraitantForActivite(): Observable<any> {
    return this.httpClient.get<any[]>(`${GlobalConstants.uriSousTraitantCtx}`)
                    .pipe(
                        map((response: any) => {
                            this.isGetAllSousTraitantForActiviteOK = true;
                            //var result = GlobalResponse.getResponse(response);
                            return response.data as any[];
                        }),
                        catchError(() => {
                            this.isGetAllSousTraitantForActiviteOK = false;
                            return of(GlobalResponse.handleError());
                        })
                    );
          
  } 

  addSousTraitant(sousTraitant: SousTraitantModel): Observable<any> {
    return this.httpClient.post<SousTraitantModel>(`${GlobalConstants.uriSousTraitantCtx}`, sousTraitant)
                    .pipe(
                        map((response: any) => {
                            this.isTblLoading = false;
                            this.isAddSousTraitantOk = true;
                            this.dialogData = response.data;
                            this.sousTraitantAdd = response.data;
                            return response.data;
                        }),
                        catchError(() => {
                            this.isAddSousTraitantOk = false;
                            this.isTblLoading = false;
                            return of(GlobalResponse.handleError());
                        })
                    );
                    
  }

  updateSousTraitant(sousTraitant: SousTraitantModel): Observable<any> {
    return this.httpClient.put<SousTraitantModel>(`${GlobalConstants.uriSousTraitantCtx}`, sousTraitant)
                    .pipe(
                        map((response: any) => {
                            this.isTblLoading = false;
                            this.isEditSousTraitantOK = true;
                            //var result = GlobalResponse.getResponse(response);
                            this.dialogData = response.data;
                            this.sousTraitantUpdate = response.data;
                            return response.data;;
                        }),
                        catchError(() => {
                            this.isEditSousTraitantOK = false;
                            this.isTblLoading = false;
                            return of(GlobalResponse.handleError());
                        })
                    );
                    
  }

  deleteSousTraitant(sousTraitantId: string): Observable<any> {
    return this.httpClient.delete(`${GlobalConstants.uriSousTraitantCtx}?sousTraitantId=${sousTraitantId}`)
                    .pipe(
                      map((response: any) => {
                        this.isTblLoading = false;
                            this.isDeleteSousTraitantOK = true;
                            return response.data;
                        }),
                        catchError(() => {
                          this.isTblLoading = false;
                            this.isDeleteSousTraitantOK = false;
                            return of(GlobalResponse.handleError());
                        })
                    );
                    
  }
}
