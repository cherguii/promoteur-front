import { Injectable } from '@angular/core';
import { Router, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';

import { AuthService } from '../service/auth.service';

@Injectable({
  providedIn: 'root',
})
export class AuthGuard  {
  constructor(private authService: AuthService, private router: Router) {}

  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
    // const roles = localStorage.getItem('user_roles');
    // if (route.data.roles && route.data.roles.indexOf(roles) === -1) {
    //   // role not authorised so redirect to home page
    //   this.router.navigate(['/pages/home']);
    //   return false;
    // }

    const accessToken = localStorage.getItem('access_token');
    if (accessToken === null || accessToken === '') {
      this.router.navigate(['/authentication/signin']);
      return false;
    }
    return true;

    // if (this.authService.currentUserValue) {
    //   const userRole = this.authService.currentUserValue.role;
    //   if (route.data['role'] && route.data['role'].indexOf(userRole) === -1) {
    //     this.router.navigate(['/signin']);
    //     return false;
    //   }
    //   return true;
    // }

    // this.router.navigate(['/signin']);
    // return false;
  }
}
