import { environment } from "environments/environment";

// une class pour gérer toutes les constantes front
export class GlobalConstants {

  // Endpoints
  static uriAuthentificationCtx: string = environment.apiBaseURL + "/Authentification";
  static uriReferentialCtx: string = environment.apiBaseURL + "/Referential";
  static uriMaterielCtx: string = environment.apiBaseURL + "/Materiel";
  static uriActiviteTypeCtx: string = environment.apiBaseURL + "/ActiviteType";
  
  static uriProjetCtx: string = environment.apiBaseURL + "/Projet";
  static uriPlanningTravauxCtx: string = environment.apiBaseURL + "/PlanningTravaux";
  
  static uriImmeubleCtx: string = environment.apiBaseURL + "/Immeuble";
  static uriAppartementCtx: string = environment.apiBaseURL + "/Appartement";
  static uriSousTraitantCtx: string = environment.apiBaseURL + "/SousTraitant";

  static specialiteStorageCtx :string= "specialites";
  static groupeSanguinStorageCtx :string= "groupeSanguins";
  
}
