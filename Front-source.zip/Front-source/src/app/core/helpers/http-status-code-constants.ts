
export class HttpStatusCode {
  static OK: number = 200;
  static NotFound: number = 404;
  static BadRequest: number = 400;
  static InternalServerError: number = 500;  
}
