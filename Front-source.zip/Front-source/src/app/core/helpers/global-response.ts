import { HttpStatusCode } from './http-status-code-constants';
import { HttpErrorResponse } from '@angular/common/http';
import { GlobalResponseModel } from '@core/models/global-response.model';

export class GlobalResponse {

  // Fields.
  static httpErrorResponse: HttpErrorResponse;
  static failureResponseMessage: string = 'Le serveur distant ne répond pas. veuillez contacter votre administrateur';

  // Retourner un objet 'GlobalResponseModel'.
  static getResponse(httpResponse: any){
    var response = new GlobalResponseModel();
    if (httpResponse.status === HttpStatusCode.OK) {
      response.data = httpResponse.body.data;
      return response;
    } else {
      response.data = null;
      response.message = httpResponse.body.error;
      return response;
    }
  }

  static handleError() {
    console.log(this.httpErrorResponse.error);
    var response = new GlobalResponseModel();
    if (this.httpErrorResponse.status === HttpStatusCode.NotFound || 
      this.httpErrorResponse.status   === HttpStatusCode.BadRequest || 
      this.httpErrorResponse.status   === HttpStatusCode.InternalServerError) {
      response.data = null;
      response.message = this.httpErrorResponse.error.message;
      return response;
    } else {
      response.data = null;
      response.message = this.failureResponseMessage;
      return response;
    }
  }

  static SetHttpErrorResponse(httpErrorResponse: HttpErrorResponse) {
    this.httpErrorResponse = httpErrorResponse;
  }
  
}