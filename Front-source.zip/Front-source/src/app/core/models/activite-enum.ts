export enum ActiviteEnum {
  OPERATION = 1,
  IMMEUBLE = 2,
  APPARTEMENT = 3
}
