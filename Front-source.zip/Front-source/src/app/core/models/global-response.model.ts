
export class GlobalResponseModel {
  message: string;
  data: any;
}