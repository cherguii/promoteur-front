
export class MaterielTask {
  materielId: string;
  libelle: string;
  //quantiteEnStock: number;
  quantite: number;
  prixUnitaire: number;
  tva: number;
  //prixUnitaireTTC: number;
  //prixTotal: number;
  commentaire: string;
}