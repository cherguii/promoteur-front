export class LoginResult {
  id: string;
  username: string;
  password: string;
  photo: string;
  nomCabinet: string;
  roles: string[];
  accessToken: string;
  refreshToken: string;
  isAuthenticated: boolean;
}
