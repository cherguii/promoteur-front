
export class RendezVousStatus {
  static EnAttenteCode: number = 1;
  static EnCoursCode: number = 2;
  static TermineCode: number = 3;
  static AbsentCode: number = 4;

  static EnAttenteLibelle: string = "En Attente";
  static EnCoursLibelle: string = "En cours";
  static TermineLibelle: string = "Terminé";
  static AbsentLibelle: string = "Absent";
}
