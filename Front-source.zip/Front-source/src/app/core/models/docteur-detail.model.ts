import { formatDate } from "@angular/common";

export class DocteurDetail {

  //cabinetId: string;
  docteurId: string;
  civiliteCode: number;
  isActif: boolean;
  nom: string;
  prenom: string
  specialiteCode: number;
  specialiteLibelle: string;
  photo: string;
  dureeConsultation: number;

  lundiStart: string;
  lundiEnd: string;
  mardiStart: string;
  mardiEnd: string;
  mercrediStart: string;
  mercrediEnd: string;
  jeudiStart: string;
  jeudiEnd: string;
  vendrediStart: string;
  vendrediEnd: string;
  samediStart: string;
  samediEnd: string;
  dimancheStart: string;
  dimancheEnd: string;
  createdDate: Date;

  //  // Ctor.
  //  constructor(docteur: DocteurDetail) {
  //   {
  //     this.cabinetId = docteur.cabinetId || '';
  //     this.docteurId = docteur.docteurId || '';
  //     this.civiliteCode = docteur.civiliteCode || 1;
  //     this.nom = docteur.nom || '';
  //     this.prenom = docteur.prenom || '';
  //     this.specialiteCode = docteur.specialiteCode || 1;
  //     this.specialiteLibelle = docteur.specialiteLibelle || '';
  //     this.photo = docteur.photo || 'assets/images/user/avatar.png';

  //     this.honoraire = docteur.specialiteLibelle || '';
  //     this.lundiStart = docteur.specialiteLibelle || '';
  //     this.lundiEnd = docteur.specialiteLibelle || '';
  //     this.mardiStart = docteur.specialiteLibelle || '';
  //     this.mardiEnd = docteur.specialiteLibelle || '';
  //     this.mercrediStart = docteur.specialiteLibelle || '';
  //     this.mercrediEnd = docteur.specialiteLibelle || '';
  //     this.jeudiStart = docteur.specialiteLibelle || '';
  //     this.jeudiEnd = docteur.specialiteLibelle || '';
  //     this.vendrediStart = docteur.specialiteLibelle || '';
  //     this.vendrediEnd = docteur.specialiteLibelle || '';
  //     this.samediStart = docteur.specialiteLibelle || '';
  //     this.samediEnd = docteur.specialiteLibelle || '';
  //     this.dimancheStart = docteur.specialiteLibelle || '';
  //     this.dimancheEnd = docteur.specialiteLibelle || '';

  //     this.createdDate = docteur.createdDate || formatDate(new Date(), 'yyyy-MM-dd', 'en');
  //   }
  // }

  
}
