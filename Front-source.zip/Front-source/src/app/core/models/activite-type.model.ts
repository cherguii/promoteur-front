
export class ActiviteTypeModel {
  activiteTypeId: string;
  libelle: string;
  order: number;
  createdDate: Date;
}