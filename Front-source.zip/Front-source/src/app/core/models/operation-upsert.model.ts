
export class OperationUpsertModel {
  operationId: string;
  nom: string;
  adresse: string;
  ville: string;
  surfaceTotal: number;
  statusCode: number;
  statusLibelle: string;
  demarrageDate: string;
  finDate: string;
  photos: string[];
}