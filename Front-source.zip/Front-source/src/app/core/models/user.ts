import { Role } from './role';

export class User {
  id: string;
  photo!: string;
  username!: string;
  password!: string;
  nomCabinet!: string;
  //lastName!: string;
  //role!: Role;
  role!: string;
  //token!: string;
  accessToken!:string;
  refreshToken!: string;
  isAuthenticated!: boolean;
}
