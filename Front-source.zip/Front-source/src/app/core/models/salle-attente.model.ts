import { PatientModel } from "./patient.model";

export class SalleAttenteModel {

  //cabinetId: string;
  docteurId: string;
  
  nomCabinet: string;
  nomDocteur: string;
  prenomDocteur: string
  specialiteLibelle: string;
  photoDocteur: string;
  adresseDocteur: string;
  villeDocteur: string;
  telephoneDocteur: string;

  enAttenteCount: number;
  absentCount: number;
  termineCount: number;

  rendezVousDate: Date;  
  //createdDate: Date;

  patientEnCour: PatientModel;
  patientsEnAttente: Array<PatientModel>;
  patientsTermine: Array<PatientModel>;
}

export class NextPreviousPatientModel {

  cabinetId: string;
  docteurId: string;
  //isNextPatient: boolean;

  rendezVousDate: Date;  
  createdDate: Date;  

  patientEnCours: PatientModel;

  patientsEnAttente: Array<PatientModel>;
  patientsTermine: Array<PatientModel>;
}