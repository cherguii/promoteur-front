
export interface SpecialiteModel {
  code : number;
  libelle : string;
}

// export interface GroupeSanguinModel {
//   code : number;
//   libelle : string;
// }
