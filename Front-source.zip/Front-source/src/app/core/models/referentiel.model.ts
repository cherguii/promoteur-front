
export class ReferentielModel {
  referentielId: string;
  code : number;
  libelle : string;
  createdDate: Date;
}