import { formatDate } from "@angular/common";

export class Docteur {

  cabinetId: string;
  docteurId: string;
  civiliteCode: number;
  nom: string;
  prenom: string
  specialiteCode: number;
  specialiteLibelle: string;
  photo: string;
  createdDate: Date;

  // Ctor.
  constructor(docteur: Docteur) {
    {
      this.cabinetId = docteur.cabinetId || '';
      this.docteurId = docteur.docteurId || '';
      this.civiliteCode = docteur.civiliteCode || 1;
      this.nom = docteur.nom || '';
      this.prenom = docteur.prenom || '';
      this.specialiteCode = docteur.specialiteCode || 1;
      this.specialiteLibelle = docteur.specialiteLibelle || '';
      this.photo = docteur.photo || 'assets/images/user/avatar.png';
      this.createdDate = docteur.createdDate || formatDate(new Date(), 'yyyy-dd-MM', 'en');
    }
  }
  
  // public getRandomID(): number {
  //   const S4 = () => {
  //     return ((1 + Math.random()) * 0x10000) | 0;
  //   };
  //   return S4() + S4();
  // }
}
