
export class PatientModel {
  docteurId: string;
  patientId: string;
  genreCode: number;
  nom: string;
  prenom: string;
  telephoneMobile: string;
  numero: number;
  statusLibelle: string;
  statusCode: number;
  docteurNomPrenom: string;
  rendezVousStatusCode: number;
  rendezVousDate: string;
  heureRendezVous: string;
  createdDate: Date;
}