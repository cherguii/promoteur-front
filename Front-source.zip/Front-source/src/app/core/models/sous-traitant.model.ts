
export class SousTraitantModel {
  sousTraitantId : string;
  nomSociete : string;
  nomGerant : string;
  telephoneGerant: string;
  sousTraitantTypeCode : number;
  sousTraitantTypeLibelle : string;
}