import { ImmeubleItemModel } from "./immeuble-item.model";

export class OperationDetailModel {
  operationId: string;
  nom: string;
  adresse: string;
  ville: string;
  surfaceTotal: number;
  demarrageDate: string;
  finDate: string;
  livraisonDate: string;
  statusCode: number;
  statusLibelle: string;
  createdDate: Date;
  photos: string[];
  immeubles: ImmeubleItemModel[];
  //coutTotalTTC: number;
}