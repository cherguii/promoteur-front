
export class MaterielModel {
  materielId: string;
  libelle: string;
  quantiteInitial: number;
  tva: number;
  prixUnitaire: number;
  createdDate: Date;
}