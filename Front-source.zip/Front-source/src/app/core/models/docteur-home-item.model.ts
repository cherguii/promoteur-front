
export class DocteurHomeItem {

  cabinetId: string;
  docteurId: string;
  nom: string;
  prenom: string
  patientCount: number;
  //photo: string;
  createdDate: Date;
}
