
export class AppartementModel {
  operationId: string;
  immeubleId: string;
  appartementId: string;
  reference: string;
  numeroEtage: number;
  surfaceTotal: number;
  
  appartementTypeCode: number;
  appartementTypeLibelle: string;

  positionAppartementCode: number;
  positionAppartementLibelle: string;

  cuisineTypeCode: number;
  cuisineTypeLibelle: string;

  photoPlanBase64: string;
}