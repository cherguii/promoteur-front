import { AppartementModel } from "./appartement.model";

export class ImmeubleDetailModel {
  operationId: string;
  immeubleId: string;
  nomOperation: string;
  nom: string;
  numero: number;
  nombreEtage: number;
  surfaceTotal: number;
  avecSousSol: boolean;
  debutConstructionDate: string;
  finConstructionDate: string;
  planPhoto: string;
  appartements: AppartementModel[];
}