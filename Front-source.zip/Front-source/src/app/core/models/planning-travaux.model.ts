import { MaterielTask } from "./materiel-task.model";

export class PlanningTravauxModel {

  operationId: string;
  planningTravauxId: string;

  activiteTypeCode: number;
  activiteTypeLibelle: string;
  
  sousTraitantId: string;
  sousTraitantNomSociete: string;

  coutHT: number;
  tva: number;
  
  activiteForUsedCode: number;
  selectedImmeubleId: string;
  selectedImmeubleNom: string;
  selectedAppartementId: string;
  selectedAppartementReference: string;

  materiels: MaterielTask[];
  
  debutDate: Date;
  finDate: Date;
}