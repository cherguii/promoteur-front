
export class ImmeubleItemModel {
  operationId: string;
  immeubleId: string;
  nom: string;
  numero: number;
  nombreEtage: number;
  surfaceTotal: number;
  avecSousSol: boolean;
  debutConstructionDate: string;
  finConstructionDate: string;
}