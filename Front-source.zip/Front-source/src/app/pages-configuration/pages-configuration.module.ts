import { LOCALE_ID, NgModule } from '@angular/core';
import { CommonModule, DatePipe, registerLocaleData } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ComponentsModule } from '@shared/components/components.module';
import { SharedModule } from '@shared';
import { GalleryModule } from '@ks89/angular-modal-gallery';
import { NgScrollbarModule } from 'ngx-scrollbar';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { NgxMatSelectSearchModule } from 'ngx-mat-select-search';
import localeFr from '@angular/common/locales/fr';
import { DateAdapter, NativeDateAdapter } from '@angular/material/core';
import { NgxMaskDirective, NgxMaskPipe, provideNgxMask } from 'ngx-mask';

import { PagesConfigurationRoutingModule } from './pages-configuration-routing.module';

import { AllActiviteComponent } from './activite/all-activite.component';
import { EditActiviteDialogComponent } from './activite/dialogs/form-dialog/edit-activite-dialog.component';
import { DeleteActiviteDialogComponent } from './activite/dialogs/delete-activite/delete-activite-dialog.component';

import { ActiviteService } from '@core/service/activite.service';

registerLocaleData(localeFr);

export class FrenchDateAdapter extends NativeDateAdapter {
  override parse(value: any): Date | null {
    if ((typeof value === 'string') && (value.indexOf('/') > -1)) {
      const str = value.split('/');
      if (str.length < 2 || isNaN(+str[0]) || isNaN(+str[1]) || isNaN(+str[2])) {
        return null;
      }
      return new Date(Number(str[2]), Number(str[1]) - 1, Number(str[0]), 12);
    }
    const timestamp = typeof value === 'number' ? value : Date.parse(value);
    return isNaN(timestamp) ? null : new Date(timestamp);
  }
}

@NgModule({
  declarations: [
    
    AllActiviteComponent,
    EditActiviteDialogComponent,
    DeleteActiviteDialogComponent,
    
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    PagesConfigurationRoutingModule,
    ComponentsModule,
    NgxMaskDirective,
    NgxMaskPipe,
    SharedModule,
    GalleryModule,
    NgScrollbarModule,
    DragDropModule,
    NgxMatSelectSearchModule,
    
  ],
  providers: [
    ActiviteService,
    provideNgxMask(),
    DatePipe,
    { provide: LOCALE_ID, useValue: 'fr-FR'},
    { provide: DateAdapter, useClass: FrenchDateAdapter },
  ],
})
export class PagesConfigurationModule {}
