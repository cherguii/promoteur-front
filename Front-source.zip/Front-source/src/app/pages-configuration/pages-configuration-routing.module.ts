import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { AuthGuard } from "@core/guard/auth.guard";
import { AllActiviteComponent } from "./activite/all-activite.component";

const routes: Routes = [
  
  { path: "all-activite", component: AllActiviteComponent, canActivate: [AuthGuard] },  
  
];
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class PagesConfigurationRoutingModule {}
