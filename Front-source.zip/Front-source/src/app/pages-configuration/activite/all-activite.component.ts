import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { DataSource } from '@angular/cdk/collections';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition, } from '@angular/material/snack-bar';
import { BehaviorSubject, fromEvent, merge, Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { EditActiviteDialogComponent } from './dialogs/form-dialog/edit-activite-dialog.component';
import { DeleteActiviteDialogComponent } from './dialogs/delete-activite/delete-activite-dialog.component';
import { SelectionModel } from '@angular/cdk/collections';
import { UnsubscribeOnDestroyAdapter, } from '@shared';
import { ActiviteService } from '@core/service/activite.service';
import { ActiviteTypeModel } from '@core/models/activite-type.model';

@Component({
  selector: 'app-all-activite',
  templateUrl: './all-activite.component.html',
  styleUrls: ['./all-activite.component.scss'],
})
export class AllActiviteComponent extends UnsubscribeOnDestroyAdapter implements OnInit {

  // Fields.
  displayedColumns = [
    'select',
    'order',
    'libelle',
    'createdDate',
    'actions',
  ];
  activiteDatabase?: ActiviteService;
  dataSource!: ActiviteDataSource;
  selection = new SelectionModel<ActiviteTypeModel>(true, []);
  activiteTypeId?: string;

  @ViewChild(MatPaginator, { static: true }) paginator!: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort!: MatSort;
  @ViewChild('filter', { static: true }) filter?: ElementRef;

  // Ctor.
  constructor(public httpClient: HttpClient,
              public dialog: MatDialog,
              public activiteService: ActiviteService,
              private snackBar: MatSnackBar) {
    super();
  }

  ngOnInit() {
    this.loadData();
  }

  refresh() {
    this.loadData();
  }

  addNew() {
    const dialogRef = this.dialog.open(EditActiviteDialogComponent, {
      data: {
        action: 'add',
      },
      direction: 'ltr',
    });
    this.subs.sink = dialogRef.afterClosed().subscribe((result) => {
      if (result === 1) {
        var activiteToAdd = this.activiteService.currentActivite;
        this.activiteService.addActivite(activiteToAdd)
            .subscribe({
              next: (response) =>  {
                if(this.activiteService.isAddActiviteOk) {
                  this.activiteDatabase?.dataChange.value.unshift(
                    this.activiteService.activiteAdd
                  );
                  this.refreshTable();
                  this.showNotification(
                    'snackbar-success',
                    'L\'activité a été ajoutée avec succès !!!',
                    'bottom',
                    'right'
                  );
                }
                else {
                  this.showNotification(
                    'snackbar-danger',
                    response.message,
                    'bottom',
                    'right'
                  );
                }
                this.activiteService.currentActivite = null;
              }
            });
      }
    });
  }

  editCall(row: ActiviteTypeModel) {
    this.activiteTypeId = row.activiteTypeId;
    const dialogRef = this.dialog.open(EditActiviteDialogComponent, {
      data: {
        activite: row,
        action: 'edit',
      },
      direction: 'ltr',
    });
    this.subs.sink = dialogRef.afterClosed().subscribe((result) => {

      if (result === 1) {
        var activiteToUpdate= this.activiteService.currentActivite;
        this.activiteService.updateActivite(activiteToUpdate)
            .subscribe({
              next: (response) =>  {
                if(this.activiteService.isEditActiviteOK) {
                    const foundIndex = this.activiteDatabase?.dataChange.value.findIndex(
                      (x) => x.activiteTypeId === this.activiteTypeId
                    );
                    if (foundIndex != null && this.activiteDatabase) {
                      this.activiteDatabase.dataChange.value[foundIndex] = this.activiteService.activiteUpdate;
                      this.refreshTable();
                      this.showNotification(
                        'snackbar-success',
                        'L\'activité a été mis à jour avec succès !!!',
                        'bottom',
                        'right'
                      );
                    }
                }
                else {
                  this.showNotification(
                    'snackbar-danger',
                    response.message,
                    'bottom',
                    'right'
                  );
                }
                this.activiteService.currentActivite = null;
              }
            });
      }
    });
  }

  deleteItem(row: ActiviteTypeModel) {
    this.activiteTypeId = row.activiteTypeId;
    const dialogRef = this.dialog.open(DeleteActiviteDialogComponent, {
      data: row,
      direction: 'ltr',
    });
    this.subs.sink = dialogRef.afterClosed().subscribe((result) => {
      if (result === 1) {
        this.activiteService.deleteActivite(row.activiteTypeId)
              .subscribe({
                next: (response) =>  {
                  if(this.activiteService.isDeleteActiviteOK) { 
                    const foundIndex = this.activiteDatabase?.dataChange.value.findIndex(
                      (x) => x.activiteTypeId === this.activiteTypeId
                    );
                    if (foundIndex != null && this.activiteDatabase) {
                      this.activiteDatabase.dataChange.value.splice(foundIndex, 1);
                      this.refreshTable();
                      this.showNotification(
                        'snackbar-success',
                        'L\'activité a été supprimer avec succès',
                        'bottom',
                        'right'
                      );
                    }
                  }
                  else {
                    this.showNotification(
                      'snackbar-danger',
                      response.message,
                      'bottom',
                      'right'
                    );
                  }
                }
              });
      }
    });
  }

  private refreshTable() {
    this.paginator?._changePageSize(this.paginator?.pageSize);
  }

  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.renderedData.length;
    return numSelected === numRows;
  }

  masterToggle() {
    this.isAllSelected()
      ? this.selection.clear()
      : this.dataSource.renderedData.forEach((row) =>
          this.selection.select(row)
        );
  }

  removeSelectedRows() {
    const totalSelect = this.selection.selected.length;
    this.selection.selected.forEach((item) => {
      const index: number = this.dataSource.renderedData.findIndex(
        (d) => d === item
      );
      this.activiteDatabase?.dataChange.value.splice(index, 1);
      this.refreshTable();
      this.selection = new SelectionModel<ActiviteTypeModel>(true, []);
    });
    this.showNotification(
      'snackbar-danger',
      totalSelect + ' activité(s) ont été supprimés avec succès',
      'bottom',
      'right'
    );
  }

  public loadData() {
    this.activiteDatabase = new ActiviteService(this.httpClient);
    this.dataSource = new ActiviteDataSource(
      this.activiteDatabase,
      this.paginator,
      this.sort
    );
    this.subs.sink = fromEvent(this.filter?.nativeElement, 'keyup').subscribe(
      () => {
        if (!this.dataSource) {
          return;
        }
        this.dataSource.filter = this.filter?.nativeElement.value;
      }
    );
  }

  showNotification(colorName: string, text: string, placementFrom: MatSnackBarVerticalPosition, placementAlign: MatSnackBarHorizontalPosition) {
    this.snackBar.open(text, '', {
      duration: 5000,
      verticalPosition: placementFrom,
      horizontalPosition: placementAlign,
      panelClass: colorName,
    });
  }
  
}

export class ActiviteDataSource extends DataSource<ActiviteTypeModel> {

  // Fields.
  filterChange = new BehaviorSubject('');
  get filter(): string {
    return this.filterChange.value;
  }
  set filter(filter: string) {
    this.filterChange.next(filter);
  }
  filteredData: ActiviteTypeModel[] = [];
  renderedData: ActiviteTypeModel[] = [];

  // Ctor.
  constructor(public activiteDatabase: ActiviteService,
              public paginator: MatPaginator,
              public _sort: MatSort) {
    super();
    this.filterChange.subscribe(() => (this.paginator.pageIndex = 0));
  }

  connect(): Observable<ActiviteTypeModel[]> {
    const displayDataChanges = [
      this.activiteDatabase.dataChange,
      this._sort.sortChange,
      this.filterChange,
      this.paginator.page,
    ];
    this.activiteDatabase.getAllActivite();
    return merge(...displayDataChanges).pipe(
      map(() => {
        // Filter data
        this.filteredData = this.activiteDatabase.data
          .slice()
          .filter((activite: ActiviteTypeModel) => {
            const searchStr = (
              activite.libelle +
              activite.order
            ).toLowerCase();
            return searchStr.indexOf(this.filter.toLowerCase()) !== -1;
          });
        // Sort filtered data
        const sortedData = this.sortData(this.filteredData.slice());
        // Grab the page's slice of the filtered sorted data.
        const startIndex = this.paginator.pageIndex * this.paginator.pageSize;
        this.renderedData = sortedData.splice(
          startIndex,
          this.paginator.pageSize
        );
        return this.renderedData;
      })
    );
  }

  disconnect() {}

  sortData(data: ActiviteTypeModel[]): ActiviteTypeModel[] {
    if (!this._sort.active || this._sort.direction === '') {
      return data;
    }
    return data.sort((a, b) => {
      let propertyA: Date | number | string = '';
      let propertyB: Date | number | string = '';
      switch (this._sort.active) {
        case 'activiteTypeId':
          [propertyA, propertyB] = [a.activiteTypeId, b.activiteTypeId];
          break;
        case 'libelle':
          [propertyA, propertyB] = [a.libelle, b.libelle];
          break;
        case 'order':
          [propertyA, propertyB] = [a.order, b.order];
          break;
      }
      const valueA = isNaN(+propertyA) ? propertyA : +propertyA;
      const valueB = isNaN(+propertyB) ? propertyB : +propertyB;
      return (
        (valueA < valueB ? -1 : 1) * (this._sort.direction === 'asc' ? 1 : -1)
      );
    });
  }
  
}
