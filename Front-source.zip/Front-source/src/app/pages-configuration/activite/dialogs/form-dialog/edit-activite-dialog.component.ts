import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { Component, Inject } from '@angular/core';
import { UntypedFormGroup, UntypedFormBuilder, } from '@angular/forms';
import { ActiviteService } from '@core/service/activite.service';
import { DatePipe } from '@angular/common';
import { ActiviteTypeModel } from '@core/models/activite-type.model';

export interface DialogData {
  action: string;
  activite: ActiviteTypeModel;
}

@Component({
  selector: 'app-edit-activite-dialog:not(f)',
  templateUrl: './edit-activite-dialog.component.html',
  styleUrls: ['./edit-activite-dialog.component.scss'],
})
export class EditActiviteDialogComponent {

 // Fields.
 action: string;
 dialogTitle: string;
 activiteForm: UntypedFormGroup;
 activite: ActiviteTypeModel;
 
 // Ctor.
 constructor(public dialogRef: MatDialogRef<EditActiviteDialogComponent>,
             @Inject(MAT_DIALOG_DATA) public data: DialogData,
             private activiteService: ActiviteService,
             public datepipe: DatePipe,
             private fb: UntypedFormBuilder) {
   this.action = data.action;
   if (this.action === 'edit') {
     this.dialogTitle = `${data.activite.libelle}`;
     this.activite = data.activite;
   } else {
     this.dialogTitle = 'Nouvelle Activité';
     this.activite = new ActiviteTypeModel();
   }
   this.activiteForm = this.createContactForm();
 }

 ngOnInit() {
 }

 createContactForm(): UntypedFormGroup {
   return this.fb.group({
    activiteTypeId: [this.activite.activiteTypeId],
    libelle: [this.activite.libelle],
    order: [this.activite.order]
   });
 }
 
 public confirmSave(): void {
   this.activiteService.currentActivite = this.activiteForm.getRawValue();
   if (this.action === 'add') {
     this.activiteService.currentActivite.referentielId = '00000000-0000-0000-0000-000000000000';
     this.activiteService.currentActivite.code = 0;
   }
 }

onNoClick(): void {
  this.dialogRef.close();
}

}
