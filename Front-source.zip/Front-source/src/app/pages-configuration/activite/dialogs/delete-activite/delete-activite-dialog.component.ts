import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { Component, Inject } from '@angular/core';

@Component({
  selector: 'app-delete-activite-dialog:not(f)',
  templateUrl: './delete-activite-dialog.component.html',
  styleUrls: ['./delete-activite-dialog.component.scss'],
})
export class DeleteActiviteDialogComponent {
  
  // Ctor.
  constructor(public dialogRef: MatDialogRef<DeleteActiviteDialogComponent>,
              @Inject(MAT_DIALOG_DATA) public data: any) {}

  onNoClick(): void {
    this.dialogRef.close();
  }
}
