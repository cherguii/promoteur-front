import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { UntypedFormBuilder, UntypedFormGroup, Validators } from '@angular/forms';
import { UnsubscribeOnDestroyAdapter } from '@shared';
import { AuthService, Role } from '@core';
import { Subscription } from 'rxjs';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-signin',
  templateUrl: './signin.component.html',
  styleUrls: ['./signin.component.scss'],
})
export class SigninComponent extends UnsubscribeOnDestroyAdapter implements OnInit, OnDestroy {

  // Fields.
  authForm!: UntypedFormGroup;
  submitted = false;
  loading = false;
  error = '';
  hide = true;

  username = '';
  password = '';
  private subscription: Subscription;

  // Ctor.
  constructor(private formBuilder: UntypedFormBuilder,
              private authService: AuthService,
              private snackBar: MatSnackBar,
              private route: ActivatedRoute,
              private router: Router) {
    super();
  }

  ngOnInit() {
    this.authForm = this.formBuilder.group({
      username: ['achergui', Validators.required],
      password: ['23021978', Validators.required],
    });

    this.subscription = this.authService.currentUser.subscribe((x) => {
      if (this.route.snapshot.url[0].path === 'login') {
        const accessToken = localStorage.getItem('access_token');
        const refreshToken = localStorage.getItem('refresh_token');
        if (x && accessToken && refreshToken) {
          const returnUrl = this.route.snapshot.queryParams['returnUrl'] || '';
          this.router.navigate([returnUrl]);
        }
      } // optional touch-up: if a tab shows login page, then refresh the page to reduce duplicate login
    });
  }
  get f() {
    return this.authForm.controls;
  }

  // adminSet() {
  //   this.authForm.get('username')?.setValue('admin@hospital.org');
  //   this.authForm.get('password')?.setValue('admin@123');
  // }

  // doctorSet() {
  //   this.authForm.get('username')?.setValue('doctor@hospital.org');
  //   this.authForm.get('password')?.setValue('doctor@123');
  // }

  // patientSet() {
  //   this.authForm.get('username')?.setValue('patient@hospital.org');
  //   this.authForm.get('password')?.setValue('patient@123');
  // }

  onSubmit() {
    this.submitted = true;
    this.loading = true;
    this.error = '';
    if (this.authForm.invalid) {
      //this.error = 'Username and Password not valid !';
      this.showNotification('snackbar-danger', 'Veuillez remplir les champs obligatoires.', 'bottom', 'right');
      return;
    } 
    else {

      this.username = this.f['username'].value;
      this.password = this.f['password'].value;

      if (!this.username || !this.password)
        return;
        

      this.subs.sink = this.authService.login(this.username, this.password )
            .subscribe({
              next: (res) => {
                if (res) {
                  setTimeout(() => {
                    // const role = this.authService.currentUserValue.role;
                    // if (role === Role.All || role === Role.Admin) {
                    //   this.router.navigate(['/admin/dashboard/main']);
                    // } else if (role === Role.Doctor) {
                    //   this.router.navigate(['/doctor/dashboard']);
                    // } else if (role === Role.Patient) {
                    //   this.router.navigate(['/patient/dashboard']);
                    // } else {
                    //   this.router.navigate(['/authentication/signin']);
                    // }
                    if (this.authService.isAuth === true) {
                      this.navigateToHome();
                    }
                    this.loading = false;
                  }, 1000);
                } 
                else {
                  this.error = 'Invalid Login';
                  this.showNotification(
                    'snackbar-danger', 
                    'Votre identifiant ou mot de passe sont incorrects.', 
                    'bottom', 'right'
                  );
                }
              },
              error: (error) => {
                this.error = error;
                this.submitted = false;
                this.loading = false;
                this.showNotification(
                  'snackbar-danger', 
                  this.authService.errorMessage, 
                  'bottom', 
                  'right'
                );
              },
            });
    }
  }

  // navigateToHome.
  navigateToHome(): void {
    this.router.navigate(['/home']);
  }

  // showNotification.
  showNotification(colorName: any, text: any, placementFrom: any, placementAlign: any) {
    this.snackBar.open(text, '', {
      duration: 2000,
      verticalPosition: placementFrom,
      horizontalPosition: placementAlign,
      panelClass: colorName
    });
  }

   // ngOnDestroy.
   override ngOnDestroy(): void {
    this.subscription?.unsubscribe();
  }

}
