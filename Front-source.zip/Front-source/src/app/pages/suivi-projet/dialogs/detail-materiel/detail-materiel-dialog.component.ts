import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { Component, Inject } from '@angular/core';
import { PatientModel } from '@core/models/patient.model';
import { ImmeubleItemModel } from '@core/models/immeuble-item.model';
import { MaterielTask } from '@core/models/materiel-task.model';
import { MaterielService } from '@core/service/materiel.service';

export interface DialogData {
  planningTravauxId: string;
  activiteLibelle: string;
  materiels: MaterielTask[];
}

@Component({
  selector: 'app-detail-materiel-dialog',
  templateUrl: './detail-materiel-dialog.component.html',
  styleUrls: ['./detail-materiel-dialog.component.scss'],
})
export class DetailMaterielDialogComponent {
  
  // Fields.
  activiteLibelle: string;
  planningTravauxId: string;
  materiels: MaterielTask[];

  // Ctor.
  constructor(public dialogRef: MatDialogRef<DetailMaterielDialogComponent>,
              @Inject(MAT_DIALOG_DATA) public data: DialogData,
              private materielService: MaterielService) {

    this.activiteLibelle = data.activiteLibelle;
    this.planningTravauxId = data.planningTravauxId;
    this.materiels = data.materiels;
  }

  getMaterielsByPlanningTravauxId() {

  }

  onNoClick(): void {
    this.dialogRef.close();
  }
  
}
