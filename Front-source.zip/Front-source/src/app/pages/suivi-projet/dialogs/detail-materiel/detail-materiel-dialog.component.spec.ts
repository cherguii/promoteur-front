import { ComponentFixture, TestBed, waitForAsync } from "@angular/core/testing";
import { DetailMaterielDialogComponent } from "./detail-materiel-dialog.component";

describe("DetailMaterielDialogComponent", () => {
  let component: DetailMaterielDialogComponent;
  let fixture: ComponentFixture<DetailMaterielDialogComponent>;

  beforeEach(
    waitForAsync(() => {
      TestBed.configureTestingModule({
        declarations: [DetailMaterielDialogComponent],
      }).compileComponents();
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(DetailMaterielDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
