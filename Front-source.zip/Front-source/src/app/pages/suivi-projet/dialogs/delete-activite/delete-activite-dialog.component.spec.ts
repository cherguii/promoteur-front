import { ComponentFixture, TestBed, waitForAsync } from "@angular/core/testing";
import { DeleteActiviteDialogComponent } from "./delete-activite-dialog.component";

describe("DeleteActiviteDialogComponent", () => {
  let component: DeleteActiviteDialogComponent;
  let fixture: ComponentFixture<DeleteActiviteDialogComponent>;
  beforeEach(
    waitForAsync(() => {
      TestBed.configureTestingModule({
        declarations: [DeleteActiviteDialogComponent],
      }).compileComponents();
    })
  );
  beforeEach(() => {
    fixture = TestBed.createComponent(DeleteActiviteDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });
  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
