import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Component, Inject, Input, ViewChild } from '@angular/core';
import { UntypedFormControl, UntypedFormGroup, UntypedFormBuilder, FormControl } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { CommonHelper } from '@core/helpers/common-helper';
import { ActivatedRoute } from '@angular/router';
import { ReferentialService } from '@core/service/referential.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ReferentielModel } from '@core/models/referentiel.model';
import { PlanningTravauxModel } from '@core/models/planning-travaux.model';
import { SuiviProjetService } from '@core/service/suivi-projet.service';
import { MatSidenav } from '@angular/material/sidenav';
import { CdkDragDrop, moveItemInArray } from '@angular/cdk/drag-drop';
import { MaterielService } from '@core/service/materiel.service';
import { SousTraitantService } from '@core/service/sous-traitant.service';
import { SousTraitantModel } from '@core/models/sous-traitant.model';
import { MaterielModel } from '@core/models/materiel.model';
import { MaterielTask } from '@core/models/materiel-task.model';
import { ImmeubleService } from '@core/service/immeuble.service';
import { ImmeubleItemModel } from '@core/models/immeuble-item.model';
import { AppartementModel } from '@core/models/appartement.model';
import { AppartementService } from '@core/service/appartement.service';
import { ActiviteEnum } from '@core/models/activite-enum';
import { ReplaySubject, Subject } from 'rxjs';
import { MatSelect } from "@angular/material/select";
import { take, takeUntil } from 'rxjs/operators';

export interface DialogData {
  id: number;
  action: string;
  planningTravaux: PlanningTravauxModel;
}

@Component({
  selector: 'app-add-edit-activite-dialog:not(f)',
  templateUrl: './add-edit-activite-dialog.component.html',
  styleUrls: ['./add-edit-activite-dialog.component.scss'],
})
export class AddEditActiviteDialogComponent {

  // Fields.
  action: string;
  dialogTitle: string;
  planningTravauxForm: UntypedFormGroup;
  currentPlanningTravaux: PlanningTravauxModel;
  activiteTypes: ReferentielModel[];
  //sousTraitantTypes: ReferentielModel[];
  sousTraitants: SousTraitantModel[];
  immeubles: ImmeubleItemModel[];
  materiels: MaterielModel[];
  appartements: AppartementModel[];
  currentUsedActiviteSelected: number;
  selectedImmeubleId: any;
  selectedAppartementId: any;
  selectedMateriel: MaterielModel;
  @Input() quantiteResteEnstock: any;

//  public productionRegionFilterCtrl: FormControl<string> = new FormControl<string>('toto');
//  public filteredProductionRegions: ReplaySubject<string[]> = new ReplaySubject<string[]>(1);
//  @ViewChild('activiteTypeSelect', { static: true }) activiteTypeSelect: MatSelect;
 
  // Ctor.
  constructor(public dialogRef: MatDialogRef<AddEditActiviteDialogComponent>,
              @Inject(MAT_DIALOG_DATA) public data: DialogData,
              private suiviProjetService: SuiviProjetService,
              private sousTraitantService: SousTraitantService,
              private referentialService: ReferentialService,
              private materielService: MaterielService,
              private immeubleService: ImmeubleService,
              private appartementService: AppartementService,
              private activatedRoute: ActivatedRoute,
              public datepipe: DatePipe,
              private fb: UntypedFormBuilder,
              private snackBar: MatSnackBar) {

    this.action = data.action;
    if (this.action === 'edit') {
      this.dialogTitle = `${data.planningTravaux.activiteTypeLibelle}`;
      this.currentPlanningTravaux = data.planningTravaux;
      this.tasks = data.planningTravaux.materiels;
      this.currentUsedActiviteSelected = data.planningTravaux.activiteForUsedCode;
      this.selectedImmeubleId = data.planningTravaux.selectedImmeubleId;
      this.selectedAppartementId = data.planningTravaux.selectedAppartementId;

      if(this.currentUsedActiviteSelected === ActiviteEnum.IMMEUBLE) {
        this.fillImmeubles();
      }

      if(this.currentUsedActiviteSelected === ActiviteEnum.APPARTEMENT) {
        this.fillImmeubles();
        this.fillAppartementsByImmeubleId(this.selectedImmeubleId );
      }
    } else {
      this.dialogTitle = 'Nouveau matériel';
      this.currentPlanningTravaux = new PlanningTravauxModel();
    }
    
    this.planningTravauxForm = this.initForm();
    this.fillActiviteTypes();
    //this.fillSousTraitantTypes();
    this.fillSousTraitant();
    this.fillMateriels();

    const blank = {} as MaterielTask;
    this.materielTaskForm = this.initMaterielTaskForm(blank);
  }

  ngOnInit() {
  }

  initForm(): UntypedFormGroup {
    return this.fb.group({
      operationId: [this.currentPlanningTravaux.operationId],
      planningTravauxId: [this.currentPlanningTravaux.planningTravauxId],
      activiteTypeCode: [this.currentPlanningTravaux.activiteTypeCode],
      activiteTypeLibelle: [this.currentPlanningTravaux.activiteTypeLibelle],
      // sousTraitantTypeCode: [this.currentPlanningTravaux.sousTraitantTypeCode],
      // sousTraitantTypeLibelle: [this.currentPlanningTravaux.sousTraitantTypeLibelle],
      sousTraitantId: [this.currentPlanningTravaux.sousTraitantId],
      sousTraitantNomSociete: [this.currentPlanningTravaux.sousTraitantNomSociete],

      coutHT: [this.currentPlanningTravaux.coutHT],
      tva: [this.currentPlanningTravaux.tva],

      debutDate: [CommonHelper.formatDate2(this.currentPlanningTravaux.debutDate)],
      finDate: [CommonHelper.formatDate2(this.currentPlanningTravaux.finDate)],

      activiteForUsedCode: [this.currentPlanningTravaux.activiteForUsedCode],
      selectedImmeubleId:  [this.currentPlanningTravaux.selectedImmeubleId],
      selectedAppartementId:  [this.currentPlanningTravaux.selectedAppartementId],
    });
  }

  initMaterielTaskForm(data: MaterielTask) {
    return this.fb.group({
      materielId: [data ? data.materielId: null],
      libelle: [data ? data.libelle: null],
      quantite: [data ? data.quantite: null],
      prixUnitaire: [data ? data.prixUnitaire: null],
      tva: [data ? data.tva: null],
      commentaire: [data ? data.commentaire: null]
    });
  }

  fillImmeubles() {
    const operationId = this.activatedRoute.snapshot.queryParamMap.get('operationId');
    this.immeubleService.getImmeublesByOperationId(operationId)
            .subscribe({
              next: (response) => {
              if(this.immeubleService.isGetImmeublesByOperationIdOK === true) {
                this.immeubles = response;
              }
              else {
                this.showNotification(
                  'snackbar-danger',
                  response.message,
                  'bottom',
                  'right'
                );
              }
              }
            });
  }

  fillAppartementsByImmeubleId(immeubleId: any) {
    const operationId = this.activatedRoute.snapshot.queryParamMap.get('operationId');
    this.appartementService.getAppartementsByOperationIdAndImmeubleId(operationId, immeubleId)
            .subscribe({
              next: (response) => {
              if(this.appartementService.isGetAppartementsByOperationIdAndImmeubleIdOK === true) {
                this.appartements = response;
              }
              else {
                this.showNotification(
                  'snackbar-danger',
                  response.message,
                  'bottom',
                  'right'
                );
              }
              }
            });
  }

  fillActiviteTypes() {
    this.referentialService.getAllActiviteType()
            .subscribe({
              next: (response) => {
              if(this.referentialService.isGetAllActiviteTypeOk === true) {
                this.activiteTypes = response;
              }
              else {
                this.showNotification(
                  'snackbar-danger',
                  response.message,
                  'bottom',
                  'right'
                );
              }
              }
            });
    
  }

//  fillSousTraitantTypes() {
//   this.referentialService.getAllSousTraitantType()
//           .subscribe({
//             next: (response) => {
//              if(this.referentialService.isGetAllSousTraitantTypeOk === true) {
//                this.sousTraitantTypes = response;
//              }
//              else {
//                this.showNotification(
//                  'snackbar-danger',
//                  response.message,
//                  'bottom',
//                  'right'
//                );
//              }
//             }
//           });
  
//  }

  fillSousTraitant() {
    this.sousTraitantService.getAllSousTraitantForActivite()
            .subscribe({
              next: (response) => {
              if(this.sousTraitantService.isGetAllSousTraitantForActiviteOK === true) {
                this.sousTraitants = response;
              }
              else {
                this.showNotification(
                  'snackbar-danger',
                  response.message,
                  'bottom',
                  'right'
                );
              }
              }
            });
  }

  fillMateriels() {
    this.materielService.getAllMaterielForActivite()
            .subscribe({
              next: (response) => {
              if(this.materielService.isGetAllMaterielForActiviteOK === true) {
                this.materiels = response;
              }
              else {
                this.showNotification(
                  'snackbar-danger',
                  response.message,
                  'bottom',
                  'right'
                );
              }
              }
            });
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

  onOperationSelected(selectedValue: any) {
    this.currentUsedActiviteSelected = selectedValue;
  }

  onImmeubleSelected(selectedValue: any) {
    this.currentUsedActiviteSelected = selectedValue;
    if(this.immeubles == undefined || this.immeubles === null)
      this.fillImmeubles();
  }

  onAppartementSelected(selectedValue: any) {
    this.currentUsedActiviteSelected = selectedValue;
    if(this.immeubles == undefined || this.immeubles === null) {
      this.fillImmeubles();
    }
    if(this.selectedImmeubleId !== undefined && this.selectedImmeubleId != null) {
      this.fillAppartementsByImmeubleId(this.selectedImmeubleId);
    }
  }

  onChangeImmeuble(event: any){
    this.selectedImmeubleId = event.value;
    this.fillAppartementsByImmeubleId(this.selectedImmeubleId);
  }

  onChangeAppartement(event: any){
    this.selectedAppartementId = event.value;
  }

  onChangeMateriel(event: any) {
    var materielId = event.value;
    var materiel =  this.tasks.find(x=> x.materielId === materielId);
    if(materiel !== undefined) {
      this.showNotification(
        'snackbar-danger',
        'Le matériel existe déjà dans la liste des matériaux.',
        'bottom',
        'right'
      );
    }
    else {
      this.getQuantiteQuiResteEnStock(materielId);
    }  
  }

  getQuantiteQuiResteEnStock(materielId: any) {
    this.materielService.getQuantiteQuiResteEnStock(materielId)
          .subscribe({
            next: (response) => {
              if(this.materielService.isGetQuantiteQuiResteEnStockOK === true) {
                this.quantiteResteEnstock = response;
              }
            }
          });
  }

public confirmSave(): void {
  this.suiviProjetService.currentPlanningTravaux = this.planningTravauxForm.getRawValue();
  const operationId = this.activatedRoute.snapshot.queryParamMap.get('operationId');
  this.suiviProjetService.currentPlanningTravaux.operationId = operationId;
  this.suiviProjetService.currentPlanningTravaux.materiels = this.tasks;

  if(this.currentUsedActiviteSelected === ActiviteEnum.OPERATION) {
    this.suiviProjetService.currentPlanningTravaux.selectedImmeubleId = null;
    this.suiviProjetService.currentPlanningTravaux.selectedAppartementId = null;
  }

  if(this.currentUsedActiviteSelected === ActiviteEnum.IMMEUBLE) {
    this.suiviProjetService.currentPlanningTravaux.selectedImmeubleId = this.selectedImmeubleId;
    this.suiviProjetService.currentPlanningTravaux.selectedAppartementId = null;
  }

  if(this.currentUsedActiviteSelected === ActiviteEnum.APPARTEMENT) {
    this.suiviProjetService.currentPlanningTravaux.selectedImmeubleId = this.selectedImmeubleId;
    this.suiviProjetService.currentPlanningTravaux.selectedAppartementId = this.selectedAppartementId;
  }

  if (this.action === 'edit')
    this.suiviProjetService.currentPlanningTravaux.planningTravauxId = this.currentPlanningTravaux.planningTravauxId;    
  else
    this.suiviProjetService.currentPlanningTravaux.planningTravauxId = '00000000-0000-0000-0000-000000000000';

  if(this.suiviProjetService.currentPlanningTravaux.debutDate !== '')
    this.suiviProjetService.currentPlanningTravaux.debutDate = CommonHelper.formatDate(this.suiviProjetService.currentPlanningTravaux.debutDate);
  else
    this.suiviProjetService.currentPlanningTravaux.debutDate = null;

  if(this.suiviProjetService.currentPlanningTravaux.finDate !== '')
    this.suiviProjetService.currentPlanningTravaux.finDate = CommonHelper.formatDate(this.suiviProjetService.currentPlanningTravaux.finDate);
  else
    this.suiviProjetService.currentPlanningTravaux.finDate = null;

 }

 // showNotification.
 showNotification(colorName: any, text: any, placementFrom: any, placementAlign: any) {
  this.snackBar.open(text, '', {
    duration: 5000,
    verticalPosition: placementFrom,
    horizontalPosition: placementAlign,
    panelClass: colorName,
  });
 }

 ////////////////////////// Task
  mode = new UntypedFormControl('side');
  materielTaskForm: UntypedFormGroup;
  showFiller = false;
  isNewEvent = false;
  dialogTaskTitle?: string;
  userImg?: string;
  tasks: MaterielTask[] = [];

  drop(event: CdkDragDrop<string[]>) {
    moveItemInArray(this.tasks, event.previousIndex, event.currentIndex);
  }

  toggle(task: { done: boolean }, nav: MatSidenav) {
    nav.close();
    task.done = !task.done;
  }

  addNewTask(nav: MatSidenav) {
    this.resetFormField();
    this.isNewEvent = true;
    this.dialogTitle = 'Ajouter un matériel';
    nav.open();
    console.log('add');
  }

  taskClick(task: MaterielTask, nav: MatSidenav): void {
    this.isNewEvent = false;
    this.dialogTitle = 'Modifier le matériel';
    nav.open();
    this.materielTaskForm = this.initMaterielTaskForm(task);
    console.log('edit');

    this.getQuantiteQuiResteEnStock(task.materielId);
  }

  closeSlider(nav: MatSidenav) {
    nav.close();
  }

  saveTask(nav: MatSidenav) {

    var materielId = this.materielTaskForm.value.materielId;
    var materiel =  this.tasks.find(x=> x.materielId === materielId);
    if(materiel !== undefined) {
      this.showNotification(
        'snackbar-danger',
        'Le matériel existe déjà dans la liste des matériaux.',
        'bottom',
        'right'
      );
    }
    else {
      let materielTask = new MaterielTask();
      materielTask.libelle = this.getMaterielLibelleByMaterielId(this.materielTaskForm.value.materielId);
      materielTask.prixUnitaire = this.getPrixUnitaireByMaterielId(this.materielTaskForm.value.materielId);
      materielTask.tva = this.getTvaByMaterielId(this.materielTaskForm.value.materielId);
  
      this.materielTaskForm.value.libelle = materielTask.libelle;
      this.materielTaskForm.value.prixUnitaire = materielTask.prixUnitaire;
      this.materielTaskForm.value.tva = materielTask.tva;
  
      this.tasks.unshift(this.materielTaskForm.value);
    }
    this.resetFormField();
    nav.close();
  }

  getMaterielLibelleByMaterielId(materielId: string): string {
    var materiel =  this.materiels.find(x=> x.materielId === materielId) as MaterielModel;
    return materiel.libelle;
  }

  getPrixUnitaireByMaterielId(materielId: string): number {
    var materiel =  this.materiels.find(x=> x.materielId === materielId) as MaterielModel;
    return materiel.prixUnitaire;
  }

  getTvaByMaterielId(materielId: string): number {
    var materiel =  this.materiels.find(x=> x.materielId === materielId) as MaterielModel;
    return materiel.tva;
  }

  editTask(nav: MatSidenav) {
    const targetIdx = this.tasks
      .map((item) => item.materielId)
      .indexOf(this.materielTaskForm.value.materielId);
    this.tasks[targetIdx] = this.materielTaskForm.value;

    nav.close();
  }

  deleteTask(nav: MatSidenav) {
    const targetIdx = this.tasks
      .map((item) => item.materielId)
      .indexOf(this.materielTaskForm.value.id);
    this.tasks.splice(targetIdx, 1);
    nav.close();
  }

  resetFormField() {
     this.materielTaskForm.controls['materielId'].reset();
     this.materielTaskForm.controls['quantite'].reset();
     this.materielTaskForm.controls['commentaire'].reset();
  }

}