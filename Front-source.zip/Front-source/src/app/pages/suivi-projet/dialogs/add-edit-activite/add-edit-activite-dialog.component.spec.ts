import { ComponentFixture, TestBed, waitForAsync } from "@angular/core/testing";
import { AddEditActiviteDialogComponent } from "./add-edit-activite-dialog.component";

describe("AddEditActiviteDialogComponent", () => {
  let component: AddEditActiviteDialogComponent;
  let fixture: ComponentFixture<AddEditActiviteDialogComponent>;
  beforeEach(
    waitForAsync(() => {
      TestBed.configureTestingModule({
        declarations: [AddEditActiviteDialogComponent],
      }).compileComponents();
    })
  );
  beforeEach(() => {
    fixture = TestBed.createComponent(AddEditActiviteDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });
  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
