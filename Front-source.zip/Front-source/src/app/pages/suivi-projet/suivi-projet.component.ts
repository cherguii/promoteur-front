import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ActivatedRoute, Router} from '@angular/router';
import { OperationDetailModel } from '@core/models/operation-detail.model';
import { OperationItemModel } from '@core/models/operation-item.model';
import { ProjetService } from '@core/service/projet.service';
import { EditProjetDialogComponent } from '../projet/projet-detail/dialogs/edit-projet/edit-projet-dialog.component';
import { HttpClient } from '@angular/common/http';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { DataSource } from '@angular/cdk/collections';
import { BehaviorSubject, fromEvent, merge, Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { SelectionModel } from '@angular/cdk/collections';
import { TableExportUtil, TableElement, UnsubscribeOnDestroyAdapter } from '@shared';
import { SuiviProjetService } from '@core/service/suivi-projet.service';
import { PlanningTravauxModel } from '@core/models/planning-travaux.model';
import { AddEditActiviteDialogComponent } from './dialogs/add-edit-activite/add-edit-activite-dialog.component';
import { DeleteActiviteDialogComponent } from './dialogs/delete-activite/delete-activite-dialog.component';
import { DetailMaterielDialogComponent } from './dialogs/detail-materiel/detail-materiel-dialog.component';

@Component({
  selector: 'app-suivi-projet',
  templateUrl: './suivi-projet.component.html',
  styleUrls: ['./suivi-projet.component.scss'],
})
export class SuiviProjetComponent extends UnsubscribeOnDestroyAdapter implements OnInit {

  // Fields.
  displayedColumns = [
    'select',
    'activiteTypeLibelle',
    'sousTraitantNomSociete',
    'selectedImmeubleNom',
    'selectedAppartementReference',
    'debutDate',
    'finDate',
    'status',
    'actions',
  ];
  suiviProjetDatabase?: SuiviProjetService;
  dataSource!: SuiviProjetDataSource;
  selection = new SelectionModel<PlanningTravauxModel>(true, []);
  planningTravauxId?: string;

  @ViewChild(MatPaginator, { static: true }) paginator!: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort!: MatSort;
  @ViewChild('filter', { static: true }) filter?: ElementRef;

  currentProjet: OperationDetailModel = new OperationDetailModel();
  currentProjetCoutTotalTTC: string;

  // Ctor.
  constructor(public httpClient: HttpClient,
              private projetService: ProjetService,
              public suiviProjetService: SuiviProjetService,
              private router: Router,
              public dialog: MatDialog,
              private activatedRoute: ActivatedRoute,
              private snackBar: MatSnackBar) {
    super();
  }

  ngOnInit() {
    const operationId = this.activatedRoute.snapshot.queryParamMap.get('operationId');
    this.loadProjetById(operationId);
    this.loadData();
  }
  
  loadProjetById(operationId: any) {
    this.projetService.getProjetDetailById(operationId)
              .subscribe({
                next: (response) => {
                  if(this.projetService.isGetProjetByIdOK === true) {
                    this.currentProjet = response;
                  }
                  else {
                    this.showNotification(
                      'snackbar-danger',
                      response.message,
                      'bottom',
                      'right'
                    );
                  }
                }
              });
  }

  editProjet(projet: OperationItemModel) {
    const dialogRef = this.dialog.open(EditProjetDialogComponent, {
      data: {
        action: 'edit',
        projet: projet,
      },
      direction: 'ltr',
    });
    dialogRef.afterClosed().subscribe((result) => {
      if (result === 1) {
        var projetToUpdate= this.projetService.currentProjet;
        this.projetService.updateProjet(projetToUpdate)
            .subscribe({
              next: (response) =>  {
                if(this.projetService.isEditProjetOK) {
                      this.currentProjet = this.projetService.projetUpdate;
                      this.showNotification(
                        'snackbar-success',
                        'Le projet a été mis à jour avec succès !!!',
                        'bottom',
                        'right'
                      );
                    //}
                }
                else {
                  this.showNotification(
                    'snackbar-danger',
                    response.message,
                    'bottom',
                    'right'
                  );
                }
                this.projetService.currentProjet = null;
              }
            });
      }
    });
  }

  goToProjetItemsPage() {
    this.router.navigate(['/projets'] );
  }

  // showNotification.
  showNotification(colorName: any, text: any, placementFrom: any, placementAlign: any) {
    this.snackBar.open(text, '', {
      duration: 5000,
      verticalPosition: placementFrom,
      horizontalPosition: placementAlign,
      panelClass: colorName,
    });
  }

  // Table activités
  addNewActivite() {
    const dialogRef = this.dialog.open(AddEditActiviteDialogComponent, {
      data: {
        action: 'add',
      },
      direction: 'ltr',
      width: '60%',
    });
    dialogRef.afterClosed().subscribe((result) => {
      if (result === 1) {
        var planningTravauxToAdd = this.suiviProjetService.currentPlanningTravaux;
        this.suiviProjetService.addPlanningTravaux(planningTravauxToAdd)
            .subscribe({
              next: (response) =>  {
                if(this.suiviProjetService.isAddPlanningTravauxOk) {
                  this.suiviProjetDatabase?.dataChange.value.unshift(
                    this.suiviProjetService.planningTravauxAdd
                  );
                  this.refreshTable();

                  var dataChange = this.suiviProjetDatabase?.dataChange.value as PlanningTravauxModel[];
                  this.currentProjetCoutTotalTTC = this.suiviProjetService.calculateCoutTotal(dataChange);

                  this.showNotification(
                    'snackbar-success',
                    'L\'activité a été ajoutée avec succès !!!',
                    'bottom',
                    'right'
                  );
                }
                else {
                  this.showNotification(
                    'snackbar-danger',
                    response.message,
                    'bottom',
                    'right'
                  );
                }
                this.suiviProjetService.currentPlanningTravaux = null;
              }
            });

      }
    });
  }

  editActivite(row: PlanningTravauxModel) {
    this.planningTravauxId = row.planningTravauxId;
    const dialogRef = this.dialog.open(AddEditActiviteDialogComponent, {
      data: {
        planningTravaux: row,
        action: 'edit',
      },
      direction: 'ltr',
      width: '60%',
      height: '90%',
    });
    this.subs.sink = dialogRef.afterClosed().subscribe((result) => {
      if (result === 1) {
        var materielToUpdate= this.suiviProjetService.currentPlanningTravaux;
        this.suiviProjetService.updatePlanningTravaux(materielToUpdate)
            .subscribe({
              next: (response) =>  {
                if(this.suiviProjetService.isEditPlanningTravauxOk) {
                    const foundIndex = this.suiviProjetDatabase?.dataChange.value.findIndex(
                      (x) => x.planningTravauxId === this.planningTravauxId
                    );
                    if (foundIndex != null && this.suiviProjetDatabase) {
                      this.suiviProjetDatabase.dataChange.value[foundIndex] = this.suiviProjetService.planningTravauxUpdate;
                      this.refreshTable();
                      this.showNotification(
                        'snackbar-success',
                        'Le planning travaux a été mis à jour avec succès !!!',
                        'bottom',
                        'right'
                      );
                    }
                    var dataChange = this.suiviProjetDatabase?.dataChange.value as PlanningTravauxModel[];
                    this.currentProjetCoutTotalTTC = this.suiviProjetService.calculateCoutTotal(dataChange);
                }
                else {
                  this.showNotification(
                    'snackbar-danger',
                    response.message,
                    'bottom',
                    'right'
                  );
                }
                this.suiviProjetService.currentPlanningTravaux = null;
              }
            });
      }
    });
  }

  deleteActivite(row: PlanningTravauxModel) {
    this.planningTravauxId = row.planningTravauxId;
    const dialogRef = this.dialog.open(DeleteActiviteDialogComponent, {
      data: row,
      direction: 'ltr',
    });
    this.subs.sink = dialogRef.afterClosed().subscribe((result) => {
      if (result === 1) {
        const operationId = this.activatedRoute.snapshot.queryParamMap.get('operationId');
        this.suiviProjetService.deletePlanningTravaux(operationId, row.planningTravauxId)
              .subscribe({
                next: (response) =>  {
                  if(this.suiviProjetService.isDeletePlanningTravauxOK) { 
                    const foundIndex = this.suiviProjetDatabase?.dataChange.value.findIndex(
                      (x) => x.planningTravauxId === this.planningTravauxId
                    );
                    if (foundIndex != null && this.suiviProjetDatabase) {
                      this.suiviProjetDatabase.dataChange.value.splice(foundIndex, 1);
                      this.refreshTable();
                      this.showNotification(
                        'snackbar-success',
                        'Le matériel a été supprimer avec succès',
                        'bottom',
                        'right'
                      );
                    }
                    var dataChange = this.suiviProjetDatabase?.dataChange.value as PlanningTravauxModel[];
                    this.currentProjetCoutTotalTTC = this.suiviProjetService.calculateCoutTotal(dataChange);
                  }
                  else {
                    this.showNotification(
                      'snackbar-danger',
                      response.message,
                      'bottom',
                      'right'
                    );
                  }
                }
              });
      }
    });
  }

  detailMateriels(row: PlanningTravauxModel) {
    this.dialog.open(DetailMaterielDialogComponent, {
      data: {
        planningTravauxId: row.planningTravauxId,
        activiteLibelle: row.activiteTypeLibelle,
        materiels: row.materiels,
        action: 'details',
      },
      // height: '70%',
      width: '60%',
    });
  }

  refresh() {
    this.loadData();
  }

  private refreshTable() {
    this.paginator._changePageSize(this.paginator.pageSize);
  }

  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.renderedData.length;
    return numSelected === numRows;
  }

  /** Selects all rows if they are not all selected; otherwise clear selection. */
  masterToggle() {
    this.isAllSelected()
      ? this.selection.clear()
      : this.dataSource.renderedData.forEach((row) =>
          this.selection.select(row)
        );
  }
  
  removeSelectedRows() {
    const totalSelect = this.selection.selected.length;
    this.selection.selected.forEach((item) => {
      const index: number = this.dataSource.renderedData.findIndex(
        (d) => d === item
      );
      // console.log(this.dataSource.renderedData.findIndex((d) => d === item));
      this.suiviProjetDatabase?.dataChange.value.splice(index, 1);
      this.refreshTable();
      this.selection = new SelectionModel<PlanningTravauxModel>(true, []);
    });
    this.showNotification(
      'snackbar-danger',
      totalSelect + ' Record Delete Successfully...!!!',
      'bottom',
      'center'
    );
  }

  public loadData() {
    this.suiviProjetDatabase = new SuiviProjetService(this.httpClient);
    this.dataSource = new SuiviProjetDataSource(
      this.suiviProjetDatabase,
      this.activatedRoute,
      this.paginator,
      this.sort
    );
    this.subs.sink = fromEvent(this.filter?.nativeElement, 'keyup').subscribe(
      () => {
        if (!this.dataSource) {
          return;
        }
        this.dataSource.filter = this.filter?.nativeElement.value;
      }
    );
  }

  exportExcel() {
    const exportData: Partial<TableElement>[] =
      this.dataSource.filteredData.map((x) => ({
        'Activité': x.activiteTypeLibelle,
        //'Type sous-traitant': x.sousTraitantTypeLibelle,
        'Société sous-traitant': x.sousTraitantNomSociete,
        'Immeuble': x.selectedImmeubleNom,
        'Appartement': x.selectedAppartementReference,
        'Date début': x.debutDate.toString(),
        'Date fin': x.finDate.toString()
      }));
    TableExportUtil.exportToExcel(exportData, 'excel');
  }

}

export class SuiviProjetDataSource extends DataSource<PlanningTravauxModel> {
  filterChange = new BehaviorSubject('');
  get filter(): string {
    return this.filterChange.value;
  }
  set filter(filter: string) {
    this.filterChange.next(filter);
  }
  filteredData: PlanningTravauxModel[] = [];
  renderedData: PlanningTravauxModel[] = [];
  currentProjetCoutTotalTTC: string;

  constructor(public suiviProjetDatabase: SuiviProjetService,
              public activatedRoute: ActivatedRoute,
              public paginator: MatPaginator,
              public _sort: MatSort) {
    super();
    // Reset to the first page when the user changes the filter.
    this.filterChange.subscribe(() => (this.paginator.pageIndex = 0));
  }
  
  connect(): Observable<PlanningTravauxModel[]> {
    const displayDataChanges = [
      this.suiviProjetDatabase.dataChange,
      this._sort.sortChange,
      this.filterChange,
      this.paginator.page,
    ];

    const operationId = this.activatedRoute.snapshot.queryParamMap.get('operationId');
    this.suiviProjetDatabase.getAllPlanningTravauxByOperationId(operationId);
    return merge(...displayDataChanges).pipe(
      map(() => {
        // Filter data
        this.filteredData = this.suiviProjetDatabase.data
          .slice()
          .filter((planning: PlanningTravauxModel) => {
            const searchStr = (
              planning.activiteTypeLibelle +
              planning.sousTraitantNomSociete +
              planning.selectedImmeubleNom +
              planning.selectedAppartementReference
            ).toLowerCase();
            return searchStr.indexOf(this.filter.toLowerCase()) !== -1;
          });
        const sortedData = this.sortData(this.filteredData.slice());
        const startIndex = this.paginator.pageIndex * this.paginator.pageSize;
        this.renderedData = sortedData.splice(
          startIndex,
          this.paginator.pageSize
        );
        if(this.renderedData.length > 0) {
          this.currentProjetCoutTotalTTC = this.suiviProjetDatabase.calculateCoutTotal(this.renderedData);
        }
          
        return this.renderedData;
      })
    );
  }

  disconnect() {}
  
  sortData(data: PlanningTravauxModel[]): PlanningTravauxModel[] {
    if (!this._sort.active || this._sort.direction === '') {
      return data;
    }
    return data.sort((a, b) => {
      let propertyA: number | string = '';
      let propertyB: number | string = '';
      switch (this._sort.active) {
        case 'activiteTypeLibelle':
          [propertyA, propertyB] = [a.activiteTypeLibelle, b.activiteTypeLibelle];
          break;
        case 'sousTraitantNomSociete':
          [propertyA, propertyB] = [a.sousTraitantNomSociete, b.sousTraitantNomSociete];
          break;
        case 'selectedImmeubleNom':
          [propertyA, propertyB] = [a.selectedImmeubleNom, b.selectedImmeubleNom];
          break;
        case 'selectedAppartementReference':
          [propertyA, propertyB] = [a.selectedAppartementReference, b.selectedAppartementReference];
          break;
      }
      const valueA = isNaN(+propertyA) ? propertyA : +propertyA;
      const valueB = isNaN(+propertyB) ? propertyB : +propertyB;
      return (
        (valueA < valueB ? -1 : 1) * (this._sort.direction === 'asc' ? 1 : -1)
      );
    });
  }
}
