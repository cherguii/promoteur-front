import { LOCALE_ID, NgModule } from '@angular/core';
import { CommonModule, DatePipe, registerLocaleData } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ComponentsModule } from '@shared/components/components.module';
import { SharedModule } from '@shared';
import { PagesRoutingModule } from './pages-routing.module';
import { GalleryModule } from '@ks89/angular-modal-gallery';
import { NgScrollbarModule } from 'ngx-scrollbar';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { NgxMatSelectSearchModule } from 'ngx-mat-select-search';
import localeFr from '@angular/common/locales/fr';

import { HomeComponent } from './home/home.component';

import { NgxMaskDirective, NgxMaskPipe, provideNgxMask } from 'ngx-mask';
// import { DocteurService } from '@core/service/docteur.service';
// import { PatientService } from '@core/service/patient.service';
import { MaterielService } from '@core/service/materiel.service';
import { ProjetService } from '@core/service/projet.service';
import { ImmeubleService } from '@core/service/immeuble.service';
import { AppartementService } from '@core/service/appartement.service';

import { AllMaterielComponent } from './materiel/all-materiel.component';
import { EditMaterielDialogComponent } from './materiel/dialogs/form-dialog/edit-materiel-dialog.component';
import { DeleteMaterielDialogComponent } from './materiel/dialogs/delete-materiel/delete-materiel-dialog.component';

import { ProjetItemComponent } from './projet/projet-item/projet-item.component';
import { ProjetDetailComponent } from './projet/projet-detail/projet-detail.component';
import { AddImmeubleDialogComponent } from './projet/projet-detail/dialogs/add-immeuble/add-immeuble-dialog.component';

import { ImmeubleDetailComponent } from './projet/immeuble/immeuble-detail.component';
import { EditImmeubleDialogComponent } from './projet/immeuble/dialogs/edit-immeuble/edit-immeuble-dialog.component';

import { AddAppartementDialogComponent } from './projet/immeuble/dialogs/add-appartement/add-appartement-dialog.component';
import { DeleteAppartementDialogComponent } from './projet/immeuble/dialogs/delete-appartement/delete-appartement-dialog.component';
import { DeleteImmeubleDialogComponent } from './projet/projet-detail/dialogs/delete-immeuble/delete-immeuble-dialog.component';
import { EditProjetDialogComponent } from './projet/projet-detail/dialogs/edit-projet/edit-projet-dialog.component';
import { EditAppartementDialogComponent } from './projet/immeuble/dialogs/edit-appartement/edit-appartement-dialog.component';
import { DeleteProjetDialogComponent } from './projet/projet-item/dialogs/delete-projet-item/delete-projet-dialog.component';
import { SuiviProjetComponent } from './suivi-projet/suivi-projet.component';
import { AddEditActiviteDialogComponent } from './suivi-projet/dialogs/add-edit-activite/add-edit-activite-dialog.component';
import { SuiviProjetService } from '@core/service/suivi-projet.service';
import { SousTraitantService } from '@core/service/sous-traitant.service';
import { AllSousTraitantComponent } from './sous-traitant/all-sous-traitant.component';
import { EditSousTraitantDialogComponent } from './sous-traitant/dialogs/form-dialog/edit-sous-traitant-dialog.component';
import { DeleteSousTraitantDialogComponent } from './sous-traitant/dialogs/delete-sous-traitant/delete-sous-traitant-dialog.component';
import { DeleteActiviteDialogComponent } from './suivi-projet/dialogs/delete-activite/delete-activite-dialog.component';
import { DetailMaterielDialogComponent } from './suivi-projet/dialogs/detail-materiel/detail-materiel-dialog.component';
import { DateAdapter, NativeDateAdapter } from '@angular/material/core';

registerLocaleData(localeFr);

export class FrenchDateAdapter extends NativeDateAdapter {
  override parse(value: any): Date | null {
    if ((typeof value === 'string') && (value.indexOf('/') > -1)) {
      const str = value.split('/');
      if (str.length < 2 || isNaN(+str[0]) || isNaN(+str[1]) || isNaN(+str[2])) {
        return null;
      }
      return new Date(Number(str[2]), Number(str[1]) - 1, Number(str[0]), 12);
    }
    const timestamp = typeof value === 'number' ? value : Date.parse(value);
    return isNaN(timestamp) ? null : new Date(timestamp);
  }
}

@NgModule({
  declarations: [
    
    HomeComponent,
    
    AllMaterielComponent,
    EditMaterielDialogComponent,
    DeleteMaterielDialogComponent,

    AllSousTraitantComponent,
    EditSousTraitantDialogComponent,
    DeleteSousTraitantDialogComponent,

    ProjetItemComponent,
    DeleteProjetDialogComponent,

    ProjetDetailComponent,
    
    EditProjetDialogComponent,
    AddImmeubleDialogComponent,
    DeleteImmeubleDialogComponent,

    ImmeubleDetailComponent,
    EditImmeubleDialogComponent,
    AddAppartementDialogComponent,
    EditAppartementDialogComponent,
    DeleteAppartementDialogComponent,

    SuiviProjetComponent,
    AddEditActiviteDialogComponent,
    DeleteActiviteDialogComponent,
    DetailMaterielDialogComponent,
    
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    PagesRoutingModule,
    ComponentsModule,
    NgxMaskDirective,
    NgxMaskPipe,
    SharedModule,
    GalleryModule,
    NgScrollbarModule,
    DragDropModule,
    NgxMatSelectSearchModule,
    
  ],
  providers: [
    // DocteurService,
    // PatientService,
    MaterielService,
    ProjetService,
    ImmeubleService,
    AppartementService,
    SuiviProjetService,
    SousTraitantService,
    provideNgxMask(),
    DatePipe,
    { provide: LOCALE_ID, useValue: 'fr-FR'},
    { provide: DateAdapter, useClass: FrenchDateAdapter },
  ],
})
export class PagesModule {}
