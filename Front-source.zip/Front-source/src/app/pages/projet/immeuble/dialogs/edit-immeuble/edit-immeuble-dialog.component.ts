import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { Component, Inject } from '@angular/core';
import { UntypedFormGroup, UntypedFormBuilder, } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { CommonHelper } from '@core/helpers/common-helper';
import { ImmeubleItemModel } from '@core/models/immeuble-item.model';
import { ImmeubleService } from '@core/service/immeuble.service';
import { ActivatedRoute } from '@angular/router';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ProjetService } from '@core/service/projet.service';

export interface DialogData {
  id: number;
  immeuble: ImmeubleItemModel;
}

@Component({
  selector: 'app-edit-immeuble-dialog:not(f)',
  templateUrl: './edit-immeuble-dialog.component.html',
  styleUrls: ['./edit-immeuble-dialog.component.scss'],
})
export class EditImmeubleDialogComponent {

 // Fields.
 dialogTitle: string;
 immeubleForm: UntypedFormGroup;
 currentImmeuble: ImmeubleItemModel;
 demarrageProjetDate: string;
 finProjetDate: string;
 surfaceTotalProjet: number;
 surfaceTotalAllImmeuble: number;

 // Ctor.
 constructor(public dialogRef: MatDialogRef<EditImmeubleDialogComponent>,
             @Inject(MAT_DIALOG_DATA) public data: DialogData,
             private projetService: ProjetService,
             private immeubleService: ImmeubleService,
             private activatedRoute: ActivatedRoute,
             public datepipe: DatePipe,
             private fb: UntypedFormBuilder,
             private snackBar: MatSnackBar) {
  this.dialogTitle = `Immeuble ${data.immeuble.nom}`;
  this.currentImmeuble = data.immeuble;
  this.immeubleForm = this.createContactForm();
  this.dialogRef.disableClose = true;
 }

 ngOnInit() {
  this.loadCurretProjetItem();
 }

 loadCurretProjetItem() {
  this.projetService.getProjetDetailById(this.currentImmeuble.operationId)
              .subscribe({
                next: (response) => {
                  if(this.projetService.isGetProjetByIdOK === true) {
                    this.demarrageProjetDate = response.demarrageDate;
                    this.finProjetDate = response.finDate;
                    this.surfaceTotalProjet = response.surfaceTotal,
                    this.surfaceTotalAllImmeuble = this.sumSurfaceTotalAllImmeuble(response.immeubles)
                  }
                  else {
                    this.showNotification(
                      'snackbar-danger',
                      response.message,
                      'bottom',
                      'right'
                    );
                  }
                }
              });
 }

 sumSurfaceTotalAllImmeuble(immeubles: ImmeubleItemModel[]) {
  var surfaceTotalAllImmeuble = 0;
  immeubles.forEach(immeuble => {
    if(immeuble.immeubleId !== this.currentImmeuble.immeubleId)
      surfaceTotalAllImmeuble += immeuble.surfaceTotal;
  });
  return surfaceTotalAllImmeuble;
}

 createContactForm(): UntypedFormGroup {
   return this.fb.group({
    operationId: [this.currentImmeuble.operationId],
    immeubleId: [this.currentImmeuble.immeubleId],
    nom: [this.currentImmeuble.nom],
    numero: [this.currentImmeuble.numero],
    nombreEtage: [this.currentImmeuble.nombreEtage],
    surfaceTotal: [this.currentImmeuble.surfaceTotal],
    avecSousSol: [this.currentImmeuble.avecSousSol],
    debutConstructionDate: [CommonHelper.formatDate2(this.currentImmeuble.debutConstructionDate)],
    finConstructionDate: [CommonHelper.formatDate2(this.currentImmeuble.finConstructionDate)],
   });
 }
 
 public confirmSave(): void {
  this.immeubleService.currentImmeuble = this.immeubleForm.getRawValue();

  var newSurfaceTotalImmeuble = this.surfaceTotalAllImmeuble + this.immeubleService.currentImmeuble.surfaceTotal;
  if(newSurfaceTotalImmeuble > this.surfaceTotalProjet) {
    var diferenceSurface = this.surfaceTotalProjet - this.surfaceTotalAllImmeuble;
    this.showNotification(
      'snackbar-danger',
      `Vous avez dépasser la surface total du projet, il reste : ${diferenceSurface} m² a utiliser pour cette immeuble.`,
      'bottom',
      'right'
    );
    return;
  }

  const demarrageProjetDate = new Date(CommonHelper.formatDateUS(this.demarrageProjetDate));
  const finProjetDate = new Date(CommonHelper.formatDateUS(this.finProjetDate));
  
  if(this.immeubleService.currentImmeuble.debutConstructionDate.getTime() < demarrageProjetDate.getTime()) {
    this.showNotification(
      'snackbar-danger',
      'La date de début de construction de l\'immeuble doit être inférieur ou égale à la date de début du projet.',
      'bottom',
      'right'
    );
    return;
  }

  if(this.immeubleService.currentImmeuble.finConstructionDate.getTime() > finProjetDate.getTime()) {
    this.showNotification(
      'snackbar-danger',
      'La date de fin de construction de l\'immeuble doit être inférieur ou égale à la date de début du projet.',
      'bottom',
      'right'
    );
    return;
  }

  const operationId = this.activatedRoute.snapshot.queryParamMap.get('operationId');
  this.immeubleService.currentImmeuble.operationId = operationId;

  if(this.immeubleService.currentImmeuble.debutConstructionDate !== '')
   this.immeubleService.currentImmeuble.debutConstructionDate = CommonHelper.formatDate(this.immeubleService.currentImmeuble.debutConstructionDate);
  else
   this.immeubleService.currentImmeuble.debutConstructionDate = null;

  if(this.immeubleService.currentImmeuble.finConstructionDate !== '')
    this.immeubleService.currentImmeuble.finConstructionDate = CommonHelper.formatDate(this.immeubleService.currentImmeuble.finConstructionDate);
  else
    this.immeubleService.currentImmeuble.finConstructionDate = null;

  this.dialogRef.close(1);
 }

 onNoClick(): void {
  this.dialogRef.close();
}

 // showNotification.
 showNotification(colorName: any, text: any, placementFrom: any, placementAlign: any) {
  this.snackBar.open(text, '', {
    duration: 5000,
    verticalPosition: placementFrom,
    horizontalPosition: placementAlign,
    panelClass: colorName,
  });
 }

}
