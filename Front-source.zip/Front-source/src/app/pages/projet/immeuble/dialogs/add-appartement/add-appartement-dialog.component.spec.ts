import { ComponentFixture, TestBed, waitForAsync } from "@angular/core/testing";
import { AddAppartementDialogComponent } from "./add-appartement-dialog.component";

describe("AddAppartementDialogComponent", () => {
  let component: AddAppartementDialogComponent;
  let fixture: ComponentFixture<AddAppartementDialogComponent>;
  beforeEach(
    waitForAsync(() => {
      TestBed.configureTestingModule({
        declarations: [AddAppartementDialogComponent],
      }).compileComponents();
    })
  );
  beforeEach(() => {
    fixture = TestBed.createComponent(AddAppartementDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });
  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
