import { ComponentFixture, TestBed, waitForAsync } from "@angular/core/testing";
import { EditAppartementDialogComponent } from "./edit-appartement-dialog.component";

describe("EditAppartementDialogComponent", () => {
  let component: EditAppartementDialogComponent;
  let fixture: ComponentFixture<EditAppartementDialogComponent>;
  beforeEach(
    waitForAsync(() => {
      TestBed.configureTestingModule({
        declarations: [EditAppartementDialogComponent],
      }).compileComponents();
    })
  );
  beforeEach(() => {
    fixture = TestBed.createComponent(EditAppartementDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });
  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
