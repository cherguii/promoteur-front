import { MatDialogRef } from '@angular/material/dialog';
import { Component } from '@angular/core';
import { UntypedFormControl, Validators, UntypedFormGroup, UntypedFormBuilder, } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { ActivatedRoute } from '@angular/router';
import { AppartementService } from '@core/service/appartement.service';
import { AppartementModel } from '@core/models/appartement.model';
import { ReferentialService } from '@core/service/referential.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ReferentielModel } from '@core/models/referentiel.model';

@Component({
  selector: 'app-add-appartement-dialog:not(f)',
  templateUrl: './add-appartement-dialog.component.html',
  styleUrls: ['./add-appartement-dialog.component.scss'],
})
export class AddAppartementDialogComponent {

 // Fields.
 dialogTitle: string;
 appartementForm: UntypedFormGroup;
 currentAppartement: AppartementModel;
 appartementTypes: ReferentielModel[];
 positionAppartements: ReferentielModel[];
 cuisineTypes: ReferentielModel[];

 // upload photo.
 fileData: File;
 previewUrl: any = null;
 backgroundImagePhoto = '';
 backgroundImageSize = '';
 fileAsBase64: string;
 
 // Ctor.
 constructor(public dialogRef: MatDialogRef<AddAppartementDialogComponent>,
             private appartementService: AppartementService,
             private referentialService: ReferentialService,
             private activatedRoute: ActivatedRoute,
             public datepipe: DatePipe,
             private fb: UntypedFormBuilder,
             private snackBar: MatSnackBar) {

    this.dialogTitle = 'Nouveau appartement';
    this.currentAppartement = new AppartementModel();
    this.appartementForm = this.createContactForm();
    this.dialogRef.disableClose = true;
 }

 ngOnInit() {
  this.fillAppartementTypes();
  this.fillPositionAppartements();
  this.fillCuisineTypes();
  this.initPhotos();
 }

 fillAppartementTypes() {
  this.referentialService.getAllAppartementType()
          .subscribe({
            next: (response) => {
             if(this.referentialService.isGetAllAppartementTypeOk === true) {
               this.appartementTypes = response;
             }
             else {
               this.showNotification(
                 'snackbar-danger',
                 response.message,
                 'bottom',
                 'right'
               );
             }
            }
          });
  
 }

 fillPositionAppartements() {
  this.referentialService.getAllPositionAppartement()
          .subscribe({
            next: (response) => {
             if(this.referentialService.isGetAllPositionAppartementOk === true) {
               this.positionAppartements = response;
             }
             else {
               this.showNotification(
                 'snackbar-danger',
                 response.message,
                 'bottom',
                 'right'
               );
             }
            }
          });
  
 }

 fillCuisineTypes() {
  this.referentialService.getAllCuisineType()
          .subscribe({
            next: (response) => {
             if(this.referentialService.isGetAllCuisineTypeOk === true) {
               this.cuisineTypes = response;
             }
             else {
               this.showNotification(
                 'snackbar-danger',
                 response.message,
                 'bottom',
                 'right'
               );
             }
            }
          });
  
 }

  // initPhotos.
  initPhotos() {
    this.backgroundImagePhoto = 'url(assets/images/no-image.png)';
    this.backgroundImageSize = '70%';
  }

 createContactForm(): UntypedFormGroup {
   return this.fb.group({
    operationId: [this.currentAppartement.operationId],
    immeubleId: [this.currentAppartement.immeubleId],
    appartementId: [this.currentAppartement.appartementId],
    reference: [this.currentAppartement.reference],
    numeroEtage: [this.currentAppartement.numeroEtage],
    surfaceTotal: [this.currentAppartement.surfaceTotal],
    appartementTypeCode: [this.currentAppartement.appartementTypeCode],
    appartementTypeLibelle: [this.currentAppartement.appartementTypeLibelle],
    positionAppartementCode: [this.currentAppartement.positionAppartementCode],
    positionAppartementLibelle: [this.currentAppartement.positionAppartementLibelle],
    cuisineTypeCode: [this.currentAppartement.cuisineTypeCode],
    cuisineTypeLibelle: [this.currentAppartement.cuisineTypeLibelle],
   });
 }
 
 public confirmSave(): void {
   this.appartementService.currentAppartement = this.appartementForm.getRawValue();

   const operationId = this.activatedRoute.snapshot.queryParamMap.get('operationId');
   const immeubleId = this.activatedRoute.snapshot.queryParamMap.get('immeubleId');
   this.appartementService.currentAppartement.operationId = operationId;
   this.appartementService.currentAppartement.immeubleId = immeubleId;
   this.appartementService.currentAppartement.appartementId = '00000000-0000-0000-0000-000000000000';
   this.appartementService.currentAppartement.photoPlanBase64 = this.fileAsBase64;

   this.dialogRef.close(1);
 }

 onNoClick(): void {
  this.dialogRef.close();
}

 // showNotification.
 showNotification(colorName: any, text: any, placementFrom: any, placementAlign: any) {
    this.snackBar.open(text, '', {
      duration: 5000,
      verticalPosition: placementFrom,
      horizontalPosition: placementAlign,
      panelClass: colorName,
    });
  }

  /******** Photos *********/
  // fileChangeImage.
  fileChangeImage(fileInput: any) {
    this.fileData = <File>fileInput.target.files[0];
    this.previewFile();
  }

  // previewFile.
  previewFile() {
    var mimeType = this.fileData.type;
    if (mimeType.match(/image\/*/) == null) {
      return;
    }

    var reader = new FileReader();
    reader.readAsDataURL(this.fileData);
    reader.onload = (_event) => {
      this.backgroundImagePhoto = 'url(' + reader.result + ')';
      this.backgroundImageSize = 'cover';
      this.previewUrl = reader.result;
      this.fileAsBase64 = reader.result !== null ? reader.result.toString() : '';
    }
  }

  // removePhoto.
  removePhoto() {
    this.backgroundImagePhoto = 'url(assets/images/no-image.png)';
    this.backgroundImageSize = '70%';
    this.previewUrl = null;
    this.fileAsBase64 = '';
  }

}
