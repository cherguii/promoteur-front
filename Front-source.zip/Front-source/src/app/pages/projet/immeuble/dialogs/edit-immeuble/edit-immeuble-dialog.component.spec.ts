import { ComponentFixture, TestBed, waitForAsync } from "@angular/core/testing";
import { EditImmeubleDialogComponent } from "./edit-immeuble-dialog.component";

describe("EditImmeubleDialogComponent", () => {
  let component: EditImmeubleDialogComponent;
  let fixture: ComponentFixture<EditImmeubleDialogComponent>;
  beforeEach(
    waitForAsync(() => {
      TestBed.configureTestingModule({
        declarations: [EditImmeubleDialogComponent],
      }).compileComponents();
    })
  );
  beforeEach(() => {
    fixture = TestBed.createComponent(EditImmeubleDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });
  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
