import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { Component, Inject } from '@angular/core';
import { AppartementService } from '@core/service/appartement.service';
import { AppartementModel } from '@core/models/appartement.model';

export interface DialogData {
  id: number;
  action: string;
  appartement: AppartementModel;
}

@Component({
  selector: 'app-delete-appartement-dialog:not(i)',
  templateUrl: './delete-appartement-dialog.component.html',
  styleUrls: ['./delete-appartement-dialog.component.scss'],
})
export class DeleteAppartementDialogComponent {

  // Fields.
  appartement: AppartementModel;

  // Ctor.
  constructor(public dialogRef: MatDialogRef<DeleteAppartementDialogComponent>,
              @Inject(MAT_DIALOG_DATA) public data: DialogData,
              private appartementService: AppartementService) {
      this.appartement = data.appartement;
  }

  onNoClick(): void {
    this.dialogRef.close();
  }
  
  confirmDelete(): void {
    this.appartementService.currentAppartement = this.appartement;
  }
}
