import { ComponentFixture, TestBed, waitForAsync } from "@angular/core/testing";
import { DeleteAppartementDialogComponent } from "./delete-appartement-dialog.component";

describe("DeleteAppartementDialogComponent", () => {
  let component: DeleteAppartementDialogComponent;
  let fixture: ComponentFixture<DeleteAppartementDialogComponent>;

  beforeEach(
    waitForAsync(() => {
      TestBed.configureTestingModule({
        declarations: [DeleteAppartementDialogComponent],
      }).compileComponents();
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(DeleteAppartementDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
