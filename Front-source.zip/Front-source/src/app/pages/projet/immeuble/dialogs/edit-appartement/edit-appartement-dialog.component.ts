import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Component, Inject } from '@angular/core';
import { UntypedFormControl, Validators, UntypedFormGroup, UntypedFormBuilder, } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { ActivatedRoute } from '@angular/router';
import { AppartementService } from '@core/service/appartement.service';
import { AppartementModel } from '@core/models/appartement.model';
import { ReferentialService } from '@core/service/referential.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ReferentielModel } from '@core/models/referentiel.model';

import { Image, 
         LineLayout, 
         PlainGalleryConfig, 
         PlainGalleryStrategy, 
         ModalGalleryService, 
         ModalGalleryRef, 
         PlainLibConfig, 
         ModalLibConfig, 
         ModalGalleryConfig } from '@ks89/angular-modal-gallery';

export interface DialogData {
  id: number;
  appartement: AppartementModel;
}

@Component({
  selector: 'app-edit-appartement-dialog:not(f)',
  templateUrl: './edit-appartement-dialog.component.html',
  styleUrls: ['./edit-appartement-dialog.component.scss'],
})
export class EditAppartementDialogComponent {

 // Fields.
 dialogTitle: string;
 appartementForm: UntypedFormGroup;
 currentAppartement: AppartementModel;
 appartementTypes: ReferentielModel[];
 positionAppartements: ReferentielModel[];
 cuisineTypes: ReferentielModel[];

 // upload photo.
 fileData: File;
 previewUrl: any = null;
 backgroundImagePhoto = '';
 backgroundImageSize = '';
 fileAsBase64: string;
 curentPhoto: string;

 //Config GaleryModule.
 plainGalleryRow: PlainGalleryConfig;
 libConfigPlainGalleryRow: PlainLibConfig;
 galleryImages: Array<Image>;
 
 // Ctor.
 constructor(public dialogRef: MatDialogRef<EditAppartementDialogComponent>,
             @Inject(MAT_DIALOG_DATA) public data: DialogData,
             private appartementService: AppartementService,
             private referentialService: ReferentialService,
             private modalGalleryService: ModalGalleryService,
             private activatedRoute: ActivatedRoute,
             public datepipe: DatePipe,
             private fb: UntypedFormBuilder,
             private snackBar: MatSnackBar) {

    this.dialogTitle = `Appartement ${data.appartement.reference}`;
    this.currentAppartement = data.appartement;
    this.appartementForm = this.createContactForm();
    this.dialogRef.disableClose = true;
 }

 ngOnInit() {
  this.fillAppartementTypes();
  this.fillPositionAppartements();
  this.fillCuisineTypes();
  this.initPhotos();
  this.loadPhotos();
  this.setGalleryOption();
 }

 fillAppartementTypes() {
  this.referentialService.getAllAppartementType()
          .subscribe({
            next: (response) => {
             if(this.referentialService.isGetAllAppartementTypeOk === true) {
               this.appartementTypes = response;
             }
             else {
               this.showNotification(
                 'snackbar-danger',
                 response.message,
                 'bottom',
                 'right'
               );
             }
            }
          });
  
 }

 fillPositionAppartements() {
  this.referentialService.getAllPositionAppartement()
          .subscribe({
            next: (response) => {
             if(this.referentialService.isGetAllPositionAppartementOk === true) {
               this.positionAppartements = response;
             }
             else {
               this.showNotification(
                 'snackbar-danger',
                 response.message,
                 'bottom',
                 'right'
               );
             }
            }
          });
  
 }

 fillCuisineTypes() {
  this.referentialService.getAllCuisineType()
          .subscribe({
            next: (response) => {
             if(this.referentialService.isGetAllCuisineTypeOk === true) {
               this.cuisineTypes = response;
             }
             else {
               this.showNotification(
                 'snackbar-danger',
                 response.message,
                 'bottom',
                 'right'
               );
             }
            }
          });
  
 }

 // initPhotos.
 initPhotos() {
    if (this.currentAppartement.photoPlanBase64 === null || this.currentAppartement.photoPlanBase64 === undefined) {
      this.backgroundImagePhoto = 'url(assets/images/no-image.png)';
      this.backgroundImageSize = '70%';
      this.previewUrl = null;
      this.fileAsBase64 = '';
    }
    else {
      this.backgroundImagePhoto = 'url(' + this.currentAppartement.photoPlanBase64 + ')';
      this.backgroundImageSize = 'cover';
      this.previewUrl = this.currentAppartement.photoPlanBase64;
      this.fileAsBase64 = this.currentAppartement.photoPlanBase64;
      this.curentPhoto = this.currentAppartement.photoPlanBase64;
    }
 }

 // loadPhotos.
 loadPhotos() {
  var photo;
  this.galleryImages = new Array<Image>();
  if(this.curentPhoto !== '') {
    photo = new Image(0, {
        img: this.curentPhoto,
        extUrl: ''
      }),
    this.galleryImages.push(photo);
  }

}

onShowImage(id: number, image: Image): void {
  const imageIndex: number = this.getCurrentIndexCustomLayout(image, this.galleryImages);
  const dialogRef: ModalGalleryRef = this.modalGalleryService.open({
    id: id,
    images: this.galleryImages,
    currentImage: this.galleryImages[imageIndex],
    libConfig: {
      slideConfig: {
        infinite: true,
        sidePreviews: {
          show: false
        }
      }
    } as ModalLibConfig
  } as ModalGalleryConfig) as ModalGalleryRef;
}

// getCurrentIndexCustomLayout.
private getCurrentIndexCustomLayout(image: Image, galleryImages: Image[]): number {
  return image ? galleryImages.indexOf(image) : -1;
}

// setGalleryOption.
setGalleryOption() {
  this.plainGalleryRow = {
    strategy: PlainGalleryStrategy.ROW,
    layout: new LineLayout({ width: '80px', height: '80px' }, { length: 2, wrap: true }, 'flex-start')
  };

  this.libConfigPlainGalleryRow = {
    plainGalleryConfig: this.plainGalleryRow
  };
}

 createContactForm(): UntypedFormGroup {
   return this.fb.group({
    operationId: [this.currentAppartement.operationId],
    immeubleId: [this.currentAppartement.immeubleId],
    appartementId: [this.currentAppartement.appartementId],
    reference: [this.currentAppartement.reference],
    numeroEtage: [this.currentAppartement.numeroEtage],
    surfaceTotal: [this.currentAppartement.surfaceTotal],
    appartementTypeCode: [this.currentAppartement.appartementTypeCode],
    appartementTypeLibelle: [this.currentAppartement.appartementTypeLibelle],
    positionAppartementCode: [this.currentAppartement.positionAppartementCode],
    positionAppartementLibelle: [this.currentAppartement.positionAppartementLibelle],
    cuisineTypeCode: [this.currentAppartement.cuisineTypeCode],
    cuisineTypeLibelle: [this.currentAppartement.cuisineTypeLibelle],
   });
 }

 public confirmSave(): void {
   this.appartementService.currentAppartement = this.appartementForm.getRawValue();

   const operationId = this.activatedRoute.snapshot.queryParamMap.get('operationId');
   const immeubleId = this.activatedRoute.snapshot.queryParamMap.get('immeubleId');
   this.appartementService.currentAppartement.operationId = operationId;
   this.appartementService.currentAppartement.immeubleId = immeubleId;
   this.appartementService.currentAppartement.photoPlanBase64 = this.fileAsBase64;

   this.dialogRef.close(1);
 }

 onNoClick(): void {
  this.dialogRef.close();
}

 // showNotification.
 showNotification(colorName: any, text: any, placementFrom: any, placementAlign: any) {
  this.snackBar.open(text, '', {
    duration: 5000,
    verticalPosition: placementFrom,
    horizontalPosition: placementAlign,
    panelClass: colorName,
  });
}

/******** Photos *********/
  // fileChangeImage.
  fileChangeImage(fileInput: any) {
    this.fileData = <File>fileInput.target.files[0];
    this.previewFile();
  }

  // previewFile.
  previewFile() {
    var mimeType = this.fileData.type;
    if (mimeType.match(/image\/*/) == null) {
      return;
    }

    var reader = new FileReader();
    reader.readAsDataURL(this.fileData);
    reader.onload = (_event) => {
      this.backgroundImagePhoto = 'url(' + reader.result + ')';
      this.backgroundImageSize = 'cover';
      this.previewUrl = reader.result;
      this.fileAsBase64 = reader.result !== null ? reader.result.toString() : '';
    }
  }

  // removePhoto.
  removePhoto() {
    this.backgroundImagePhoto = 'url(assets/images/no-image.png)';
    this.backgroundImageSize = '70%';
    this.previewUrl = null;
    this.fileAsBase64 = '';
  }

}
