import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ActivatedRoute, Router } from '@angular/router';
import { ImmeubleDetailModel } from '@core/models/immeuble-detail.model';
import { ImmeubleService } from '@core/service/immeuble.service';
import { EditImmeubleDialogComponent } from './dialogs/edit-immeuble/edit-immeuble-dialog.component';
import { AddAppartementDialogComponent } from './dialogs/add-appartement/add-appartement-dialog.component';
import { AppartementService } from '@core/service/appartement.service';
import { AppartementModel } from '@core/models/appartement.model';
import { DeleteAppartementDialogComponent } from './dialogs/delete-appartement/delete-appartement-dialog.component';
import { EditAppartementDialogComponent } from './dialogs/edit-appartement/edit-appartement-dialog.component';

@Component({
  selector: 'app-immeuble-detail',
  templateUrl: './immeuble-detail.component.html',
  styleUrls: ['./immeuble-detail.component.scss'],
})
export class ImmeubleDetailComponent implements OnInit {

  // Fields.
  currentImmeuble: ImmeubleDetailModel = new ImmeubleDetailModel();

  // Ctor.
  constructor(private immeubleService: ImmeubleService,
              private appartementService: AppartementService,
              public dialog: MatDialog,
              private router: Router,
              private activatedRoute: ActivatedRoute,
              private snackBar: MatSnackBar) {}

  ngOnInit() {
    const operationId = this.activatedRoute.snapshot.queryParamMap.get('operationId');
    const immeubleId = this.activatedRoute.snapshot.queryParamMap.get('immeubleId');
    this.loadImmeubleDetailById(operationId, immeubleId);
  }
  
  loadImmeubleDetailById(operationId: any, immeubleId: any) {
    this.immeubleService.getImmeubleDetailById(operationId, immeubleId)
              .subscribe({
                next: (response) => {
                  if(this.immeubleService.isGetImmeubleDetailByIdOK === true) {
                    this.currentImmeuble = response;
                  }
                  else {
                    this.showNotification(
                      'snackbar-danger',
                      response.message,
                      'bottom',
                      'right'
                    );
                  }
                }
              });
  }

  editImmeuble(immeuble: ImmeubleDetailModel) {
    const dialogRef = this.dialog.open(EditImmeubleDialogComponent, {
      data: {
        immeuble: immeuble,
      },
      direction: 'ltr',
    });
    dialogRef.afterClosed().subscribe((result) => {
      if (result === 1) {
        var immeubleToUpdate = this.immeubleService.currentImmeuble;
        this.immeubleService.updateImmeuble(immeubleToUpdate)
            .subscribe({
              next: (response) =>  {
                if(this.immeubleService.isEditImmeubleOK) {
                  this.currentImmeuble  = this.immeubleService.immeubleUpdate;
                  this.showNotification(
                    'snackbar-success',
                    'L\'immeuble a été mis à jour avec succès !!!',
                    'bottom',
                    'right'
                  );
                }
                else {
                  this.showNotification(
                    'snackbar-danger',
                    response.message,
                    'bottom',
                    'right'
                  );
                }
                this.immeubleService.currentImmeuble = null;
              }
            });
      }

    });
  }

  addNewAppartement() {
    const dialogRef = this.dialog.open(AddAppartementDialogComponent, {
      data: {
        action: 'add',
      },
      direction: 'ltr',
    });
    dialogRef.afterClosed().subscribe((result) => {
      if (result === 1) {
        var immeubleToAdd = this.appartementService.currentAppartement;
        this.appartementService.addAppartement(immeubleToAdd)
            .subscribe({
              next: (response) =>  {
                if(this.appartementService.isAddAppartementOk) {
                  this.currentImmeuble.appartements.push(response);
                  this.showNotification(
                    'snackbar-success',
                    'L\'appartement a été ajouté avec succès !!!',
                    'bottom',
                    'right'
                  );
                }
                else {
                  this.showNotification(
                    'snackbar-danger',
                    response.message,
                    'bottom',
                    'right'
                  );
                }
                this.immeubleService.currentImmeuble = null;
              }
            });

      }
    });
  }

  editAppartement(appartement: AppartementModel) {
    const dialogRef = this.dialog.open(EditAppartementDialogComponent, {
      data: {
        appartement: appartement,
      },
      direction: 'ltr',
    });
    dialogRef.afterClosed().subscribe((result) => {
      if (result === 1) {
        var appartementToUpdate = this.appartementService.currentAppartement;
        this.appartementService.updateAppartement(appartementToUpdate)
            .subscribe({
              next: (response) =>  {
                if(this.appartementService.isEditAppartementOK) {
                  const foundIndex = this.currentImmeuble.appartements.findIndex(
                    (x) => x.appartementId === appartementToUpdate.appartementId
                  );
                  if (foundIndex != null) {
                    this.currentImmeuble.appartements[foundIndex] = this.appartementService.appartementUpdate;
                    this.showNotification(
                      'snackbar-success',
                      'L\'appartement a été mis à jour avec succès !!!',
                      'bottom',
                      'right'
                    );
                  }
                }
                else {
                  this.showNotification(
                    'snackbar-danger',
                    response.message,
                    'bottom',
                    'right'
                  );
                }
                this.appartementService.currentAppartement = null;
              }
            });
      }

    });
  }

  deleteAppartement(appartement: AppartementModel) {
    const dialogRef = this.dialog.open(DeleteAppartementDialogComponent, {
      data: {
        appartement: appartement,
      },
      direction: 'ltr',
    });
    dialogRef.afterClosed().subscribe((result) => {
      if (result === 1) {
        var appartementToDelete = this.appartementService.currentAppartement;
        this.appartementService.deleteAppartement(appartementToDelete.operationId, appartementToDelete.immeubleId, appartementToDelete.appartementId)
            .subscribe({
              next: (response) =>  {
                if(this.appartementService.isDeleteAppartementOK) {
                  const foundIndex = this.currentImmeuble.appartements.findIndex(
                    (x) => x.appartementId === appartementToDelete.appartementId
                  );
                  if (foundIndex != null) {
                    this.currentImmeuble.appartements.splice(foundIndex, 1);
                    this.showNotification(
                      'snackbar-success',
                      'L\'appartement a été supprimé avec succès !!!',
                      'bottom',
                      'right'
                    );
                  }
                }
                else {
                  this.showNotification(
                    'snackbar-danger',
                    response.message,
                    'bottom',
                    'right'
                  );
                }
                this.appartementService.currentAppartement = null;
              }
            });
      }
    });
  }

  refresh() {
    const operationId = this.activatedRoute.snapshot.queryParamMap.get('operationId');
    const immeubleId = this.activatedRoute.snapshot.queryParamMap.get('immeubleId');
    this.loadImmeubleDetailById(operationId, immeubleId);
  }

  goToProjetPage(operationId: any) {
    this.router.navigate(['/projet-detail'], { queryParams: { operationId: operationId } });
  }

  getClassByIndex(index: any) {
    if(index === 0)
      return `bg-green`;

    if(index === 1)
      return `bg-indigo`;

    if(index === 2)
      return `bg-brown`;

    if(index === 3)
      return `l-bg-orange`;

    return `l-bg-purple-dark`;
    
  }

  // showNotification.
  showNotification(colorName: any, text: any, placementFrom: any, placementAlign: any) {
    this.snackBar.open(text, '', {
      duration: 5000,
      verticalPosition: placementFrom,
      horizontalPosition: placementAlign,
      panelClass: colorName,
    });
  }

}
