import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { ImmeubleDetailComponent } from './immeuble-detail.component';

describe('ImmeubleDetailComponent', () => {
  let component: ImmeubleDetailComponent;
  let fixture: ComponentFixture<ImmeubleDetailComponent>;

  beforeEach(
    waitForAsync(() => {
      TestBed.configureTestingModule({
        declarations: [ImmeubleDetailComponent],
      }).compileComponents();
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(ImmeubleDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
