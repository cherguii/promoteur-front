import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Component, Inject } from '@angular/core';
import { UntypedFormGroup, UntypedFormBuilder, } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { CommonHelper } from '@core/helpers/common-helper';
import { ImmeubleItemModel } from '@core/models/immeuble-item.model';
import { ImmeubleService } from '@core/service/immeuble.service';
import { ActivatedRoute } from '@angular/router';
import { MatSnackBar } from '@angular/material/snack-bar';

export interface DialogData {
  demarrageProjetDate: string;
  finProjetDate: string;
  surfaceTotalProjet: number;
  surfaceTotalAllImmeuble: number;
}

@Component({
  selector: 'app-add-immeuble-dialog:not(f)',
  templateUrl: './add-immeuble-dialog.component.html',
  styleUrls: ['./add-immeuble-dialog.component.scss'],
})
export class AddImmeubleDialogComponent {

 // Fields.
 action: string;
 dialogTitle: string;
 operationForm: UntypedFormGroup;
 currentImmeuble: ImmeubleItemModel;
 demarrageProjetDate: string;
 finProjetDate: string;
 surfaceTotalProjet: number;
 surfaceTotalAllImmeuble: number;
 
 // Ctor.
 constructor(public dialogRef: MatDialogRef<AddImmeubleDialogComponent>,
            @Inject(MAT_DIALOG_DATA) public data: DialogData,
             private immeubleService: ImmeubleService,
             private activatedRoute: ActivatedRoute,
             public datepipe: DatePipe,
             private fb: UntypedFormBuilder,
             private snackBar: MatSnackBar) {
   this.dialogTitle = 'Nouveau Immeuble';
   this.currentImmeuble = new ImmeubleItemModel();
   this.operationForm = this.createContactForm();
   this.demarrageProjetDate = data.demarrageProjetDate;
   this.finProjetDate = data.finProjetDate;
   this.surfaceTotalProjet = data.surfaceTotalProjet;
   this.surfaceTotalAllImmeuble = data.surfaceTotalAllImmeuble;
   this.dialogRef.disableClose = true;
 }

 ngOnInit() {
 }

 createContactForm(): UntypedFormGroup {
   return this.fb.group({
    operationId: [this.currentImmeuble.operationId],
    immeubleId: [this.currentImmeuble.immeubleId],
    nom: [this.currentImmeuble.nom],
    numero: [this.currentImmeuble.numero],
    nombreEtage: [this.currentImmeuble.nombreEtage],
    surfaceTotal: [this.currentImmeuble.surfaceTotal],
    avecSousSol: [this.currentImmeuble.avecSousSol],
    debutConstructionDate: [CommonHelper.formatDate2(this.currentImmeuble.debutConstructionDate)],
    finConstructionDate: [CommonHelper.formatDate2(this.currentImmeuble.finConstructionDate)],
   });
 }

 public confirmSave(): void {
  this.immeubleService.currentImmeuble = this.operationForm.getRawValue();

  var newSurfaceTotalImmeuble = this.surfaceTotalAllImmeuble + this.immeubleService.currentImmeuble.surfaceTotal;
  if(newSurfaceTotalImmeuble > this.surfaceTotalProjet) {
    var diferenceSurface = this.surfaceTotalProjet - this.surfaceTotalAllImmeuble;
    this.showNotification(
      'snackbar-danger',
      `Vous avez dépasser la surface total du projet, il reste : ${diferenceSurface} m² a utiliser pour cette immeuble.`,
      'bottom',
      'right'
    );
    return;
  }

  const demarrageProjetDate = new Date(CommonHelper.formatDateUS(this.demarrageProjetDate));
  const finProjetDate = new Date(CommonHelper.formatDateUS(this.finProjetDate));
  
  if(this.immeubleService.currentImmeuble.debutConstructionDate.getTime() < demarrageProjetDate.getTime()) {
    this.showNotification(
      'snackbar-danger',
      'La date de début de construction de l\'immeuble doit être inférieur ou égale à la date de début du projet.',
      'bottom',
      'right'
    );
    return;
  }

  if(this.immeubleService.currentImmeuble.finConstructionDate.getTime() > finProjetDate.getTime()) {
    this.showNotification(
      'snackbar-danger',
      'La date de fin de construction de l\'immeuble doit être inférieur ou égale à la date de début du projet.',
      'bottom',
      'right'
    );
    return;
  }

  const operationId = this.activatedRoute.snapshot.queryParamMap.get('operationId');
  this.immeubleService.currentImmeuble.operationId = operationId;
  this.immeubleService.currentImmeuble.immeubleId = '00000000-0000-0000-0000-000000000000';

  if(this.immeubleService.currentImmeuble.debutConstructionDate !== '')
  this.immeubleService.currentImmeuble.debutConstructionDate = CommonHelper.formatDate(this.immeubleService.currentImmeuble.debutConstructionDate);
  else
  this.immeubleService.currentImmeuble.debutConstructionDate = null;

  if(this.immeubleService.currentImmeuble.finConstructionDate !== '')
    this.immeubleService.currentImmeuble.finConstructionDate = CommonHelper.formatDate(this.immeubleService.currentImmeuble.finConstructionDate);
  else
    this.immeubleService.currentImmeuble.finConstructionDate = null;

  this.dialogRef.close(1);
 }

 onNoClick(): void {
  this.dialogRef.close();
}

 // showNotification.
 showNotification(colorName: any, text: any, placementFrom: any, placementAlign: any) {
  this.snackBar.open(text, '', {
    duration: 5000,
    verticalPosition: placementFrom,
    horizontalPosition: placementAlign,
    panelClass: colorName,
  });
 }

}
