import { ComponentFixture, TestBed, waitForAsync } from "@angular/core/testing";
import { AddImmeubleDialogComponent } from "./add-immeuble-dialog.component";

describe("AddImmeubleDialogComponent", () => {
  let component: AddImmeubleDialogComponent;
  let fixture: ComponentFixture<AddImmeubleDialogComponent>;
  beforeEach(
    waitForAsync(() => {
      TestBed.configureTestingModule({
        declarations: [AddImmeubleDialogComponent],
      }).compileComponents();
    })
  );
  beforeEach(() => {
    fixture = TestBed.createComponent(AddImmeubleDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });
  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
