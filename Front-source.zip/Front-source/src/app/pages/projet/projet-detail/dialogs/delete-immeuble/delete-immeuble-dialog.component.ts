import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { Component, Inject } from '@angular/core';
import { ImmeubleItemModel } from '@core/models/immeuble-item.model';
import { ImmeubleService } from '@core/service/immeuble.service';

export interface DialogData {
  immeuble: ImmeubleItemModel;
}

@Component({
  selector: 'app-delete-immeuble-dialog:not(i)',
  templateUrl: './delete-immeuble-dialog.component.html',
  styleUrls: ['./delete-immeuble-dialog.component.scss'],
})
export class DeleteImmeubleDialogComponent {

  // Fields.
  immeuble: ImmeubleItemModel;

  // Ctor.
  constructor(public dialogRef: MatDialogRef<DeleteImmeubleDialogComponent>,
              @Inject(MAT_DIALOG_DATA) public data: DialogData,
              private immeubleService: ImmeubleService) {
      this.immeuble = data.immeuble;
  }

  onNoClick(): void {
    this.dialogRef.close();
  }
  
  confirmDelete(): void {
    this.immeubleService.currentImmeuble = this.immeuble;
  }
}
