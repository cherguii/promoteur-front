import { ComponentFixture, TestBed, waitForAsync } from "@angular/core/testing";
import { DeleteImmeubleDialogComponent } from "./delete-immeuble-dialog.component";

describe("DeleteImmeubleDialogComponent", () => {
  let component: DeleteImmeubleDialogComponent;
  let fixture: ComponentFixture<DeleteImmeubleDialogComponent>;

  beforeEach(
    waitForAsync(() => {
      TestBed.configureTestingModule({
        declarations: [DeleteImmeubleDialogComponent],
      }).compileComponents();
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(DeleteImmeubleDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
