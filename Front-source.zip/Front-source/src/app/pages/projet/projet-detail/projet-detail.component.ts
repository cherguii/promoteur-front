import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ActivatedRoute, Router} from '@angular/router';
import { ImmeubleItemModel } from '@core/models/immeuble-item.model';
import { OperationDetailModel } from '@core/models/operation-detail.model';
import { OperationItemModel } from '@core/models/operation-item.model';
import { ImmeubleService } from '@core/service/immeuble.service';
import { ProjetService } from '@core/service/projet.service';
import { AddImmeubleDialogComponent } from './dialogs/add-immeuble/add-immeuble-dialog.component';
import { DeleteImmeubleDialogComponent } from './dialogs/delete-immeuble/delete-immeuble-dialog.component';
import { EditProjetDialogComponent } from './dialogs/edit-projet/edit-projet-dialog.component';

@Component({
  selector: 'app-projet-detail',
  templateUrl: './projet-detail.component.html',
  styleUrls: ['./projet-detail.component.scss'],
})
export class ProjetDetailComponent implements OnInit {

  // Fields.
  currentProjet: OperationDetailModel = new OperationDetailModel();

  // Ctor.
  constructor(private projetService: ProjetService,
              private immeubleService: ImmeubleService,
              private router: Router,
              public dialog: MatDialog,
              private activatedRoute: ActivatedRoute,
              private snackBar: MatSnackBar) {}

  ngOnInit() {
    const operationId = this.activatedRoute.snapshot.queryParamMap.get('operationId');
    this.loadProjetById(operationId);
  }
  
  loadProjetById(operationId: any) {
    this.projetService.getProjetDetailById(operationId)
              .subscribe({
                next: (response) => {
                  if(this.projetService.isGetProjetByIdOK === true) {
                    this.currentProjet = response;
                  }
                  else {
                    this.showNotification(
                      'snackbar-danger',
                      response.message,
                      'bottom',
                      'right'
                    );
                  }
                }
              });
  }

  editProjet(projet: OperationItemModel) {
    const dialogRef = this.dialog.open(EditProjetDialogComponent, {
      data: {
        action: 'edit',
        projet: projet
      },
      direction: 'ltr',
    });
    dialogRef.afterClosed().subscribe((result) => {
      if (result === 1) {
        var projetToUpdate= this.projetService.currentProjet;
        this.projetService.updateProjet(projetToUpdate)
            .subscribe({
              next: (response) =>  {
                if(this.projetService.isEditProjetOK) {
                  this.currentProjet = this.projetService.projetUpdate;
                  this.showNotification(
                    'snackbar-success',
                    'Le projet a été mis à jour avec succès !!!',
                    'bottom',
                    'right'
                  );
                }
                else {
                  this.showNotification(
                    'snackbar-danger',
                    response.message,
                    'bottom',
                    'right'
                  );
                }
                this.projetService.currentProjet = null;
              }
            });
      }
    });
  }

  addNewImmeuble() {
    const dialogRef = this.dialog.open(AddImmeubleDialogComponent, {
      data: {
        demarrageProjetDate: this.currentProjet.demarrageDate,
        finProjetDate: this.currentProjet.finDate,
        surfaceTotalProjet: this.currentProjet.surfaceTotal,
        surfaceTotalAllImmeuble: this.sumSurfaceTotalAllImmeuble(this.currentProjet.immeubles)
      },
      direction: 'ltr'
    });
    dialogRef.afterClosed().subscribe((result) => {
      if (result === 1) {
        var immeubleToAdd = this.immeubleService.currentImmeuble;
        this.immeubleService.addImmeuble(immeubleToAdd)
            .subscribe({
              next: (response) =>  {
                if(this.immeubleService.isAddImmeubleOk) {
                  this.currentProjet.immeubles.push(response);
                  this.showNotification(
                    'snackbar-success',
                    'L\'immeuble a été ajouté avec succès !!!',
                    'bottom',
                    'right'
                  );
                }
                else {
                  this.showNotification(
                    'snackbar-danger',
                    response.message,
                    'bottom',
                    'right'
                  );
                }
                this.immeubleService.currentImmeuble = null;
              }
            });

      }
    });
  }

  sumSurfaceTotalAllImmeuble(immeubles: ImmeubleItemModel[]) {
    var surfaceTotalAllImmeuble = 0;
    immeubles.forEach(immeuble => {
      surfaceTotalAllImmeuble += immeuble.surfaceTotal;
    });
    return surfaceTotalAllImmeuble;
  }

  deleteImmeuble(immeuble: ImmeubleItemModel) {
    const dialogRef = this.dialog.open(DeleteImmeubleDialogComponent, {
      data: {
        immeuble: immeuble,
      },
      direction: 'ltr',
    });
    dialogRef.afterClosed().subscribe((result) => {
      if (result === 1) {
        var immeubleToDelete = this.immeubleService.currentImmeuble;
        this.immeubleService.deleteImmeuble(immeubleToDelete.operationId, immeubleToDelete.immeubleId)
            .subscribe({
              next: (response) =>  {
                if(this.immeubleService.isDeleteImmeubleOK) {
                  const foundIndex = this.currentProjet.immeubles.findIndex(
                    (x) => x.immeubleId === immeubleToDelete.immeubleId
                  );
                  if (foundIndex != null) {
                    this.currentProjet.immeubles.splice(foundIndex, 1);
                    this.showNotification(
                      'snackbar-success',
                      'L\'immeuble a été supprimé avec succès !!!',
                      'bottom',
                      'right'
                    );
                  }
                }
                else {
                  this.showNotification(
                    'snackbar-danger',
                    response.message,
                    'bottom',
                    'right'
                  );
                }
                this.immeubleService.currentImmeuble = null;
              }
            });
      }
    });
  }

  refresh() {
    const operationId = this.activatedRoute.snapshot.queryParamMap.get('operationId');
    this.loadProjetById(operationId);
  }
  
  goToPageImmeubleDetail(immeuble: ImmeubleItemModel) {
    this.router.navigate(['/immeuble-detail'], { queryParams: { operationId: immeuble.operationId, immeubleId: immeuble.immeubleId } });
  }

  goToProjetItemsPage() {
    this.router.navigate(['/projets'] );
  }

  goToaSuiviProjetPage(operationId: string) {
    this.router.navigate(['/suivi-projet'], { queryParams: { operationId: operationId } });
  }

  getClassByIndex(index: any) {
    index++;
    var mod = index % 5;
    if(mod === 0 && index > 4)
      mod = 1;

    return `lz-bg-card${mod}`;
  }

  // showNotification.
  showNotification(colorName: any, text: any, placementFrom: any, placementAlign: any) {
    this.snackBar.open(text, '', {
      duration: 5000,
      verticalPosition: placementFrom,
      horizontalPosition: placementAlign,
      panelClass: colorName,
    });
  }

}
