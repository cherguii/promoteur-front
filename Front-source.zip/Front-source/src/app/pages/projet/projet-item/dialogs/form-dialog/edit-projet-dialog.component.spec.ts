// import { ComponentFixture, TestBed, waitForAsync } from "@angular/core/testing";
// import { EditProjetItemDialogComponent } from "./edit-projet-dialog.component";

// describe("EditProjetItemDialogComponent", () => {
//   let component: EditProjetItemDialogComponent;
//   let fixture: ComponentFixture<EditProjetItemDialogComponent>;
//   beforeEach(
//     waitForAsync(() => {
//       TestBed.configureTestingModule({
//         declarations: [EditProjetItemDialogComponent],
//       }).compileComponents();
//     })
//   );
//   beforeEach(() => {
//     fixture = TestBed.createComponent(EditProjetItemDialogComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });
//   it("should create", () => {
//     expect(component).toBeTruthy();
//   });
// });
