// import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
// import { Component, Inject } from '@angular/core';
// import { UntypedFormControl, UntypedFormGroup, UntypedFormBuilder, } from '@angular/forms';
// import { DatePipe } from '@angular/common';
// import { OperationItemModel } from '@core/models/operation-item.model';
// import { CommonHelper } from '@core/helpers/common-helper';
// import { ProjetService } from '@core/service/projet.service';

// export interface DialogData {
//   id: number;
//   action: string;
//   projet: OperationItemModel;
// }

// @Component({
//   selector: 'app-edit-projet-dialog:not(f)',
//   templateUrl: './edit-projet-dialog.component.html',
//   styleUrls: ['./edit-projet-dialog.component.scss'],
// })
// export class EditProjetItemDialogComponent {

//   // Fields.
//   action: string;
//   dialogTitle: string;
//   projetForm: UntypedFormGroup;
//   projet: OperationItemModel;
//   specialteToppings = new UntypedFormControl();
//   docteurId: any;
 
//   // Ctor.
//   constructor(public dialogRef: MatDialogRef<EditProjetItemDialogComponent>,
//               @Inject(MAT_DIALOG_DATA) public data: DialogData,
//               private projetService: ProjetService,
//               public datepipe: DatePipe,
//               private fb: UntypedFormBuilder) {
//     this.action = data.action;
//     if (this.action === 'edit') {
//       this.dialogTitle = `Projet ${data.projet.nom}`;
//       this.projet = data.projet;
//     } else {
//       this.dialogTitle = 'Nouveau projet';
//       this.projet = new OperationItemModel();
//     }
//     this.projetForm = this.createContactForm();
//   }

//   ngOnInit() {
    
//   }

//   createContactForm(): UntypedFormGroup {
//     return this.fb.group({
//       operationId: [this.projet.operationId],
//       nom: [this.projet.nom],
//       adresse: [this.projet.adresse],
//       ville: [this.projet.ville],
//       surfaceTotal: [this.projet.surfaceTotal],
//       demarrageDate: [CommonHelper.formatDate2(this.projet.demarrageDate)],
//       finDate: [CommonHelper.formatDate2(this.projet.finDate)]
//     });
//   }
 
//   public confirmSave(): void {
//     this.projetService.currentProjet = this.projetForm.getRawValue();
//     if (this.action === 'add') {
//       this.projetService.currentProjet.operationId = '00000000-0000-0000-0000-000000000000';
//     }

//     if(this.projetService.currentProjet.demarrageDate !== '')
//       this.projetService.currentProjet.demarrageDate = CommonHelper.formatDate(this.projetService.currentProjet.demarrageDate);
//     else
//       this.projetService.currentProjet.demarrageDate = null;

//     if(this.projetService.currentProjet.finDate !== '')
//       this.projetService.currentProjet.finDate = CommonHelper.formatDate(this.projetService.currentProjet.finDate);
//     else
//       this.projetService.currentProjet.finDate = null;
        
//   }

//   onNoClick(): void {
//     this.dialogRef.close();
//   }

// }
