import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { Component, Inject } from '@angular/core';
import { ProjetService } from '@core/service/projet.service';

@Component({
  selector: 'app-delete-projet-dialog:not(f)',
  templateUrl: './delete-projet-dialog.component.html',
  styleUrls: ['./delete-projet-dialog.component.scss'],
})
export class DeleteProjetDialogComponent {
  
  // Ctor.
  constructor(public dialogRef: MatDialogRef<DeleteProjetDialogComponent>,
              @Inject(MAT_DIALOG_DATA) public data: any,
              private projetService: ProjetService) {
    this.projetService.currentProjet = data;
  }

  onNoClick(): void {
    this.dialogRef.close();
  }
}
