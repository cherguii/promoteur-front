import { ComponentFixture, TestBed, waitForAsync } from "@angular/core/testing";
import { DeleteProjetDialogComponent } from "./delete-projet-dialog.component";

describe("DeleteProjetDialogComponent", () => {
  let component: DeleteProjetDialogComponent;
  let fixture: ComponentFixture<DeleteProjetDialogComponent>;
  beforeEach(
    waitForAsync(() => {
      TestBed.configureTestingModule({
        declarations: [DeleteProjetDialogComponent],
      }).compileComponents();
    })
  );
  beforeEach(() => {
    fixture = TestBed.createComponent(DeleteProjetDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });
  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
