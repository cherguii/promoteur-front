import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router} from '@angular/router';
import { OperationItemModel } from '@core/models/operation-item.model';
import { ProjetService } from '@core/service/projet.service';
import { EditProjetDialogComponent } from '../projet-detail/dialogs/edit-projet/edit-projet-dialog.component';
import { DeleteProjetDialogComponent } from './dialogs/delete-projet-item/delete-projet-dialog.component';
//import { EditProjetItemDialogComponent } from './dialogs/form-dialog/edit-projet-dialog.component';

@Component({
  selector: 'app-projet-item',
  templateUrl: './projet-item.component.html',
  styleUrls: ['./projet-item.component.scss'],
})
export class ProjetItemComponent implements OnInit {

  // Fields.
  projets: Array<OperationItemModel> = new Array<OperationItemModel>();

  // Ctor.
  constructor(private projetService: ProjetService,
              public dialog: MatDialog,
              private router: Router,
              private snackBar: MatSnackBar) {}

  // ngOnInit. 
  ngOnInit() {
    this.loadAllProjetItem();
  }
  
  loadAllProjetItem() {
    this.projetService.getAllProjetItem()
                      .subscribe({
                        next: (response) => {
                          if(this.projetService.isGetAllProjetItemOK === true) {
                            this.projets = response;
                          }
                          else {
                            this.showNotification(
                              'snackbar-danger',
                              response.message,
                              'bottom',
                              'right'
                            );
                          }
                        }
                      });
  }

  addNewProjet() {
    const dialogRef = this.dialog.open(EditProjetDialogComponent, {
      data: {
        action: 'add',
      },
      direction: 'ltr',
    });
    dialogRef.afterClosed().subscribe((result) => {
      if (result === 1) {
        var projetToAdd = this.projetService.currentProjet;
        this.projetService.addProjet(projetToAdd)
            .subscribe({
              next: (response) =>  {
                if(this.projetService.isAddProjetOk) {
                  this.projets.push(this.projetService.projetAdd);
                  // this.operationDatabase?.dataChange.value.unshift(
                  //   this.operationService.operationAdd
                  // );
                  // this.refreshTable();
                  this.showNotification(
                    'snackbar-success',
                    'Le projet a été ajoutée avec succès !!!',
                    'bottom',
                    'right'
                  );
                }
                else {
                  this.showNotification(
                    'snackbar-danger',
                    response.message,
                    'bottom',
                    'right'
                  );
                }
                this.projetService.currentProjet = null;
              }
            });
      }
    });
  }

  editProjet(projet: OperationItemModel) {
    //this.operationId = row.operationId;
    const dialogRef = this.dialog.open(EditProjetDialogComponent, {
      data: {
        projet: projet,
        action: 'edit',
      },
      direction: 'ltr',
    });
    dialogRef.afterClosed().subscribe((result) => {
      if (result === 1) {
        var projetToUpdate = this.projetService.currentProjet;
        this.projetService.updateProjet(projetToUpdate)
            .subscribe({
              next: (response) =>  {
                if(this.projetService.isEditProjetOK) {
                    const foundIndex = this.projets.findIndex(
                      (x) => x.operationId === projetToUpdate.operationId
                    );
                    if (foundIndex != null) {
                      this.projets[foundIndex] = this.projetService.projetUpdate;
                      this.showNotification(
                        'snackbar-success',
                        'Le projet a été mis à jour avec succès !!!',
                        'bottom',
                        'right'
                      );
                    }
                }
                else {
                  this.showNotification(
                    'snackbar-danger',
                    response.message,
                    'bottom',
                    'right'
                  );
                }
                this.projetService.currentProjet = null;
              }
            });
      }
    });
  }

  deleteProjet(projet: OperationItemModel) {
    const dialogRef = this.dialog.open(DeleteProjetDialogComponent, {
      data: projet,
      direction: 'ltr',
    });
    dialogRef.afterClosed().subscribe((result) => {
      if (result === 1) {
        var projetToDelete = this.projetService.currentProjet;
        this.projetService.deleteProjet(projet.operationId)
              .subscribe({
                next: (response) =>  {
                  if(this.projetService.isDeleteProjetOK) { 
                    const foundIndex = this.projets.findIndex(
                      (x) => x.operationId === projetToDelete.operationId
                    );
                    if (foundIndex != null) {
                      this.projets.splice(foundIndex, 1);
                      this.showNotification(
                        'snackbar-success',
                        'Le projet a été supprimé avec succès !!!',
                        'bottom',
                        'right'
                      );
                    }
                  }
                  else {
                    this.showNotification(
                      'snackbar-danger',
                      response.message,
                      'bottom',
                      'right'
                    );
                  }
                }
              });
      }
    });
  }

  refresh() {
    this.loadAllProjetItem();
  }

  goToaProjetDetailPage(operationId: string) {
    this.router.navigate(['/projet-detail'], { queryParams: { operationId: operationId } });
  }

  goToaSuiviProjetPage(operationId: string) {
    this.router.navigate(['/suivi-projet'], { queryParams: { operationId: operationId } });
  }

  getClassByIndex(index: any) {
    index++;
    if(index === 5)
      index =1;

    return `l-bg-card${index}`;
  }

  showNotification(colorName: any, text: any, placementFrom: any, placementAlign: any) {
    this.snackBar.open(text, '', {
      duration: 5000,
      verticalPosition: placementFrom,
      horizontalPosition: placementAlign,
      panelClass: colorName,
    });
  }

}
