import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { HomeComponent } from "./home/home.component";
//import { SalleAttenteComponent } from "./salle-attente/salle-attente.component";
//import { SalleAttenteHomeComponent } from "./salle-attente-home/salle-attente-home.component";
//import { AlldoctorsComponent } from "./doctors/alldoctors/alldoctors.component";
// import { DoctorProfileComponent } from "./doctors/doctor-profile/doctor-profile.component";
// import { AllPatientComponent } from "./patient/all-patient/all-patient.component";
import { AuthGuard } from "@core/guard/auth.guard";
import { AllMaterielComponent } from "./materiel/all-materiel.component";
//import { AllOperationComponent } from "./operation/all-operation/all-operation.component";
import { ProjetItemComponent } from "./projet/projet-item/projet-item.component";
import { ProjetDetailComponent } from "./projet/projet-detail/projet-detail.component";
import { ImmeubleDetailComponent } from "./projet/immeuble/immeuble-detail.component";
import { SuiviProjetComponent } from "./suivi-projet/suivi-projet.component";
import { AllSousTraitantComponent } from "./sous-traitant/all-sous-traitant.component";

const routes: Routes = [
  { path: "home", component: HomeComponent, canActivate: [AuthGuard] },
  { path: "all-materiel", component: AllMaterielComponent, canActivate: [AuthGuard] },  
  { path: "all-sous-traitant", component: AllSousTraitantComponent, canActivate: [AuthGuard] },
  { path: "projets", component: ProjetItemComponent, canActivate: [AuthGuard] },
  { path: "projet-detail", component: ProjetDetailComponent, canActivate: [AuthGuard] },
  { path: "immeuble-detail", component: ImmeubleDetailComponent, canActivate: [AuthGuard] },
  { path: "suivi-projet", component: SuiviProjetComponent, canActivate: [AuthGuard] },
];
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class PagesRoutingModule {}
