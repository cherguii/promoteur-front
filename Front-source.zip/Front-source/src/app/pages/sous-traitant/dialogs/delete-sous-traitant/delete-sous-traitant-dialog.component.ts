import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { Component, Inject } from '@angular/core';
import { SousTraitantModel } from '@core/models/sous-traitant.model';

@Component({
  selector: 'app-delete-sous-traitant-dialog:not(f)',
  templateUrl: './delete-sous-traitant-dialog.component.html',
  styleUrls: ['./delete-sous-traitant-dialog.component.scss'],
})
export class DeleteSousTraitantDialogComponent {
  
  // Fields.
  sousTraitant: SousTraitantModel;

  // Ctor.
  constructor(public dialogRef: MatDialogRef<DeleteSousTraitantDialogComponent>,
              @Inject(MAT_DIALOG_DATA) public data: any) {
    this.sousTraitant = data;
  }

  onNoClick(): void {
    this.dialogRef.close();
  }
}
