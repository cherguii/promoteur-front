import { ComponentFixture, TestBed, waitForAsync } from "@angular/core/testing";
import { DeleteSousTraitantDialogComponent } from "./delete-sous-traitant-dialog.component";

describe("DeleteSousTraitantDialogComponent", () => {
  let component: DeleteSousTraitantDialogComponent;
  let fixture: ComponentFixture<DeleteSousTraitantDialogComponent>;
  beforeEach(
    waitForAsync(() => {
      TestBed.configureTestingModule({
        declarations: [DeleteSousTraitantDialogComponent],
      }).compileComponents();
    })
  );
  beforeEach(() => {
    fixture = TestBed.createComponent(DeleteSousTraitantDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });
  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
