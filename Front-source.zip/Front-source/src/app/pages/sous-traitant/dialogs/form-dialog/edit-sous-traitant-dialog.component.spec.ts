import { ComponentFixture, TestBed, waitForAsync } from "@angular/core/testing";
import { EditSousTraitantDialogComponent } from "./edit-sous-traitant-dialog.component";

describe("EditSousTraitantDialogComponent", () => {
  let component: EditSousTraitantDialogComponent;
  let fixture: ComponentFixture<EditSousTraitantDialogComponent>;
  beforeEach(
    waitForAsync(() => {
      TestBed.configureTestingModule({
        declarations: [EditSousTraitantDialogComponent],
      }).compileComponents();
    })
  );
  beforeEach(() => {
    fixture = TestBed.createComponent(EditSousTraitantDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });
  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
