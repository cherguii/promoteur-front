import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { Component, Inject } from '@angular/core';
import { UntypedFormGroup, UntypedFormBuilder, } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { SousTraitantModel } from '@core/models/sous-traitant.model';
import { DatePipe } from '@angular/common';
import { SousTraitantService } from '@core/service/sous-traitant.service';
import { ReferentialService } from '@core/service/referential.service';
import { ReferentielModel } from '@core/models/referentiel.model';

export interface DialogData {
  id: number;
  action: string;
  sousTraitant: SousTraitantModel;
}

@Component({
  selector: 'app-edit-sous-traitant-dialog:not(f)',
  templateUrl: './edit-sous-traitant-dialog.component.html',
  styleUrls: ['./edit-sous-traitant-dialog.component.scss'],
})
export class EditSousTraitantDialogComponent {

 // Fields.
 action: string;
 dialogTitle: string;
 sousTraitantForm: UntypedFormGroup;
 sousTraitant: SousTraitantModel;
 sousTraitantTypes: ReferentielModel[];
 
 // Ctor.
 constructor(public dialogRef: MatDialogRef<EditSousTraitantDialogComponent>,
             @Inject(MAT_DIALOG_DATA) public data: DialogData,
             private sousTraitantService: SousTraitantService,
             private referentialService: ReferentialService,
             public datepipe: DatePipe,
             private fb: UntypedFormBuilder,
             private snackBar: MatSnackBar) {
   // Set the defaults
   this.action = data.action;
   if (this.action === 'edit') {
     this.dialogTitle = `${data.sousTraitant.nomSociete}`;
     this.sousTraitant = data.sousTraitant;
   } else {
     this.dialogTitle = 'Nouveau matériel';
     this.sousTraitant = new SousTraitantModel();
   }
   this.sousTraitantForm = this.createContactForm();
  
 }

 ngOnInit() {
   this.fillSousTraitantTypes();
 }

 fillSousTraitantTypes() {
  this.referentialService.getAllSousTraitantType()
          .subscribe({
            next: (response) => {
             if(this.referentialService.isGetAllSousTraitantTypeOk === true) {
               this.sousTraitantTypes = response;
             }
             else {
               this.showNotification(
                 'snackbar-danger',
                 response.message,
                 'bottom',
                 'right'
               );
             }
            }
          });
  
 }

 createContactForm(): UntypedFormGroup {
   return this.fb.group({
     sousTraitantId: [this.sousTraitant.sousTraitantId],
     nomSociete: [this.sousTraitant.nomSociete],
     nomGerant: [this.sousTraitant.nomGerant],
     telephoneGerant: [this.sousTraitant.telephoneGerant],
     sousTraitantTypeCode: [this.sousTraitant.sousTraitantTypeCode],
     sousTraitantTypeLibelle: [this.sousTraitant.sousTraitantTypeLibelle]
   });
 }

 submit() {
   // emppty stuff
 }

 onNoClick(): void {
   this.dialogRef.close();
 }
 
 public confirmSave(): void {
   this.sousTraitantService.currentSousTraitant  = this.sousTraitantForm.getRawValue();
   if (this.action === 'add') {
     this.sousTraitantService.currentSousTraitant.sousTraitantId = '00000000-0000-0000-0000-000000000000';
   }
 }

 // showNotification.
 showNotification(colorName: any, text: any, placementFrom: any, placementAlign: any) {
   this.snackBar.open(text, '', {
     duration: 5000,
     verticalPosition: placementFrom,
     horizontalPosition: placementAlign,
     panelClass: colorName,
   });
 }

}
