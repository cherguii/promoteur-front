import { Direction } from '@angular/cdk/bidi';
import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { DataSource } from '@angular/cdk/collections';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition, } from '@angular/material/snack-bar';
import { BehaviorSubject, fromEvent, merge, Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { EditSousTraitantDialogComponent } from './dialogs/form-dialog/edit-sous-traitant-dialog.component';
import { DeleteSousTraitantDialogComponent } from './dialogs/delete-sous-traitant/delete-sous-traitant-dialog.component';
import { SelectionModel } from '@angular/cdk/collections';
import { UnsubscribeOnDestroyAdapter, } from '@shared';
import { SousTraitantModel } from '@core/models/sous-traitant.model';
import { SousTraitantService } from '@core/service/sous-traitant.service';

@Component({
  selector: 'app-all-sous-traitant',
  templateUrl: './all-sous-traitant.component.html',
  styleUrls: ['./all-sous-traitant.component.scss'],
})
export class AllSousTraitantComponent extends UnsubscribeOnDestroyAdapter implements OnInit {

  // Fields.
  displayedColumns = [
    'select',
    'nomSociete',
    'nomGerant',
    'telephoneGerant',
    'sousTraitantTypeLibelle',
    'actions',
  ];
  sousTraitantDatabase?: SousTraitantService;
  dataSource!: SousTraitantDataSource;
  selection = new SelectionModel<SousTraitantModel>(true, []);
  index?: number;
  sousTraitantId: string;

  @ViewChild(MatPaginator, { static: true }) paginator!: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort!: MatSort;
  @ViewChild('filter', { static: true }) filter?: ElementRef;

  // Ctor.
  constructor(public httpClient: HttpClient,
              public dialog: MatDialog,
              public sousTraitantService: SousTraitantService,
              private snackBar: MatSnackBar) {
    super();
  }

  ngOnInit() {
    this.loadData();
  }

  refresh() {
    this.loadData();
  }

  addNew() {
    let tempDirection: Direction;
    if (localStorage.getItem('isRtl') === 'true') {
      tempDirection = 'rtl';
    } else {
      tempDirection = 'ltr';
    }
    const dialogRef = this.dialog.open(EditSousTraitantDialogComponent, {
      data: {
        action: 'add',
      },
      direction: tempDirection,
    });
    this.subs.sink = dialogRef.afterClosed().subscribe((result) => {
      if (result === 1) {
        var sousTraitantToAdd = this.sousTraitantService.currentSousTraitant;
        this.sousTraitantService.addSousTraitant(sousTraitantToAdd)
            .subscribe({
              next: (response) =>  {
                if(this.sousTraitantService.isAddSousTraitantOk) {
                  this.sousTraitantDatabase?.dataChange.value.unshift(
                    this.sousTraitantService.sousTraitantAdd
                  );
                  this.refreshTable();
                  this.showNotification(
                    'snackbar-success',
                    'Le sous-traitant a été ajouté avec succès !!!',
                    'bottom',
                    'right'
                  );
                }
                else {
                  this.showNotification(
                    'snackbar-danger',
                    response.message,
                    'bottom',
                    'right'
                  );
                }
                this.sousTraitantService.currentSousTraitant = null;
              }
            });
      }
    });
  }

  editCall(row: SousTraitantModel) {
    this.sousTraitantId = row.sousTraitantId;
    const dialogRef = this.dialog.open(EditSousTraitantDialogComponent, {
      data: {
        sousTraitant: row,
        action: 'edit',
      },
      direction: 'ltr',
    });
    this.subs.sink = dialogRef.afterClosed().subscribe((result) => {

      if (result === 1) {
        var sousTraitantToUpdate= this.sousTraitantService.currentSousTraitant;
        this.sousTraitantService.updateSousTraitant(sousTraitantToUpdate)
            .subscribe({
              next: (response) =>  {
                if(this.sousTraitantService.isEditSousTraitantOK) {
                    const foundIndex = this.sousTraitantDatabase?.dataChange.value.findIndex(
                      (x) => x.sousTraitantId === this.sousTraitantId
                    );
                    if (foundIndex != null && this.sousTraitantDatabase) {
                      this.sousTraitantDatabase.dataChange.value[foundIndex] = this.sousTraitantService.sousTraitantUpdate;
                      this.refreshTable();
                      this.showNotification(
                        'snackbar-success',
                        'Le sous-traitant a été mis à jour avec succès !!!',
                        'bottom',
                        'right'
                      );
                    }
                }
                else {
                  this.showNotification(
                    'snackbar-danger',
                    response.message,
                    'bottom',
                    'right'
                  );
                }
                this.sousTraitantService.currentSousTraitant = null;
              }
            });
      }
    });
  }

  deleteItem(row: SousTraitantModel) {
    this.sousTraitantId = row.sousTraitantId;
    const dialogRef = this.dialog.open(DeleteSousTraitantDialogComponent, {
      data: row,
      direction: 'ltr',
    });
    this.subs.sink = dialogRef.afterClosed().subscribe((result) => {
      if (result === 1) {
        this.sousTraitantService.deleteSousTraitant(this.sousTraitantId)
              .subscribe({
                next: (response) =>  {
                  if(this.sousTraitantService.isDeleteSousTraitantOK) { 
                    const foundIndex = this.sousTraitantDatabase?.dataChange.value.findIndex(
                      (x) => x.sousTraitantId === this.sousTraitantId
                    );
                    if (foundIndex != null && this.sousTraitantDatabase) {
                      this.sousTraitantDatabase.dataChange.value.splice(foundIndex, 1);
                      this.refreshTable();
                      this.showNotification(
                        'snackbar-success',
                        'Le sous-traitant a été supprimer avec succès',
                        'bottom',
                        'center'
                      );
                    }
                  }
                  else {
                    this.showNotification(
                      'snackbar-danger',
                      response.message,
                      'bottom',
                      'right'
                    );
                  }
                }
              });
      }
    });
  }

  private refreshTable() {
    this.paginator?._changePageSize(this.paginator?.pageSize);
  }

  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.renderedData.length;
    return numSelected === numRows;
  }

  masterToggle() {
    this.isAllSelected()
      ? this.selection.clear()
      : this.dataSource.renderedData.forEach((row) =>
          this.selection.select(row)
        );
  }

  removeSelectedRows() {
    const totalSelect = this.selection.selected.length;
    this.selection.selected.forEach((item) => {
      const index: number = this.dataSource.renderedData.findIndex(
        (d) => d === item
      );
      this.sousTraitantDatabase?.dataChange.value.splice(index, 1);
      this.refreshTable();
      this.selection = new SelectionModel<SousTraitantModel>(true, []);
    });
    this.showNotification(
      'snackbar-danger',
      totalSelect + ' matériel(s) ont été supprimés avec succès',
      'bottom',
      'right'
    );
  }

  public loadData() {
    this.sousTraitantDatabase = new SousTraitantService(this.httpClient);
    this.dataSource = new SousTraitantDataSource(
      this.sousTraitantDatabase,
      this.paginator,
      this.sort
    );
    this.subs.sink = fromEvent(this.filter?.nativeElement, 'keyup').subscribe(
      () => {
        if (!this.dataSource) {
          return;
        }
        this.dataSource.filter = this.filter?.nativeElement.value;
      }
    );
  }

  showNotification(colorName: string, text: string, placementFrom: MatSnackBarVerticalPosition, placementAlign: MatSnackBarHorizontalPosition) {
    this.snackBar.open(text, '', {
      duration: 5000,
      verticalPosition: placementFrom,
      horizontalPosition: placementAlign,
      panelClass: colorName,
    });
  }
  
}

export class SousTraitantDataSource extends DataSource<SousTraitantModel> {

  // Fields.
  filterChange = new BehaviorSubject('');
  get filter(): string {
    return this.filterChange.value;
  }
  set filter(filter: string) {
    this.filterChange.next(filter);
  }
  filteredData: SousTraitantModel[] = [];
  renderedData: SousTraitantModel[] = [];

  // Ctor.
  constructor(public sousTraitantDatabase: SousTraitantService,
              public paginator: MatPaginator,
              public _sort: MatSort) {
    super();
    this.filterChange.subscribe(() => (this.paginator.pageIndex = 0));
  }

  connect(): Observable<SousTraitantModel[]> {
    const displayDataChanges = [
      this.sousTraitantDatabase.dataChange,
      this._sort.sortChange,
      this.filterChange,
      this.paginator.page,
    ];
    this.sousTraitantDatabase.getAllSousTraitant();
    return merge(...displayDataChanges).pipe(
      map(() => {
        // Filter data
        this.filteredData = this.sousTraitantDatabase.data
          .slice()
          .filter((sousTraitant: SousTraitantModel) => {
            const searchStr = (
              sousTraitant.nomSociete +
              sousTraitant.nomGerant +
              sousTraitant.sousTraitantTypeLibelle +
              sousTraitant.telephoneGerant +
              sousTraitant.sousTraitantTypeLibelle
            ).toLowerCase();
            return searchStr.indexOf(this.filter.toLowerCase()) !== -1;
          });
        // Sort filtered data
        const sortedData = this.sortData(this.filteredData.slice());
        // Grab the page's slice of the filtered sorted data.
        const startIndex = this.paginator.pageIndex * this.paginator.pageSize;
        this.renderedData = sortedData.splice(
          startIndex,
          this.paginator.pageSize
        );
        return this.renderedData;
      })
    );
  }

  disconnect() {}

  sortData(data: SousTraitantModel[]): SousTraitantModel[] {
    if (!this._sort.active || this._sort.direction === '') {
      return data;
    }
    return data.sort((a, b) => {
      let propertyA: Date | number | string = '';
      let propertyB: Date | number | string = '';
      switch (this._sort.active) {
        case 'nomSociete':
          [propertyA, propertyB] = [a.nomSociete, b.nomSociete];
          break;
        case 'nomGerant':
          [propertyA, propertyB] = [a.nomGerant, b.nomGerant];
          break;
        case 'sousTraitantTypeLibelle':
          [propertyA, propertyB] = [a.sousTraitantTypeLibelle, b.sousTraitantTypeLibelle];
          break;
      }
      const valueA = isNaN(+propertyA) ? propertyA : +propertyA;
      const valueB = isNaN(+propertyB) ? propertyB : +propertyB;
      return (
        (valueA < valueB ? -1 : 1) * (this._sort.direction === 'asc' ? 1 : -1)
      );
    });
  }
  
}
