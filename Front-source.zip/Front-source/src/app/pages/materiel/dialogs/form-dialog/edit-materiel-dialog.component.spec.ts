import { ComponentFixture, TestBed, waitForAsync } from "@angular/core/testing";
import { EditMaterielDialogComponent } from "./edit-materiel-dialog.component";

describe("EditMaterielDialogComponent", () => {
  let component: EditMaterielDialogComponent;
  let fixture: ComponentFixture<EditMaterielDialogComponent>;
  beforeEach(
    waitForAsync(() => {
      TestBed.configureTestingModule({
        declarations: [EditMaterielDialogComponent],
      }).compileComponents();
    })
  );
  beforeEach(() => {
    fixture = TestBed.createComponent(EditMaterielDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });
  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
