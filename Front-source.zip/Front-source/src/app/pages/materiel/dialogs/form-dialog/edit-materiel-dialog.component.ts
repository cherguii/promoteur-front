import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { Component, Inject } from '@angular/core';
import { UntypedFormGroup, UntypedFormBuilder, } from '@angular/forms';
import { MaterielModel } from '@core/models/materiel.model';
import { MaterielService } from '@core/service/materiel.service';
import { DatePipe } from '@angular/common';

export interface DialogData {
  action: string;
  materiel: MaterielModel;
}

@Component({
  selector: 'app-edit-materiel-dialog:not(f)',
  templateUrl: './edit-materiel-dialog.component.html',
  styleUrls: ['./edit-materiel-dialog.component.scss'],
})
export class EditMaterielDialogComponent {

 // Fields.
 action: string;
 dialogTitle: string;
 materielForm: UntypedFormGroup;
 materiel: MaterielModel;
 
 // Ctor.
 constructor(public dialogRef: MatDialogRef<EditMaterielDialogComponent>,
             @Inject(MAT_DIALOG_DATA) public data: DialogData,
             private materielService: MaterielService,
             public datepipe: DatePipe,
             private fb: UntypedFormBuilder) {
   this.action = data.action;
   if (this.action === 'edit') {
     this.dialogTitle = `${data.materiel.libelle}`;
     this.materiel = data.materiel;
   } else {
     this.dialogTitle = 'Nouveau matériel';
     this.materiel = new MaterielModel();
   }
   this.materielForm = this.createContactForm();
 }

 ngOnInit() {
 }

 createContactForm(): UntypedFormGroup {
   return this.fb.group({
     materielId: [this.materiel.materielId],
     libelle: [this.materiel.libelle],
     prixUnitaire: [this.materiel.prixUnitaire],
     tva: [this.materiel.tva],
     quantiteInitial: [this.materiel.quantiteInitial]
   });
 }

 onNoClick(): void {
   this.dialogRef.close();
 }
 
 public confirmSave(): void {
   this.materielService.currentMateriel = this.materielForm.getRawValue();
   if (this.action === 'add') {
     this.materielService.currentMateriel.materielId = '00000000-0000-0000-0000-000000000000';
   }
 }

}
