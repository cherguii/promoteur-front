import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { Component, Inject } from '@angular/core';

@Component({
  selector: 'app-delete-materiel-dialog:not(f)',
  templateUrl: './delete-materiel-dialog.component.html',
  styleUrls: ['./delete-materiel-dialog.component.scss'],
})
export class DeleteMaterielDialogComponent {
  
  // Ctor.
  constructor(public dialogRef: MatDialogRef<DeleteMaterielDialogComponent>,
              @Inject(MAT_DIALOG_DATA) public data: any) {}

  onNoClick(): void {
    this.dialogRef.close();
  }
}
