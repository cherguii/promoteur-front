import { ComponentFixture, TestBed, waitForAsync } from "@angular/core/testing";
import { DeleteMaterielDialogComponent } from "./delete-materiel-dialog.component";

describe("DeleteMaterielDialogComponent", () => {
  let component: DeleteMaterielDialogComponent;
  let fixture: ComponentFixture<DeleteMaterielDialogComponent>;
  beforeEach(
    waitForAsync(() => {
      TestBed.configureTestingModule({
        declarations: [DeleteMaterielDialogComponent],
      }).compileComponents();
    })
  );
  beforeEach(() => {
    fixture = TestBed.createComponent(DeleteMaterielDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });
  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
