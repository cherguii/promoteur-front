import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { DataSource } from '@angular/cdk/collections';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition, } from '@angular/material/snack-bar';
import { BehaviorSubject, fromEvent, merge, Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { EditMaterielDialogComponent } from './dialogs/form-dialog/edit-materiel-dialog.component';
import { DeleteMaterielDialogComponent } from './dialogs/delete-materiel/delete-materiel-dialog.component';
import { SelectionModel } from '@angular/cdk/collections';
import { UnsubscribeOnDestroyAdapter, } from '@shared';
import { MaterielService } from '@core/service/materiel.service';
import { MaterielModel } from '@core/models/materiel.model';

@Component({
  selector: 'app-all-materiel',
  templateUrl: './all-materiel.component.html',
  styleUrls: ['./all-materiel.component.scss'],
})
export class AllMaterielComponent extends UnsubscribeOnDestroyAdapter implements OnInit {

  // Fields.
  displayedColumns = [
    'select',
    'libelle',
    'prixUnitaire',
    'tva',
    'quantiteInitial',
    'actions',
  ];
  materielDatabase?: MaterielService;
  dataSource!: MaterielDataSource;
  selection = new SelectionModel<MaterielModel>(true, []);
  materielId?: string;

  @ViewChild(MatPaginator, { static: true }) paginator!: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort!: MatSort;
  @ViewChild('filter', { static: true }) filter?: ElementRef;

  // Ctor.
  constructor(public httpClient: HttpClient,
              public dialog: MatDialog,
              public materielService: MaterielService,
              private snackBar: MatSnackBar) {
    super();
  }

  ngOnInit() {
    this.loadData();
  }

  refresh() {
    this.loadData();
  }

  addNew() {
    const dialogRef = this.dialog.open(EditMaterielDialogComponent, {
      data: {
        action: 'add',
      },
      direction: 'ltr',
    });
    this.subs.sink = dialogRef.afterClosed().subscribe((result) => {
      if (result === 1) {
        var materielToAdd = this.materielService.currentMateriel;
        this.materielService.addMateriel(materielToAdd)
            .subscribe({
              next: (response) =>  {
                if(this.materielService.isAddMaterielOk) {
                  this.materielDatabase?.dataChange.value.unshift(
                    this.materielService.materielAdd
                  );
                  this.refreshTable();
                  this.showNotification(
                    'snackbar-success',
                    'Le matériel a été ajouté avec succès !!!',
                    'bottom',
                    'right'
                  );
                }
                else {
                  this.showNotification(
                    'snackbar-danger',
                    response.message,
                    'bottom',
                    'right'
                  );
                }
                this.materielService.currentMateriel = null;
              }
            });
      }
    });
  }

  editCall(row: MaterielModel) {
    this.materielId = row.materielId;
    const dialogRef = this.dialog.open(EditMaterielDialogComponent, {
      data: {
        materiel: row,
        action: 'edit',
      },
      direction: 'ltr',
    });
    this.subs.sink = dialogRef.afterClosed().subscribe((result) => {

      if (result === 1) {
        var materielToUpdate= this.materielService.currentMateriel;
        this.materielService.updateMateriel(materielToUpdate)
            .subscribe({
              next: (response) =>  {
                if(this.materielService.isEditMaterielOK) {
                    const foundIndex = this.materielDatabase?.dataChange.value.findIndex(
                      (x) => x.materielId === this.materielId
                    );
                    if (foundIndex != null && this.materielDatabase) {
                      this.materielDatabase.dataChange.value[foundIndex] = this.materielService.materielUpdate;
                      this.refreshTable();
                      this.showNotification(
                        'snackbar-success',
                        'Le matériel a été mis à jour avec succès !!!',
                        'bottom',
                        'right'
                      );
                    }
                }
                else {
                  this.showNotification(
                    'snackbar-danger',
                    response.message,
                    'bottom',
                    'right'
                  );
                }
                this.materielService.currentMateriel = null;
              }
            });
      }
    });
  }

  deleteItem(row: MaterielModel) {
    this.materielId = row.materielId;
    const dialogRef = this.dialog.open(DeleteMaterielDialogComponent, {
      data: row,
      direction: 'ltr',
    });
    this.subs.sink = dialogRef.afterClosed().subscribe((result) => {
      if (result === 1) {
        this.materielService.deleteMateriel(row.materielId)
              .subscribe({
                next: (response) =>  {
                  if(this.materielService.isDeleteMaterielOK) { 
                    const foundIndex = this.materielDatabase?.dataChange.value.findIndex(
                      (x) => x.materielId === this.materielId
                    );
                    if (foundIndex != null && this.materielDatabase) {
                      this.materielDatabase.dataChange.value.splice(foundIndex, 1);
                      this.refreshTable();
                      this.showNotification(
                        'snackbar-success',
                        'Le matériel a été supprimer avec succès',
                        'bottom',
                        'right'
                      );
                    }
                  }
                  else {
                    this.showNotification(
                      'snackbar-danger',
                      response.message,
                      'bottom',
                      'right'
                    );
                  }
                }
              });
      }
    });
  }

  private refreshTable() {
    this.paginator?._changePageSize(this.paginator?.pageSize);
  }

  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.renderedData.length;
    return numSelected === numRows;
  }

  masterToggle() {
    this.isAllSelected()
      ? this.selection.clear()
      : this.dataSource.renderedData.forEach((row) =>
          this.selection.select(row)
        );
  }

  removeSelectedRows() {
    const totalSelect = this.selection.selected.length;
    this.selection.selected.forEach((item) => {
      const index: number = this.dataSource.renderedData.findIndex(
        (d) => d === item
      );
      this.materielDatabase?.dataChange.value.splice(index, 1);
      this.refreshTable();
      this.selection = new SelectionModel<MaterielModel>(true, []);
    });
    this.showNotification(
      'snackbar-danger',
      totalSelect + ' matériel(s) ont été supprimés avec succès',
      'bottom',
      'right'
    );
  }

  public loadData() {
    this.materielDatabase = new MaterielService(this.httpClient);
    this.dataSource = new MaterielDataSource(
      this.materielDatabase,
      this.paginator,
      this.sort
    );
    this.subs.sink = fromEvent(this.filter?.nativeElement, 'keyup').subscribe(
      () => {
        if (!this.dataSource) {
          return;
        }
        this.dataSource.filter = this.filter?.nativeElement.value;
      }
    );
  }

  showNotification(colorName: string, text: string, placementFrom: MatSnackBarVerticalPosition, placementAlign: MatSnackBarHorizontalPosition) {
    this.snackBar.open(text, '', {
      duration: 5000,
      verticalPosition: placementFrom,
      horizontalPosition: placementAlign,
      panelClass: colorName,
    });
  }
  
}

export class MaterielDataSource extends DataSource<MaterielModel> {

  // Fields.
  filterChange = new BehaviorSubject('');
  get filter(): string {
    return this.filterChange.value;
  }
  set filter(filter: string) {
    this.filterChange.next(filter);
  }
  filteredData: MaterielModel[] = [];
  renderedData: MaterielModel[] = [];

  // Ctor.
  constructor(public materielDatabase: MaterielService,
              public paginator: MatPaginator,
              public _sort: MatSort) {
    super();
    this.filterChange.subscribe(() => (this.paginator.pageIndex = 0));
  }

  connect(): Observable<MaterielModel[]> {
    const displayDataChanges = [
      this.materielDatabase.dataChange,
      this._sort.sortChange,
      this.filterChange,
      this.paginator.page,
    ];
    this.materielDatabase.getAllMateriel();
    return merge(...displayDataChanges).pipe(
      map(() => {
        // Filter data
        this.filteredData = this.materielDatabase.data
          .slice()
          .filter((materiel: MaterielModel) => {
            const searchStr = (
              materiel.libelle +
              materiel.prixUnitaire +
              materiel.tva
            ).toLowerCase();
            return searchStr.indexOf(this.filter.toLowerCase()) !== -1;
          });
        // Sort filtered data
        const sortedData = this.sortData(this.filteredData.slice());
        // Grab the page's slice of the filtered sorted data.
        const startIndex = this.paginator.pageIndex * this.paginator.pageSize;
        this.renderedData = sortedData.splice(
          startIndex,
          this.paginator.pageSize
        );
        return this.renderedData;
      })
    );
  }

  disconnect() {}

  sortData(data: MaterielModel[]): MaterielModel[] {
    if (!this._sort.active || this._sort.direction === '') {
      return data;
    }
    return data.sort((a, b) => {
      let propertyA: Date | number | string = '';
      let propertyB: Date | number | string = '';
      switch (this._sort.active) {
        case 'materielId':
          [propertyA, propertyB] = [a.materielId, b.materielId];
          break;
        case 'libelle':
          [propertyA, propertyB] = [a.libelle, b.libelle];
          break;
        case 'prixUnitaire':
          [propertyA, propertyB] = [a.prixUnitaire, b.prixUnitaire];
          break;
        case 'tva':
          [propertyA, propertyB] = [a.tva, b.tva];
          break;
      }
      const valueA = isNaN(+propertyA) ? propertyA : +propertyA;
      const valueB = isNaN(+propertyB) ? propertyB : +propertyB;
      return (
        (valueA < valueB ? -1 : 1) * (this._sort.direction === 'asc' ? 1 : -1)
      );
    });
  }
  
}
