import { ComponentFixture, TestBed, waitForAsync } from "@angular/core/testing";
import { AllMaterielComponent } from "./all-materiel.component";

describe("AllMaterielComponent", () => {
  let component: AllMaterielComponent;
  let fixture: ComponentFixture<AllMaterielComponent>;
  beforeEach(
    waitForAsync(() => {
      TestBed.configureTestingModule({
        declarations: [AllMaterielComponent],
      }).compileComponents();
    })
  );
  beforeEach(() => {
    fixture = TestBed.createComponent(AllMaterielComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });
  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
