
export const environment = {
  production: true,
  apiUrl: 'http://localhost:5062',
  apiBaseURL: 'http://localhost:5062/api/v1',
};
